import streamlit as st
import pandas as pd
import numpy as np
import sys
from pathlib import Path

# Set up page configuration
st.set_page_config(
    page_title="Chemistry Explorer - Korean Description Test",
    page_icon="⚗️",
    layout="wide"
)

# Include the data directory
sys.path.append(str(Path.cwd()))
from data.elements import get_all_elements, get_element_by_atomic_number

# Get all elements data
elements = get_all_elements()

st.title("Chemistry Explorer - Korean Descriptions Test")

st.write("This is a simple test page to verify Korean descriptions are working correctly.")

# Create a selectbox for elements
element_names = [f"{e['atomic_number']} - {e['name']} ({e['symbol']})" for e in elements]
selected_element_name = st.selectbox("Select an element to view its descriptions:", element_names)

# Get the selected element
if selected_element_name:
    atomic_number = int(selected_element_name.split(" - ")[0])
    element = get_element_by_atomic_number(atomic_number)
    
    # Display element basic info
    st.header(f"{element['name']} ({element['symbol']}) - Atomic Number: {element['atomic_number']}")
    
    # Show Korean name if available
    if element['korean_name']:
        st.subheader(f"Korean Name: {element['korean_name']}")
    
    # Create tabs for different languages
    english_tab, korean_tab = st.tabs(["English Descriptions", "Korean Descriptions"])
    
    with english_tab:
        # English descriptions
        st.subheader("Standard Description")
        st.write(element['description'] if element['description'] else "No standard description available.")
        
        # Check if beginner description exists and is not None or NaN
        if 'beginner_description' in element and element['beginner_description'] and str(element['beginner_description']).lower() != 'nan':
            st.subheader("Beginner Description")
            st.write(element['beginner_description'])
        else:
            st.subheader("Beginner Description")
            st.write("Beginner description not available for this element.")
        
        # Check if advanced description exists and is not None or NaN
        if 'advanced_description' in element and element['advanced_description'] and str(element['advanced_description']).lower() != 'nan':
            st.subheader("Advanced Description")
            st.write(element['advanced_description'])
        else:
            st.subheader("Advanced Description")
            st.write("Advanced description not available for this element.")
    
    with korean_tab:
        # Korean descriptions
        st.subheader("한국어 표준 설명 (Standard Korean Description)")
        if 'korean_description' in element and element['korean_description'] and str(element['korean_description']).lower() != 'nan':
            st.write(element['korean_description'])
        else:
            st.write("한국어 표준 설명이 제공되지 않습니다. (Korean description not available.)")
        
        # Check if beginner Korean description exists and is not None or NaN
        if 'korean_beginner_description' in element and element['korean_beginner_description'] and str(element['korean_beginner_description']).lower() != 'nan':
            st.subheader("한국어 초급 설명 (Beginner Korean Description)")
            st.write(element['korean_beginner_description'])
        else:
            st.subheader("한국어 초급 설명 (Beginner Korean Description)")
            st.write("한국어 초급 설명이 제공되지 않습니다. (Korean beginner description not available.)")
        
        # Check if advanced Korean description exists and is not None or NaN
        if 'korean_advanced_description' in element and element['korean_advanced_description'] and str(element['korean_advanced_description']).lower() != 'nan':
            st.subheader("한국어 고급 설명 (Advanced Korean Description)")
            st.write(element['korean_advanced_description'])
        else:
            st.subheader("한국어 고급 설명 (Advanced Korean Description)")
            st.write("한국어 고급 설명이 제공되지 않습니다. (Korean advanced description not available.)")

# Display information about what was implemented
st.sidebar.header("Implementation Details")
st.sidebar.markdown("""
### Korean Descriptions Added
- Standard Korean descriptions for all elements
- Beginner Korean descriptions that match English versions
- Advanced Korean descriptions with technical details

Each Korean description is generated based on the element's properties 
and contains information tailored to the appropriate level of detail.
""")