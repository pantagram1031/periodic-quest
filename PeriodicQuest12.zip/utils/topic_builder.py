"""
Topic Builder utility module for the Science Learning Platform.
This module provides functions for creating, managing, and manipulating custom topics.
"""
import os
import json
import random
from typing import Dict, List, Any, Optional
from datetime import datetime

# Constants
CUSTOM_TOPICS_DIR = "data/custom_topics"

# Entity templates for different types of topics
ENTITY_TEMPLATES = {
    "chemical_element": {
        "name": "Chemical Element",
        "properties": [
            {"id": "atomic_number", "name": "Atomic Number", "type": "number"},
            {"id": "symbol", "name": "Symbol", "type": "text"},
            {"id": "name", "name": "Name", "type": "text"},
            {"id": "atomic_mass", "name": "Atomic Mass", "type": "number"},
            {"id": "category", "name": "Category", "type": "text"},
            {"id": "electron_configuration", "name": "Electron Configuration", "type": "text"},
            {"id": "electronegativity", "name": "Electronegativity", "type": "number"},
            {"id": "atomic_radius", "name": "Atomic Radius", "type": "number"},
            {"id": "ionization_energy", "name": "Ionization Energy", "type": "number"},
            {"id": "electron_affinity", "name": "Electron Affinity", "type": "number"},
            {"id": "oxidation_states", "name": "Oxidation States", "type": "text"},
            {"id": "standard_state", "name": "Standard State", "type": "text"},
            {"id": "melting_point", "name": "Melting Point", "type": "number"},
            {"id": "boiling_point", "name": "Boiling Point", "type": "number"},
            {"id": "density", "name": "Density", "type": "number"},
            {"id": "year_discovered", "name": "Year Discovered", "type": "number"},
            {"id": "discovered_by", "name": "Discovered By", "type": "text"},
            {"id": "named_by", "name": "Named By", "type": "text"},
            {"id": "description", "name": "Description", "type": "text"}
        ]
    },
    "particle": {
        "name": "Particle",
        "properties": [
            {"id": "name", "name": "Name", "type": "text"},
            {"id": "symbol", "name": "Symbol", "type": "text"},
            {"id": "mass", "name": "Mass", "type": "number"},
            {"id": "charge", "name": "Charge", "type": "number"},
            {"id": "spin", "name": "Spin", "type": "number"},
            {"id": "type", "name": "Type", "type": "text"},
            {"id": "family", "name": "Family", "type": "text"},
            {"id": "discovered", "name": "Discovered", "type": "number"},
            {"id": "discovered_by", "name": "Discovered By", "type": "text"},
            {"id": "description", "name": "Description", "type": "text"}
        ]
    },
    "custom": {
        "name": "Custom Entity",
        "properties": [
            {"id": "name", "name": "Name", "type": "text"},
            {"id": "description", "name": "Description", "type": "text"}
        ]
    }
}

# Property types and their validation rules
PROPERTY_TYPES = {
    "text": {
        "validate": lambda x: isinstance(x, str),
        "format": str
    },
    "number": {
        "validate": lambda x: isinstance(x, (int, float)),
        "format": float
    },
    "boolean": {
        "validate": lambda x: isinstance(x, bool),
        "format": bool
    },
    "date": {
        "validate": lambda x: isinstance(x, str) and len(x) == 10,
        "format": str
    }
}

# Ensure the custom topics directory exists
os.makedirs(CUSTOM_TOPICS_DIR, exist_ok=True)

def get_custom_topics(username: str) -> List[Dict[str, Any]]:
    """
    Get all custom topics created by a specific user.
    
    Args:
        username (str): The username to get topics for
        
    Returns:
        List[Dict[str, Any]]: List of topic dictionaries
    """
    topics = []
    
    # Iterate through all topic files
    for filename in os.listdir(CUSTOM_TOPICS_DIR):
        if filename.endswith('.json'):
            file_path = os.path.join(CUSTOM_TOPICS_DIR, filename)
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    topic = json.load(f)
                    # Only include topics created by this user
                    if topic.get('created_by') == username:
                        topics.append(topic)
            except Exception as e:
                print(f"Error loading topic {filename}: {str(e)}")
                continue
    
    # Sort topics by creation date (newest first)
    topics.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    return topics

def create_topic(title: str, description: str, entity_type: str, creator: str) -> str:
    """
    Create a new topic with the given information.
    
    Args:
        title (str): The title of the topic
        description (str): A description of the topic
        entity_type (str): The type of entities in this topic
        creator (str): The username of the creator
        
    Returns:
        str: The ID of the created topic
    """
    # Generate a unique topic ID
    topic_id = f"{title.lower().replace(' ', '_')}_{int(datetime.now().timestamp())}"
    
    # Create the topic dictionary
    topic = {
        "id": topic_id,
        "title": title,
        "description": description,
        "entity_type": entity_type,
        "created_by": creator,
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "aspects": [],
        "entities": [],
        "quiz_settings": {
            "input_aspects": [],
            "output_aspects": []
        }
    }
    
    # Save the topic to a file
    file_path = os.path.join(CUSTOM_TOPICS_DIR, f"{topic_id}.json")
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(topic, f, indent=2, ensure_ascii=False)
    
    return topic_id

def update_topic(topic_id: str, **kwargs) -> bool:
    """
    Update a topic with new information.
    
    Args:
        topic_id (str): The ID of the topic to update
        **kwargs: The fields to update and their new values
        
    Returns:
        bool: True if the update was successful, False otherwise
    """
    file_path = os.path.join(CUSTOM_TOPICS_DIR, f"{topic_id}.json")
    
    try:
        # Load the existing topic
        with open(file_path, 'r', encoding='utf-8') as f:
            topic = json.load(f)
        
        # Update the fields
        for key, value in kwargs.items():
            topic[key] = value
        
        # Update the timestamp
        topic['updated_at'] = datetime.now().isoformat()
        
        # Save the updated topic
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(topic, f, indent=2, ensure_ascii=False)
        
        return True
    except Exception as e:
        print(f"Error updating topic {topic_id}: {str(e)}")
        return False

def load_topic(topic_id: str) -> Optional[Dict[str, Any]]:
    """
    Load a topic by its ID.
    
    Args:
        topic_id (str): The ID of the topic to load
        
    Returns:
        Optional[Dict[str, Any]]: The topic dictionary if found, None otherwise
    """
    file_path = os.path.join(CUSTOM_TOPICS_DIR, f"{topic_id}.json")
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading topic {topic_id}: {str(e)}")
        return None

def save_topic(topic: Dict) -> bool:
    """Save a topic to disk"""
    try:
        topic_file = os.path.join(CUSTOM_TOPICS_DIR, f"{topic['id']}.json")
        with open(topic_file, 'w', encoding='utf-8') as f:
            json.dump(topic, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False

def delete_topic(topic_id: str) -> bool:
    """Delete a topic by its ID"""
    topic_file = os.path.join(CUSTOM_TOPICS_DIR, f"{topic_id}.json")
    if os.path.exists(topic_file):
        try:
            os.remove(topic_file)
            return True
        except Exception:
            return False
    return False

def get_all_topics() -> List[Dict]:
    """Get all available topics"""
    topics = []
    for filename in os.listdir(CUSTOM_TOPICS_DIR):
        if filename.endswith('.json'):
            topic_id = filename[:-5]  # Remove .json extension
            topic = load_topic(topic_id)
            if topic:
                topics.append(topic)
    return topics

def get_user_topics(username: str) -> List[Dict]:
    """Get all topics created by a specific user"""
    return [topic for topic in get_all_topics() if topic.get("created_by") == username]

def add_property(topic_id: str, property_data: dict) -> bool:
    """Add a new property (aspect) to a topic."""
    topic = load_topic(topic_id)
    if not topic:
        return False
    if "properties" not in topic:
        topic["properties"] = []
    # Ensure property has an id
    if "id" not in property_data or not property_data["id"]:
        property_data["id"] = property_data.get("name", "").lower().replace(" ", "_")
    # Prevent duplicate ids
    if any(p["id"] == property_data["id"] for p in topic["properties"]):
        return False
    topic["properties"].append(property_data)
    # Add this property to all entities
    for entity in topic.get("entities", []):
        if property_data["id"] not in entity:
            entity[property_data["id"]] = ""
    return save_topic(topic)

def add_aspect(topic_id: str, aspect_data: dict) -> bool:
    """Alias for add_property for backward compatibility"""
    return add_property(topic_id, aspect_data)

def update_property(topic_id: str, property_id: str, property_data: dict) -> bool:
    """Update an existing property (aspect) in a topic."""
    topic = load_topic(topic_id)
    if not topic or "properties" not in topic:
        return False
    for i, prop in enumerate(topic["properties"]):
        if prop["id"] == property_id:
            # Update property fields
            topic["properties"][i] = property_data
            return save_topic(topic)
    return False

def update_aspect(topic_id: str, aspect_id: str, aspect_data: dict) -> bool:
    """Alias for update_property for backward compatibility"""
    return update_property(topic_id, aspect_id, aspect_data)

def delete_property(topic_id: str, property_id: str) -> bool:
    """Delete a property (aspect) from a topic."""
    topic = load_topic(topic_id)
    if not topic or "properties" not in topic:
        return False
    # Remove property from properties list
    topic["properties"] = [p for p in topic["properties"] if p["id"] != property_id]
    # Remove property from all entities
    for entity in topic.get("entities", []):
        if property_id in entity:
            del entity[property_id]
    return save_topic(topic)

def delete_aspect(topic_id: str, aspect_id: str) -> bool:
    """Alias for delete_property for backward compatibility"""
    return delete_property(topic_id, aspect_id)

def add_entity(topic_id: str, entity_name: str) -> bool:
    """Add a new entity to a topic"""
    topic = load_topic(topic_id)
    if not topic:
        return False
    
    if "entities" not in topic:
        topic["entities"] = []
    
    # Create new entity with all aspects
    new_entity = {"name": entity_name}
    for aspect in topic.get("aspects", []):
        new_entity[aspect] = ""
    
    topic["entities"].append(new_entity)
    return save_topic(topic)

def remove_entity(topic_id: str, entity_name: str) -> bool:
    """Remove an entity from a topic"""
    topic = load_topic(topic_id)
    if not topic or "entities" not in topic:
        return False
    
    # Find and remove the entity
    for i, entity in enumerate(topic["entities"]):
        if entity.get("name") == entity_name:
            topic["entities"].pop(i)
            return save_topic(topic)
    return False

def delete_entity(topic_id: str, entity_name: str) -> bool:
    """Alias for remove_entity for backward compatibility"""
    return remove_entity(topic_id, entity_name)

def update_entity(topic_id: str, entity_name: str, aspect_values: dict) -> bool:
    """Update an entity's aspect values"""
    topic = load_topic(topic_id)
    if not topic or "entities" not in topic:
        return False
    
    # Find the entity
    for entity in topic["entities"]:
        if entity.get("name") == entity_name:
            # Update aspect values
            for aspect, value in aspect_values.items():
                if aspect in topic.get("aspects", []):
                    entity[aspect] = value
            return save_topic(topic)
    return False

def generate_quiz_questions(topic_id: str, num_questions: int = 5) -> List[Dict]:
    """Generate quiz questions based on the topic's quiz settings"""
    topic = load_topic(topic_id)
    if not topic:
        return []
    
    quiz_settings = topic.get("quiz_settings", {})
    input_aspects = quiz_settings.get("input_aspects", [])
    output_aspects = quiz_settings.get("output_aspects", [])
    
    if not input_aspects or not output_aspects:
        return []
    
    questions = []
    entities = topic.get("entities", [])
    
    # Generate questions
    for _ in range(num_questions):
        # Select random entity
        entity = random.choice(entities)
        
        # Select random input and output aspects
        input_aspect = random.choice(input_aspects)
        output_aspect = random.choice(output_aspects)
        
        # Create question
        question = {
            "type": "aspect_to_aspect",
            "input_aspect": input_aspect,
            "output_aspect": output_aspect,
            "input_value": entity.get(input_aspect, ""),
            "correct_answer": entity.get(output_aspect, ""),
            "entity_name": entity.get("name", "")
        }
        
        # Add bait options
        bait_options = []
        other_entities = [e for e in entities if e != entity]
        while len(bait_options) < 3 and other_entities:
            bait_entity = random.choice(other_entities)
            bait_value = bait_entity.get(output_aspect, "")
            if bait_value and bait_value not in bait_options:
                bait_options.append(bait_value)
            other_entities.remove(bait_entity)
        
        question["bait_options"] = bait_options
        questions.append(question)
    
    return questions

def search_entities(topic_id: str, query: str) -> list:
    """
    Search for entities in a topic by matching the query against any property value.
    """
    topic = load_topic(topic_id)
    if not topic or "entities" not in topic:
        return []
    query = query.lower()
    results = []
    for entity in topic["entities"]:
        for value in entity.values():
            if isinstance(value, str) and query in value.lower():
                results.append(entity)
                break
            elif isinstance(value, (int, float)) and query in str(value):
                results.append(entity)
                break
    return results

def get_entity_by_id(topic_id: str, entity_id: str) -> Optional[Dict]:
    """Get an entity from a topic by its ID"""
    topic = load_topic(topic_id)
    if not topic or "entities" not in topic:
        return None
    
    for entity in topic["entities"]:
        if entity.get("id") == entity_id:
            return entity
    return None

def create_topic_structure(title: str, description: str, entity_type: str, created_by: str = "") -> dict:
    """
    Create a topic structure dictionary (does not save to disk).
    """
    return {
        "id": f"{title.lower().replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "title": title,
        "description": description,
        "entity_type": entity_type,
        "created_by": created_by,
        "created_at": datetime.now().isoformat(),
        "properties": [],
        "entities": [],
        "quiz_settings": {
            "input_aspects": [],
            "output_aspects": []
        }
    }

def export_topic_to_file(topic_id: str, file_path: str) -> bool:
    """Export a topic to a JSON file"""
    topic = load_topic(topic_id)
    if not topic:
        return False
    
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(topic, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False

def import_topic_from_file(file_path: str) -> Optional[str]:
    """Import a topic from a JSON file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            topic = json.load(f)
        
        # Validate required fields
        required_fields = ['id', 'title', 'description', 'entity_type']
        if not all(field in topic for field in required_fields):
            return None
        
        # Save the topic
        if save_topic(topic):
            return topic['id']
        return None
    except Exception:
        return None

def get_topic_by_id(topic_id: str) -> Optional[Dict]:
    """Get a topic by its ID"""
    return load_topic(topic_id)

def get_topic_by_title(title: str) -> Optional[Dict]:
    """Get a topic by its title"""
    topics = get_all_topics()
    for topic in topics:
        if topic.get('title') == title:
            return topic
    return None

def get_topic_by_entity_id(entity_id: str) -> Optional[Dict]:
    """Get a topic that contains an entity with the given ID"""
    topics = get_all_topics()
    for topic in topics:
        for entity in topic.get('entities', []):
            if entity.get('id') == entity_id:
                return topic
    return None

def get_topic_by_property_id(property_id: str) -> Optional[Dict]:
    """Get a topic that contains a property with the given ID"""
    topics = get_all_topics()
    for topic in topics:
        for prop in topic.get('properties', []):
            if prop.get('id') == property_id:
                return topic
    return None

def get_topic_by_aspect_id(aspect_id: str) -> Optional[Dict]:
    """Alias for get_topic_by_property_id for backward compatibility"""
    return get_topic_by_property_id(aspect_id)

def get_topic_by_entity_name(entity_name: str) -> Optional[Dict]:
    """Get a topic that contains an entity with the given name"""
    topics = get_all_topics()
    for topic in topics:
        for entity in topic.get('entities', []):
            if entity.get('name') == entity_name:
                return topic
    return None

def get_topic_by_property_name(property_name: str) -> Optional[Dict]:
    """Get a topic that contains a property with the given name"""
    topics = get_all_topics()
    for topic in topics:
        for prop in topic.get('properties', []):
            if prop.get('name') == property_name:
                return topic
    return None

def get_topic_by_aspect_name(aspect_name: str) -> Optional[Dict]:
    """Alias for get_topic_by_property_name for backward compatibility"""
    return get_topic_by_property_name(aspect_name)