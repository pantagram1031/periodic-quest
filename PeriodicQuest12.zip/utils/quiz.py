"""
Module for handling the quiz functionality.
"""

import random
import re
import streamlit as st
from typing import Union, List, Dict, Any, Optional
from data.elements import get_all_elements, get_element_by_atomic_number, get_element_by_symbol, get_element_by_korean_name

class QuizGenerator:
    """Class for generating quiz questions about chemical elements"""
    
    def __init__(self, quiz_mode: str = "multiple_choice", quiz_type: Union[str, List[str]] = "all", 
                 element_filter: Optional[Dict[str, Any]] = None, difficulty: str = "easy"):
        """Initialize the quiz generator
        
        Args:
            quiz_mode (str): The quiz mode - "multiple_choice" or "text_input"
            quiz_type (Union[str, list]): The type of questions to generate. Can be a string for a single type or a list of types.
                             Valid types: "all", "atomic_number", "symbol", "name", "category", 
                             "description", "electron_config", "period_group"
                             Note: "korean_name" is now handled as an alternative answer to "name" questions
            element_filter (dict): Filter for elements to include in the quiz
                - {'type': 'all'}: Include all elements
                - {'type': 'atomic_range', 'min': min_val, 'max': max_val}: Include elements within atomic number range
                - {'type': 'category', 'value': category_name}: Include elements of specific category
            difficulty (str): Difficulty level of the quiz - "easy", "medium", or "hard"
        """
        self.difficulty = difficulty
        # Get all elements
        all_elements = get_all_elements()
        
        # Apply element filtering if specified
        if element_filter:
            if element_filter['type'] == 'atomic_range':
                # Filter by atomic number range
                min_val = element_filter['min']
                max_val = element_filter['max']
                self.elements = [e for e in all_elements if min_val <= e['atomic_number'] <= max_val]
            elif element_filter['type'] == 'category':
                # Filter by category
                category = element_filter['value']
                self.elements = [e for e in all_elements if e['category'] == category]
            else:
                # Default to all elements
                self.elements = all_elements
        else:
            # Default to all elements if no filter provided
            self.elements = all_elements
            
        # Ensure we have at least some elements
        if not self.elements:
            self.elements = all_elements  # Fallback to all elements if filtering resulted in empty list
            
        self.quiz_mode = quiz_mode
        self.quiz_type = quiz_type
        
        # Define all the question types and their corresponding generators
        all_question_types = {
            "symbol": self._generate_symbol_question,
            "name": self._generate_name_question,
            "atomic_number": self._generate_atomic_number_question,
            "category": self._generate_category_question,
            "korean_name": self._generate_korean_name_question,
            "description": [self._generate_description_to_element_question, self._generate_element_to_description_question],
            "electron_config": self._generate_electron_configuration_question,
            "period_group": self._generate_period_group_question
        }
        
        # All possible question generators
        all_generators = [
            self._generate_symbol_question,
            self._generate_name_question,
            self._generate_atomic_number_question,
            self._generate_category_question,
            self._generate_electron_configuration_question, 
            self._generate_period_group_question,
            self._generate_korean_name_question,
            self._generate_description_to_element_question,
            self._generate_element_to_description_question
        ]
        
        # Initialize the list of question generators
        self.multiple_choice_question_types = []
        
        # For "all", add all question types
        if quiz_type == "all":
            self.multiple_choice_question_types = all_generators
        # Handle a list of question types
        elif isinstance(quiz_type, list):
            # Build list of generators based on selected types
            for qtype in quiz_type:
                if qtype in all_question_types:
                    generators = all_question_types[qtype]
                    if isinstance(generators, list):
                        self.multiple_choice_question_types.extend(generators)
                    else:
                        self.multiple_choice_question_types.append(generators)
            
            # If no types were recognized, use all
            if not self.multiple_choice_question_types:
                self.multiple_choice_question_types = all_generators
        # Handle a single question type (string)
        else:
            if quiz_type in all_question_types:
                generators = all_question_types[quiz_type]
                if isinstance(generators, list):
                    self.multiple_choice_question_types = generators
                else:
                    self.multiple_choice_question_types = [generators]
            else:
                # Default to a subset of question types
                self.multiple_choice_question_types = [
                    self._generate_symbol_question,
                    self._generate_name_question,
                    self._generate_atomic_number_question,
                    self._generate_category_question
                ]
        
        # Define all the text input question types and their corresponding generators
        all_text_question_types = {
            "symbol": self._generate_symbol_text_question,
            "name": self._generate_name_text_question,
            "atomic_number": self._generate_atomic_number_text_question,
            "category": self._generate_category_text_question,
            "korean_name": self._generate_korean_name_text_question,
            "description": self._generate_description_text_question
        }
        
        # All possible text input question generators
        all_text_generators = [
            self._generate_symbol_text_question,
            self._generate_name_text_question,
            self._generate_atomic_number_text_question,
            self._generate_category_text_question,
            self._generate_korean_name_text_question,
            self._generate_description_text_question
        ]
        
        # Initialize the list of text input question generators
        self.text_input_question_types = []
        
        # For "all", add all question types
        if quiz_type == "all":
            self.text_input_question_types = all_text_generators
        # Handle a list of question types
        elif isinstance(quiz_type, list):
            # Build list of generators based on selected types
            for qtype in quiz_type:
                if qtype in all_text_question_types:
                    self.text_input_question_types.append(all_text_question_types[qtype])
            
            # If no types were recognized, use all
            if not self.text_input_question_types:
                self.text_input_question_types = all_text_generators
        # Handle a single question type (string)
        else:
            if quiz_type in all_text_question_types:
                self.text_input_question_types = [all_text_question_types[quiz_type]]
            else:
                # Default to a subset of question types
                self.text_input_question_types = [
                    self._generate_symbol_text_question,
                    self._generate_name_text_question,
                    self._generate_atomic_number_text_question,
                    self._generate_category_text_question
                ]
    
    def generate_question(self):
        """Generate a random quiz question based on the configured mode and type"""
        if not self.elements:
            # If there are no elements (should never happen due to fallback), return a simple message
            return {
                'question': "No elements available for quiz. Please adjust your filter settings.",
                'options': ["OK"],
                'correct_answer': "OK",
                'element': {
                    'name': 'None',
                    'symbol': 'None',
                    'atomic_number': 0,
                    'category': 'None'
                }
            }
            
        if self.quiz_mode == "multiple_choice":
            question_generator = random.choice(self.multiple_choice_question_types)
        else:  # text_input mode
            question_generator = random.choice(self.text_input_question_types)
            
        return question_generator()
        
    def _generate_symbol_text_question(self):
        """Generate a text input question about element symbols"""
        element = random.choice(self.elements)
        
        return {
            'question': f"What is the symbol for {element['name']}?",
            'correct_answer': element['symbol'],
            'element': element,
            'input_type': 'text',
            'hint': f"Element symbol (1-2 characters)"
        }

    def _generate_name_text_question(self):
        """Generate a text input question about element names"""
        element = random.choice(self.elements)
        
        # Store both English name and Korean name as possible answers
        correct_answers = [element['name']]
        if 'korean_name' in element and element['korean_name']:
            correct_answers.append(element['korean_name'])
            
        return {
            'question': f"What is the name of the element with symbol {element['symbol']}?",
            'correct_answer': element['name'],  # Primary answer is still English name
            'alternative_answers': correct_answers,  # List of all acceptable answers
            'element': element,
            'input_type': 'text',
            'hint': f"Element name (English or Korean)"
        }

    def _generate_atomic_number_text_question(self):
        """Generate a text input question about atomic numbers"""
        element = random.choice(self.elements)
        
        return {
            'question': f"What is the atomic number of {element['name']} ({element['symbol']})?",
            'correct_answer': element['atomic_number'],
            'element': element,
            'input_type': 'number',
            'hint': f"Enter a number"
        }
        
    def _generate_category_text_question(self):
        """Generate a text input question about element categories"""
        element = random.choice(self.elements)
        
        return {
            'question': f"Which category does {element['name']} ({element['symbol']}) belong to?",
            'correct_answer': element['category'],
            'element': element,
            'input_type': 'text',
            'hint': f"e.g. metal, nonmetal, noble gas, etc."
        }
    
    def _generate_symbol_question(self):
        """Generate a question about element symbols"""
        element = random.choice(self.elements)
        
        # Create options with the correct symbol and some "bait" symbols based on difficulty
        correct_answer = element['symbol']
        options = [correct_answer]
        
        # Adjust number of bait symbols based on difficulty
        bait_chance = 0.3  # Base chance
        if self.difficulty == "medium":
            bait_chance = 0.5  # Medium has moderate bait chance
        elif self.difficulty == "hard":
            bait_chance = 0.8  # Hard has high bait chance
            
        # Randomly decide if we use bait symbols at all
        use_bait = random.random() < bait_chance
        max_baits = 1  # Default to at most 1 bait for easy difficulty
        
        if self.difficulty == "medium":
            max_baits = 2  # Medium difficulty can have up to 2 baits
        elif self.difficulty == "hard": 
            max_baits = 3  # Hard difficulty can have up to 3 baits
            
        if use_bait:
            # Create bait symbols that are similar to the correct symbol
            bait_symbols = self._generate_bait_symbols(correct_answer)
            options.extend(bait_symbols[:max_baits])  # Take limited number of bait symbols
        
        # Add remaining random symbols if needed to reach 4 total options
        other_elements = [e for e in self.elements if e['symbol'] != correct_answer]
        remaining_slots = 4 - len(options)
        if remaining_slots > 0 and len(other_elements) >= remaining_slots:
            random_elements = random.sample(other_elements, remaining_slots)
            options.extend([e['symbol'] for e in random_elements])
        
        # Shuffle options
        random.shuffle(options)
        
        return {
            'question': f"What is the symbol for {element['name']}?",
            'options': options,
            'correct_answer': correct_answer,
            'element': element
        }
        
    def _generate_bait_symbols(self, symbol):
        """Generate plausible but incorrect bait symbols for a given element symbol
        
        Args:
            symbol (str): The correct element symbol
            
        Returns:
            list: List of bait symbols
        """
        bait_symbols = []
        
        # Strategy 1: Adjust for various common patterns while maintaining capitalization rules
        if len(symbol) == 1:
            # For single-letter symbols (H, N, O, etc.), add a second letter that makes it look like a valid element
            bait_letters = ['l', 'a', 'r', 'n', 't']  # Common letters that might be plausible
            for letter in bait_letters:
                if len(bait_symbols) < 3:  # Limit to 3 bait symbols
                    # Ensure first letter is always capitalized, second is lowercase like real element symbols
                    bait_symbols.append(symbol + letter.lower())
                    
        elif len(symbol) == 2:
            # For two-letter symbols, follow proper element capitalization (first uppercase, second lowercase)
            
            # Swap with similar-looking letters
            letter_swaps = {
                'e': 'a', 'a': 'e', 'n': 'm', 'm': 'n', 
                'c': 'o', 'o': 'c', 'l': 'i', 'i': 'l'
            }
            
            # Try to swap first letter while keeping it capitalized
            if symbol[0].lower() in letter_swaps:
                new_letter = letter_swaps[symbol[0].lower()].upper()  # Always uppercase first letter
                bait_symbols.append(new_letter + symbol[1])
                
            # Try to swap second letter while keeping it lowercase
            if symbol[1].lower() in letter_swaps:
                new_letter = letter_swaps[symbol[1].lower()].lower()  # Always lowercase second letter
                bait_symbols.append(symbol[0] + new_letter)
                
            # Add version with both letters capitalized only if original second letter is lowercase
            if symbol[1].islower():
                bait_symbols.append(symbol[0] + symbol[1].upper())
        
        # Strategy 2: Reverse the symbol if it has 2 letters (while maintaining capitalization rules)
        if len(symbol) == 2:
            # Ensure the original second letter is now capitalized and the original first letter is lowercase
            reversed_symbol = symbol[1].upper() + symbol[0].lower()
            if reversed_symbol != symbol:  # Only add if it's different
                bait_symbols.append(reversed_symbol)
        
        # Strategy 3: Add predefined plausible mistakes for common elements
        # Expanded to include more similar-looking element symbols that follow proper capitalization
        common_mistakes = {
            # Period 1-2
            'H': ['He', 'Hy', 'Li'], 'He': ['H', 'Li', 'Be', 'Ne'], 'Li': ['Be', 'Na', 'K'], 'Be': ['B', 'Li', 'Ba', 'Mg'],
            'B': ['Be', 'C', 'Br', 'Bo'], 'C': ['B', 'N', 'Ca', 'Co', 'Cl'], 'N': ['C', 'O', 'Na', 'Ne'], 'O': ['N', 'F', 'Os'],
            'F': ['O', 'Ne', 'Fe', 'Fl'], 'Ne': ['Na', 'F', 'Ni', 'He'],
            
            # Period 3
            'Na': ['K', 'Mg', 'N', 'Nb'], 'Mg': ['Na', 'Al', 'Mn', 'Mo'], 'Al': ['Si', 'Mg', 'Ga', 'Ag', 'At'],
            'Si': ['Al', 'P', 'S', 'Se', 'Sn'], 'P': ['Si', 'S', 'Po'], 'S': ['P', 'Cl', 'Si', 'Se', 'Sr'],
            'Cl': ['S', 'Ar', 'C', 'Ca', 'Cs'], 'Ar': ['K', 'Kr', 'At'],
            
            # Period 4 (first row transition metals)
            'K': ['Ca', 'Na', 'Kr'], 'Ca': ['K', 'Sc', 'C', 'Cl', 'Cu'], 'Sc': ['Ca', 'Ti', 'Sr'], 
            'Ti': ['Sc', 'V', 'Tl'], 'V': ['Ti', 'Cr', 'W'], 'Cr': ['V', 'Mn', 'Cu'], 
            'Mn': ['Cr', 'Fe', 'Mg', 'Mo'], 'Fe': ['Mn', 'Co', 'F', 'Fl'], 'Co': ['Fe', 'Ni', 'Cu', 'C'], 
            'Ni': ['Co', 'Cu', 'Ne'], 'Cu': ['Ni', 'Zn', 'Ca', 'Co', 'Cr'], 'Zn': ['Cu', 'Ga', 'Zr'],
            'Ga': ['Zn', 'Ge', 'Al'], 'Ge': ['Ga', 'As', 'Gd'], 'As': ['Ge', 'Se', 'At', 'Au'], 
            'Se': ['As', 'Br', 'S', 'Si'], 'Br': ['Se', 'Kr', 'B'], 'Kr': ['Br', 'Rb', 'K', 'Ar'],
            
            # Period 5-7 selected elements
            'Sr': ['Ca', 'Y', 'S'], 'Ag': ['Au', 'Cd', 'Al', 'At'], 'Sn': ['Sb', 'In', 'Si'], 
            'I': ['Br', 'Te', 'In'], 'Xe': ['Cs', 'I', 'Kr'], 'Cs': ['Ba', 'Xe', 'Cl'],
            'Ba': ['Cs', 'La', 'Be'], 'Au': ['Ag', 'Hg', 'At', 'As'], 'Hg': ['Au', 'Tl', 'Ha'], 
            'Pb': ['Tl', 'Bi', 'Pt', 'P'], 'Bi': ['Pb', 'Po', 'Ba'], 'U': ['Np', 'Pa', 'V'],
            
            # Add more distinctive pairs that are commonly confused
            'Ta': ['W', 'Pa'], 'W': ['V', 'Ta'], 'Re': ['Os', 'Ra'],
            'Pt': ['Au', 'Pd', 'Pb'], 'At': ['As', 'Rn', 'Ag', 'Al'], 'Rn': ['Ra', 'Fr', 'Xe']
        }
        
        if symbol in common_mistakes:
            bait_options = common_mistakes[symbol]
            # Filter out any bait symbols that are actual element symbols
            existing_symbols = [e['symbol'] for e in self.elements]
            filtered_baits = [b for b in bait_options if b not in existing_symbols]
            if filtered_baits:
                bait_symbols.extend(filtered_baits[:2])  # Add up to 2 common mistakes
        
        # Ensure we only return unique symbols
        unique_bait_symbols = list(set(bait_symbols))
        
        # Filter out any bait symbols that are actual element symbols
        existing_symbols = [e['symbol'] for e in self.elements]
        final_bait_symbols = [b for b in unique_bait_symbols if b not in existing_symbols]
        
        # Final validation: ensure all bait symbols follow capitalization rules for elements
        # First letter must be uppercase
        validated_symbols = []
        for bait in final_bait_symbols:
            if bait and bait[0].isupper():  # Only add symbols that start with uppercase
                validated_symbols.append(bait)
        
        return validated_symbols
    
    def _generate_name_question(self):
        """Generate a question about element names"""
        element = random.choice(self.elements)
        
        # Create options with the correct name and 3 random wrong names
        correct_answer = element['name']
        options = [correct_answer]
        
        # Add 3 other random names
        other_elements = [e for e in self.elements if e['name'] != correct_answer]
        random_elements = random.sample(other_elements, 3)
        options.extend([e['name'] for e in random_elements])
        
        # Shuffle options
        random.shuffle(options)
        
        # Store both English name and Korean name as possible answers
        alternative_answers = [element['name']]
        if 'korean_name' in element and element['korean_name']:
            alternative_answers.append(element['korean_name'])
        
        return {
            'question': f"What is the name of the element with symbol {element['symbol']}?",
            'options': options,
            'correct_answer': correct_answer,
            'element': element,
            'alternative_answers': alternative_answers  # Add alternative answers
        }
    
    def _generate_atomic_number_question(self):
        """Generate a question about atomic numbers"""
        element = random.choice(self.elements)
        
        # Create options with the correct atomic number and 3 wrong numbers
        correct_answer = element['atomic_number']
        options = [correct_answer]
        
        # Generate wrong options based on difficulty
        if self.difficulty == "hard":
            # For hard difficulty, choose numbers very close to the correct answer
            # Create a range of nearby atomic numbers (typically within ±5)
            possible_numbers = list(range(max(1, correct_answer - 5), min(118, correct_answer + 6)))
            # Remove the correct answer from possible numbers
            possible_numbers.remove(correct_answer)
            
            # If we have enough nearby numbers, select from them
            if len(possible_numbers) >= 3:
                random_numbers = random.sample(possible_numbers, 3)
            else:
                # Otherwise select from close within a broader range
                broader_range = list(range(max(1, correct_answer - 10), min(118, correct_answer + 11)))
                broader_range = [n for n in broader_range if n != correct_answer]
                random_numbers = random.sample(broader_range, 3)
                
        elif self.difficulty == "medium":
            # For medium difficulty, choose numbers somewhat close to the correct answer
            # Create a range of moderately close atomic numbers (within ±15)
            possible_numbers = list(range(max(1, correct_answer - 15), min(118, correct_answer + 16)))
            # Remove the correct answer
            if correct_answer in possible_numbers:
                possible_numbers.remove(correct_answer)
            
            # Select 3 numbers from this range
            random_numbers = random.sample(possible_numbers, 3)
            
        else:  # easy difficulty
            # For easy difficulty, choose numbers from across the periodic table
            # This makes the options more distinct and easier to identify
            other_atomic_numbers = [e['atomic_number'] for e in self.elements if e['atomic_number'] != correct_answer]
            random_numbers = random.sample(other_atomic_numbers, 3)
        
        options.extend(random_numbers)
        
        # Shuffle options
        random.shuffle(options)
        
        # Get element name based on current language
        import streamlit as st
        current_lang = st.session_state.language if "language" in st.session_state else "English"
        
        # Create question with appropriate display name
        if current_lang == "Korean" and "korean_name" in element and element["korean_name"]:
            question_text = f"What is the atomic number of {element['korean_name']} ({element['name']}, {element['symbol']})?"
        else:
            question_text = f"What is the atomic number of {element['name']} ({element['symbol']})?"
        
        return {
            'question': question_text,
            'options': options,
            'correct_answer': correct_answer,
            'element': element
        }
    
    def _generate_category_question(self):
        """Generate a question about element categories"""
        element = random.choice(self.elements)
        
        # Create options with the correct category and 3 random wrong categories
        correct_answer = element['category']
        options = [correct_answer]
        
        # Get unique categories and select 3 random wrong ones
        all_categories = list(set([e['category'] for e in self.elements]))
        other_categories = [c for c in all_categories if c != correct_answer]
        random_categories = random.sample(other_categories, min(3, len(other_categories)))
        options.extend(random_categories)
        
        # Shuffle options
        random.shuffle(options)
        
        # Get element name based on current language
        import streamlit as st
        current_lang = st.session_state.language if "language" in st.session_state else "English"
        
        # Create question with appropriate display name
        if current_lang == "Korean" and "korean_name" in element and element["korean_name"]:
            question_text = f"Which category does {element['korean_name']} ({element['name']}, {element['symbol']}) belong to?"
        else:
            question_text = f"Which category does {element['name']} ({element['symbol']}) belong to?"
        
        return {
            'question': question_text,
            'options': options,
            'correct_answer': correct_answer,
            'element': element
        }
    
    def _generate_electron_configuration_question(self):
        """Generate a question about electron configurations"""
        # Only use elements that have electron configuration data
        valid_elements = [e for e in self.elements if 'electron_configuration' in e and e['electron_configuration'] and e['electron_configuration'].strip()]
        
        if not valid_elements:
            # If no elements have electron configuration data, fall back to another question type
            return self._generate_atomic_number_question()
        
        element = random.choice(valid_elements)
        
        # Create options with the correct configuration and 3 random wrong ones
        correct_answer = element['electron_configuration']
        options = [correct_answer]
        
        # For hard difficulty, try to find elements with similar configurations
        if self.difficulty == "hard":
            # Look for elements with similar electron configuration patterns
            # First, try to find elements with the same noble gas core
            core_match = re.search(r'\[(.*?)\]', correct_answer)
            if core_match:
                core = core_match.group(1)
                similar_elements = [e for e in valid_elements 
                                   if e['electron_configuration'] != correct_answer 
                                   and f"[{core}]" in e['electron_configuration']]
                
                if len(similar_elements) >= 3:
                    # Use elements with the same core
                    random_elements = random.sample(similar_elements, 3)
                    options.extend([e['electron_configuration'] for e in random_elements])
                else:
                    # Not enough elements with the same core, use other random elements
                    other_elements = [e for e in valid_elements if e['electron_configuration'] != correct_answer]
                    if len(other_elements) >= 3:
                        random_elements = random.sample(other_elements, 3)
                        options.extend([e['electron_configuration'] for e in random_elements])
                    else:
                        # Fall back to manually constructed options for hard mode
                        options.extend(self._generate_similar_electron_configs(correct_answer, 3))
            else:
                # No noble gas core found, use other random elements
                other_elements = [e for e in valid_elements if e['electron_configuration'] != correct_answer]
                if len(other_elements) >= 3:
                    random_elements = random.sample(other_elements, 3)
                    options.extend([e['electron_configuration'] for e in random_elements])
                else:
                    # Fall back to manually constructed options for hard mode
                    options.extend(self._generate_similar_electron_configs(correct_answer, 3))
                    
        # For medium difficulty, use a mix of similar and different configurations
        elif self.difficulty == "medium":
            other_elements = [e for e in valid_elements if e['electron_configuration'] != correct_answer]
            
            if len(other_elements) >= 3:
                # Get a mix of elements from different parts of the periodic table
                random_elements = random.sample(other_elements, 3)
                options.extend([e['electron_configuration'] for e in random_elements])
            else:
                # Fall back to generated options
                options.extend(self._generate_similar_electron_configs(correct_answer, 3))
                
        # For easy difficulty, use clearly different configurations
        else:  # easy difficulty
            # Try to find elements from different groups/periods for distinct configurations
            other_elements = [e for e in valid_elements if e['electron_configuration'] != correct_answer]
            
            if len(other_elements) >= 3:
                # For easy mode, try to pick elements with very different electron configurations
                # One approach is to pick elements from different regions of the periodic table
                noble_gases = [e for e in other_elements if e['category'] == 'noble gas']
                alkali_metals = [e for e in other_elements if e['category'] == 'alkali metal']
                transition_metals = [e for e in other_elements if e['category'] == 'transition metal']
                nonmetals = [e for e in other_elements if e['category'] == 'nonmetal']
                
                # Choose one from each category if possible
                samples = []
                for category in [noble_gases, alkali_metals, transition_metals, nonmetals]:
                    if category and len(samples) < 3:
                        samples.append(random.choice(category))
                
                # If we still need more, add random elements
                if len(samples) < 3:
                    remaining = [e for e in other_elements if e not in samples]
                    samples.extend(random.sample(remaining, min(3 - len(samples), len(remaining))))
                
                # Take only what we need
                options.extend([e['electron_configuration'] for e in samples[:3]])
            else:
                # Fall back to common configurations
                common_configs = [
                    "[He] 2s² 2p⁶",  # Neon
                    "[Ne] 3s² 3p⁶",  # Argon
                    "[Ar] 4s² 3d¹⁰ 4p⁶"  # Krypton
                ]
                
                # Remove the correct answer if it's in the common_configs
                common_configs = [c for c in common_configs if c != correct_answer]
                
                # Take what we need
                options.extend(common_configs[:3])
        
        # Ensure we have exactly 4 options (1 correct, 3 wrong)
        if len(options) > 4:
            # Keep the correct answer and take 3 random wrong ones
            wrong_options = [opt for opt in options if opt != correct_answer]
            options = [correct_answer] + random.sample(wrong_options, 3)
        elif len(options) < 4:
            # Not enough options, generate more
            additional_needed = 4 - len(options)
            options.extend(self._generate_similar_electron_configs(correct_answer, additional_needed))
        
        # Shuffle options
        random.shuffle(options)
        
        # Get element name based on current language
        import streamlit as st
        current_lang = st.session_state.language if "language" in st.session_state else "English"
        
        # Create question with appropriate display name
        if current_lang == "Korean" and "korean_name" in element and element["korean_name"]:
            question_text = f"What is the electron configuration of {element['korean_name']} ({element['name']}, {element['symbol']})?"
        else:
            question_text = f"What is the electron configuration of {element['name']} ({element['symbol']})?"
        
        return {
            'question': question_text,
            'options': options,
            'correct_answer': correct_answer,
            'element': element
        }
        
    def _generate_similar_electron_configs(self, correct_config, count):
        """Generate similar but incorrect electron configurations
        
        Args:
            correct_config (str): The correct electron configuration
            count (int): How many similar configurations to generate
            
        Returns:
            list: List of similar but incorrect electron configurations
        """
        # Import re at function scope to avoid potential issues
        import re
        
        generated_configs = []
        
        # Try to parse the configuration to generate similar ones
        noble_gas_match = re.search(r'\[(.*?)\]', correct_config)
        
        if noble_gas_match:
            # Configuration uses noble gas shorthand
            noble_gas = noble_gas_match.group(1)
            rest = correct_config[len(noble_gas_match.group(0)):].strip()
            
            # Generate variations by changing the noble gas core or the electrons
            noble_gas_options = ["He", "Ne", "Ar", "Kr", "Xe", "Rn"]
            
            for _ in range(count):
                if random.random() < 0.5 and noble_gas in noble_gas_options:
                    # Change the noble gas core
                    other_gases = [gas for gas in noble_gas_options if gas != noble_gas]
                    new_core = random.choice(other_gases)
                    generated_configs.append(f"[{new_core}] {rest}")
                else:
                    # Modify the electron distribution
                    if rest:
                        # Parse the rest of the configuration and modify
                        modified = []
                        parts = re.findall(r'(\d[spdf][\u00b2\u00b3\u2074-\u2079\u00b9\u00b0-\u00b1\u207a-\u207b]*)', rest)
                        
                        for part in parts:
                            orbital = part[0:2]  # Like 2s, 3p, etc.
                            
                            # Extract superscript if present
                            superscript_match = re.search(r'([spdf])([\u00b2\u00b3\u2074-\u2079\u00b9\u00b0-\u00b1\u207a-\u207b]*)', part)
                            if superscript_match and superscript_match.group(2):
                                # Change the electron count in superscript
                                new_count = random.choice([1, 2, 3, 4, 5, 6])
                                # Convert to superscript (this is simplified)
                                superscripts = {
                                    1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 
                                    7: "⁷", 8: "⁸", 9: "⁹", 10: "¹⁰"
                                }
                                new_superscript = superscripts.get(new_count, "")
                                modified.append(f"{orbital}{new_superscript}")
                            else:
                                # No superscript, just use the part as is
                                modified.append(part)
                        
                        # Create the new configuration
                        generated_configs.append(f"[{noble_gas}] {' '.join(modified)}")
                    else:
                        # No electron distribution after noble gas, create a simple one
                        next_shell = random.choice(["1s", "2s", "2p", "3s", "3p", "4s"])
                        electron_count = random.choice([1, 2])
                        superscript = "¹" if electron_count == 1 else "²"
                        generated_configs.append(f"[{noble_gas}] {next_shell}{superscript}")
        else:
            # Configuration doesn't use noble gas shorthand, harder to modify properly
            # Create some basic configurations
            basic_configs = [
                "1s² 2s² 2p⁶",
                "1s² 2s² 2p⁶ 3s² 3p⁶",
                "1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶",
                "1s² 2s² 2p⁶ 3s² 3p⁶ 4s² 3d¹⁰ 4p⁶ 5s² 4d¹⁰ 5p⁶"
            ]
            
            # Filter out the correct configuration
            basic_configs = [config for config in basic_configs if config != correct_config]
            
            # Select needed configs
            generated_configs = basic_configs[:count]
            
            # If we still need more, create variations
            while len(generated_configs) < count:
                # Create a simple variation
                shell = random.choice([1, 2, 3, 4])
                orbital = random.choice(["s", "p", "d", "f"])
                electron_count = random.choice([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
                
                # Convert to superscript (simplified)
                superscripts = {
                    1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 
                    7: "⁷", 8: "⁸", 9: "⁹", 10: "¹⁰"
                }
                superscript = superscripts.get(electron_count, "")
                
                config = f"{shell}{orbital}{superscript}"
                
                if orbital == "s" and electron_count <= 2 or \
                   orbital == "p" and electron_count <= 6 or \
                   orbital == "d" and electron_count <= 10 or \
                   orbital == "f" and electron_count <= 14:
                    generated_configs.append(config)
        
        # Ensure we return exactly the requested number of configurations
        # If we generated more, take a random sample
        if len(generated_configs) > count:
            return random.sample(generated_configs, count)
        
        # If we generated fewer, duplicate some (should be rare)
        while len(generated_configs) < count:
            if generated_configs:
                generated_configs.append(random.choice(generated_configs))
            else:
                # Last resort fallback
                generated_configs.append(f"1s² 2s² 2p⁶ 3s{random.choice(['¹', '²'])}")
        
        return generated_configs
    
    def _generate_period_group_question(self):
        """Generate a question about periods and groups"""
        # Choose randomly between period or group question
        is_period_question = random.choice([True, False])
        
        # Filter elements that have both period and group data
        valid_elements = [e for e in self.elements if 'period' in e and 'group' in e and e['group'] is not None]
        element = random.choice(valid_elements)
        
        # Get element name based on current language
        import streamlit as st
        current_lang = st.session_state.language if "language" in st.session_state else "English"
        
        # Format element name with appropriate language
        if current_lang == "Korean" and "korean_name" in element and element["korean_name"]:
            element_name = f"{element['korean_name']} ({element['name']}, {element['symbol']})"
        else:
            # In English mode, still include Korean name if available
            if "korean_name" in element and element["korean_name"]:
                element_name = f"{element['name']} ({element['korean_name']}, {element['symbol']})"
            else:
                element_name = f"{element['name']} ({element['symbol']})"
        
        if is_period_question:
            # Question about period
            correct_answer = element['period']
            question = f"In which period of the periodic table is {element_name}?"
            
            if self.difficulty == "hard":
                # For hard difficulty, create options closer to the correct period
                nearby_periods = list(range(max(1, correct_answer - 2), min(8, correct_answer + 3)))
                if correct_answer in nearby_periods:
                    nearby_periods.remove(correct_answer)
                # Ensure we have at least 3 wrong options
                if len(nearby_periods) < 3:
                    all_periods = list(range(1, 8))
                    all_periods.remove(correct_answer)
                    additional_periods = random.sample([p for p in all_periods if p not in nearby_periods], 
                                                      3 - len(nearby_periods))
                    nearby_periods.extend(additional_periods)
                options = [correct_answer] + random.sample(nearby_periods, 3)
            else:
                # For medium and easy, use all periods as options
                options = list(range(1, 8))
                if correct_answer not in options:
                    options[0] = correct_answer
                    
        else:
            # Question about group
            correct_answer = element['group']
            question = f"In which group of the periodic table is {element_name}?"
            
            if self.difficulty == "hard":
                # For hard difficulty, create options closer to the correct group
                # Create a range of ±3 from the correct group
                nearby_groups = []
                for g in range(max(1, correct_answer - 3), min(19, correct_answer + 4)):
                    # Skip groups 3-12 (transition metals are usually grouped differently)
                    if g not in range(3, 13) or correct_answer in range(3, 13):
                        nearby_groups.append(g)
                
                if correct_answer in nearby_groups:
                    nearby_groups.remove(correct_answer)
                
                # Ensure we have enough options
                if len(nearby_groups) < 3:
                    all_groups = [1, 2, 13, 14, 15, 16, 17, 18]
                    if correct_answer in all_groups:
                        all_groups.remove(correct_answer)
                    additional_groups = random.sample([g for g in all_groups if g not in nearby_groups],
                                                     3 - len(nearby_groups))
                    nearby_groups.extend(additional_groups)
                
                options = [correct_answer] + random.sample(nearby_groups, 3)
            else:
                # For medium and easy, use common groups as options
                options = [1, 2, 13, 14, 15, 16, 17, 18]
                if correct_answer not in options:
                    options[0] = correct_answer
        
        # Ensure we have at most 4 options
        if len(options) > 4:
            # Keep the correct answer and 3 random others
            other_options = [o for o in options if o != correct_answer]
            random_options = random.sample(other_options, 3)
            options = [correct_answer] + random_options
        
        # Shuffle options
        random.shuffle(options)
        
        return {
            'question': question,
            'options': options,
            'correct_answer': correct_answer,
            'element': element
        }

    def _generate_korean_name_text_question(self):
        """Generate a text input question about Korean element names"""
        # Filter elements that have Korean names
        elements_with_korean = [e for e in self.elements if 'korean_name' in e and e['korean_name']]
        if not elements_with_korean:
            # Fallback to regular name question if no elements with Korean names
            return self._generate_name_text_question()
            
        element = random.choice(elements_with_korean)
        
        return {
            'question': f"What is the Korean name of {element['name']} ({element['symbol']})?",
            'correct_answer': element['korean_name'],
            'element': element,
            'input_type': 'text',
            'hint': f"Enter the Korean name (한글로 입력하세요)"
        }
    
    def _generate_description_text_question(self):
        """Generate a text input question about element descriptions"""
        # Get the current language from streamlit session state
        import streamlit as st
        from utils.description_processor import process_korean_description, process_english_description
        
        current_language = st.session_state.language if "language" in st.session_state else "English"
        
        # Filter elements based on the current language
        if current_language == "Korean":
            # In Korean mode, only use elements with Korean descriptions
            elements_with_desc = [e for e in self.elements if 
                                'korean_description' in e and e['korean_description'] and 
                                len(e['korean_description']) > 20]
            if not elements_with_desc:
                # Fallback to name question if no elements with descriptions
                return self._generate_name_text_question()
            
            # Force Korean description
            use_korean = True
        else:
            # In English mode, only use elements with English descriptions
            elements_with_desc = [e for e in self.elements if 
                                'description' in e and e['description'] and 
                                len(e['description']) > 50]
            if not elements_with_desc:
                # Fallback to name question if no elements with descriptions
                return self._generate_name_text_question()
            
            # Force English description
            use_korean = False
        
        element = random.choice(elements_with_desc)
        
        # Get the appropriate description based on current language
        if use_korean:
            raw_desc = element['korean_description']
            desc_language = "Korean"
            
            # Get Korean name if available or use English name
            element_name = element.get('korean_name', element['name'])
            
            # Process the Korean description to remove element hints
            desc = process_korean_description(raw_desc, element_name, element['symbol'])
            
            # Korean question and hint
            question_text = "다음 설명에 해당하는 원소는 무엇인가요?"
            hint = "원소 이름을 입력하세요 (한글 또는 영어)"
        else:
            raw_desc = element['description']
            desc_language = "English"
            
            # Process the English description to remove element hints
            desc = process_english_description(raw_desc, element['name'], element['symbol'])
            
            # English question and hint
            question_text = "Which element is described by this?"
            hint = "Enter element name"
        
        # Use the processed description without further modifications
        snippet = desc
        
        return {
            'question': f"{question_text} '{snippet}'",
            'correct_answer': element['name'],
            'element': element,
            'input_type': 'text',
            'hint': hint
        }

    def _generate_korean_name_question(self):
        """Generate a question about Korean element names"""
        # Filter elements that have Korean names
        elements_with_korean = [e for e in self.elements if 'korean_name' in e and e['korean_name']]
        if not elements_with_korean:
            # Fallback to regular name question if no elements with Korean names
            return self._generate_name_question()
            
        element = random.choice(elements_with_korean)
        
        # Create options with the correct Korean name and 3 random wrong names
        correct_answer = element['korean_name']
        options = [correct_answer]
        
        # Add 3 other random Korean names
        other_elements = [e for e in elements_with_korean if e['korean_name'] != correct_answer]
        if len(other_elements) >= 3:
            random_elements = random.sample(other_elements, 3)
            options.extend([e['korean_name'] for e in random_elements])
        else:
            # If not enough Korean names, use what we have
            for e in other_elements:
                if e['korean_name'] not in options:
                    options.append(e['korean_name'])
        
        # Shuffle options
        random.shuffle(options)
        
        return {
            'question': f"What is the Korean name of {element['name']} ({element['symbol']})?",
            'options': options,
            'correct_answer': correct_answer,
            'element': element
        }
    
    def _generate_description_to_element_question(self):
        """Generate a question where description leads to element name"""
        # Get the current language from streamlit session state
        import streamlit as st
        from utils.description_processor import process_korean_description, process_english_description
        
        current_language = st.session_state.language if "language" in st.session_state else "English"
        
        # Filter elements based on the current language
        if current_language == "Korean":
            # In Korean mode, only use elements with Korean descriptions
            elements_with_desc = [e for e in self.elements if 
                                'korean_description' in e and e['korean_description'] and 
                                len(e['korean_description']) > 20]
            if not elements_with_desc:
                # Fallback to name question if no elements with descriptions
                return self._generate_name_question()
            
            # Force Korean description
            use_korean = True
        else:
            # In English mode, filter elements based on difficulty level
            if self.difficulty == "hard":
                # In hard mode, only use elements with advanced descriptions if available
                elements_with_desc = [e for e in self.elements if 
                                    'advanced_description' in e and e['advanced_description']]
                if not elements_with_desc:
                    # If no advanced descriptions, fall back to elements with any description
                    elements_with_desc = [e for e in self.elements if 
                                        'description' in e and e['description'] and 
                                        len(e['description']) > 50]
            elif self.difficulty == "easy":
                # In easy mode, only use elements with beginner descriptions if available
                elements_with_desc = [e for e in self.elements if 
                                    'beginner_description' in e and e['beginner_description']]
                if not elements_with_desc:
                    # If no beginner descriptions, fall back to elements with any description
                    elements_with_desc = [e for e in self.elements if 
                                        'description' in e and e['description'] and 
                                        len(e['description']) > 50]
            else:  # medium or default
                # In medium mode, use elements with regular descriptions
                elements_with_desc = [e for e in self.elements if 
                                    'description' in e and e['description'] and 
                                    len(e['description']) > 50]
            
            if not elements_with_desc:
                # Fallback to name question if no elements with descriptions
                return self._generate_name_question()
            
            # Force English description
            use_korean = False
        
        element = random.choice(elements_with_desc)
        
        # Get the appropriate description based on current language and difficulty
        if use_korean:
            raw_desc = element['korean_description']
            desc_language = "Korean"
            
            # Get Korean name if available or use English name
            element_name = element.get('korean_name', element['name'])
            
            # Process the Korean description to remove element hints
            desc = process_korean_description(raw_desc, element_name, element['symbol'])
            
            # Question text in Korean
            question_text = "어떤 원소에 대한 설명인가요?"
        else:
            # Choose description based on difficulty level
            if self.difficulty == "hard" and 'advanced_description' in element and element['advanced_description']:
                raw_desc = element['advanced_description']
            elif self.difficulty == "easy" and 'beginner_description' in element and element['beginner_description']:
                raw_desc = element['beginner_description']
            else:
                raw_desc = element['description']
                
            desc_language = "English"
            
            # Process the English description to remove element hints
            desc = process_english_description(raw_desc, element['name'], element['symbol'])
            
            # Question text in English
            question_text = "Which element is described by this?"
        
        # Use the processed description without further modifications
        snippet = desc
        
        # Create options with the correct element name and 3 random wrong names
        correct_answer = element['name']
        options = [correct_answer]
        
        # Add 3 other random element names
        other_elements = [e for e in self.elements if e['name'] != correct_answer]
        random_elements = random.sample(other_elements, 3)
        options.extend([e['name'] for e in random_elements])
        
        # Shuffle options
        random.shuffle(options)
        
        # Store both English name and Korean name as alternative answers
        alternative_answers = [element['name']]
        if 'korean_name' in element and element['korean_name']:
            alternative_answers.append(element['korean_name'])
        
        return {
            'question': f"{question_text} '{snippet}'",
            'options': options,
            'correct_answer': correct_answer,
            'element': element,
            'alternative_answers': alternative_answers  # Add alternative answers
        }
    
    def _generate_element_to_description_question(self):
        """Generate a question where element leads to description"""
        # Get the current language from streamlit session state
        import streamlit as st
        from utils.description_processor import process_korean_description, process_english_description
        
        current_language = st.session_state.language if "language" in st.session_state else "English"
        
        # Filter elements based on the current language
        if current_language == "Korean":
            # In Korean mode, only use elements with Korean descriptions
            elements_with_desc = [e for e in self.elements if 
                                'korean_description' in e and e['korean_description'] and 
                                len(e['korean_description']) > 20]
            if not elements_with_desc:
                # Fallback to category question if no elements with descriptions
                return self._generate_category_question()
            
            # Force Korean description
            use_korean = True
        else:
            # In English mode, filter elements based on difficulty level
            if self.difficulty == "hard":
                # In hard mode, only use elements with advanced descriptions if available
                elements_with_desc = [e for e in self.elements if 
                                    'advanced_description' in e and e['advanced_description']]
                if not elements_with_desc:
                    # If no advanced descriptions, fall back to elements with any description
                    elements_with_desc = [e for e in self.elements if 
                                        'description' in e and e['description'] and 
                                        len(e['description']) > 50]
            elif self.difficulty == "easy":
                # In easy mode, only use elements with beginner descriptions if available
                elements_with_desc = [e for e in self.elements if 
                                    'beginner_description' in e and e['beginner_description']]
                if not elements_with_desc:
                    # If no beginner descriptions, fall back to elements with any description
                    elements_with_desc = [e for e in self.elements if 
                                        'description' in e and e['description'] and 
                                        len(e['description']) > 50]
            else:  # medium or default
                # In medium mode, use elements with regular descriptions
                elements_with_desc = [e for e in self.elements if 
                                    'description' in e and e['description'] and 
                                    len(e['description']) > 50]
            
            if not elements_with_desc:
                # Fallback to category question if no elements with descriptions
                return self._generate_category_question()
            
            # Force English description
            use_korean = False
        
        element = random.choice(elements_with_desc)
        
        # Get the appropriate description based on current language and difficulty
        if use_korean:
            raw_desc = element['korean_description']
            desc_language = "Korean"
            
            # Get Korean name if available or use English name
            element_name = element.get('korean_name', element['name'])
            
            # Process the Korean description to remove element hints
            desc = process_korean_description(raw_desc, element_name, element['symbol'])
            
            # Question text in Korean
            question_text = f"다음 중 {element['name']} ({element['symbol']})에 대한 가장 적절한 설명은?"
        else:
            # Choose description based on difficulty level
            if self.difficulty == "hard" and 'advanced_description' in element and element['advanced_description']:
                raw_desc = element['advanced_description']
            elif self.difficulty == "easy" and 'beginner_description' in element and element['beginner_description']:
                raw_desc = element['beginner_description']
            else:
                raw_desc = element['description']
                
            desc_language = "English"
            
            # Process the English description to remove element hints
            desc = process_english_description(raw_desc, element['name'], element['symbol'])
            
            # Question text in English
            question_text = f"Which description best matches {element['name']} ({element['symbol']})?"
        
        # Use the processed description without further modifications
        correct_snippet = desc
            
        options = [correct_snippet]
        
        # Add 3 other random description snippets (also processed)
        other_elements = [e for e in elements_with_desc if e['name'] != element['name']]
        
        if len(other_elements) >= 3:
            random_elements = random.sample(other_elements, 3)
            
            for e in random_elements:
                # Important: Use same language as the main question for consistency
                if use_korean:
                    # Get Korean description
                    if 'korean_description' in e and e['korean_description']:
                        raw_other_desc = e['korean_description']
                        # Get Korean name if available
                        other_element_name = e.get('korean_name', e['name'])
                        # Process Korean description
                        other_desc = process_korean_description(raw_other_desc, other_element_name, e['symbol'])
                    else:
                        # Skip this element if it doesn't have a Korean description
                        continue
                else:
                    # Get English description
                    if 'description' in e and e['description']:
                        raw_other_desc = e['description']
                        # Process English description
                        other_desc = process_english_description(raw_other_desc, e['name'], e['symbol'])
                    else:
                        # Skip this element if it doesn't have an English description
                        continue
                
                # Use the processed description without truncating
                other_snippet = other_desc
                
                # Only add if it's not too similar to existing options
                if other_snippet not in options:
                    options.append(other_snippet)
                
                # Once we have 4 total options, break
                if len(options) >= 4:
                    break
        
        # If we still don't have enough options, add some more from other elements
        while len(options) < 4 and other_elements:
            e = random.choice(other_elements)
            other_elements.remove(e)  # Remove so we don't pick it again
            
            # Use same language as main question
            if use_korean:
                if 'korean_description' in e and e['korean_description']:
                    raw_other_desc = e['korean_description']
                    other_element_name = e.get('korean_name', e['name'])
                    other_desc = process_korean_description(raw_other_desc, other_element_name, e['symbol'])
                else:
                    continue
            else:
                if 'description' in e and e['description']:
                    raw_other_desc = e['description']
                    other_desc = process_english_description(raw_other_desc, e['name'], e['symbol'])
                else:
                    continue
            
            other_snippet = other_desc
            
            if other_snippet not in options:
                options.append(other_snippet)
        
        # Shuffle options for randomized presentation
        random.shuffle(options)
        
        return {
            'question': question_text,
            'options': options,
            'correct_answer': correct_snippet,
            'element': element
        }

def evaluate_answer(question, selected_answer):
    """Evaluate if the selected answer is correct"""
    if not question or 'correct_answer' not in question:
        return False
    
    # Check for alternative answers (like Korean names)
    if 'alternative_answers' in question and isinstance(question['alternative_answers'], list):
        # For text input questions with alternative answers
        if isinstance(selected_answer, str):
            selected = selected_answer.lower().strip()
            # Check if the answer matches any of the alternatives
            for alt_answer in question['alternative_answers']:
                if isinstance(alt_answer, str) and selected == alt_answer.lower().strip():
                    return True
    
    # Handle text comparison (case-insensitive for text)
    if isinstance(selected_answer, str) and isinstance(question['correct_answer'], str):
        return selected_answer.lower().strip() == question['correct_answer'].lower().strip()
    
    # Handle numeric comparison
    return selected_answer == question['correct_answer']

def get_quiz_statistics():
    """Get statistics about quiz performance"""
    if 'quiz_total' not in st.session_state or st.session_state.quiz_total == 0:
        return {
            'correct': 0,
            'total': 0,
            'percentage': 0,
            'history': []
        }
    
    return {
        'correct': st.session_state.quiz_score,
        'total': st.session_state.quiz_total,
        'percentage': round((st.session_state.quiz_score / st.session_state.quiz_total) * 100, 1),
        'history': st.session_state.quiz_history
    }

def reset_quiz_statistics():
    """Reset the quiz statistics"""
    st.session_state.quiz_score = 0
    st.session_state.quiz_total = 0
    st.session_state.quiz_history = []
    

