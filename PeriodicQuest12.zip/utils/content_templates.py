"""
Module for managing content templates for the Science Learning Platform.
This module provides templates and helper functions for generating content
without relying on external AI APIs.
"""
import random
import json
from typing import List, Dict, Any, Optional

# Sample topic templates by category
TOPIC_TEMPLATES = {
    "Chemistry": [
        {
            "title": "Introduction to Chemical Bonds",
            "description": "Explore the different types of chemical bonds and how they form between atoms.",
            "icon": "⚛️",
            "sections": [
                {
                    "title": "What are Chemical Bonds?",
                    "content_type": "text",
                    "content": """Chemical bonds are the forces of attraction that hold atoms together to form molecules. They are crucial for understanding the properties and behavior of substances.
                    
The main types of chemical bonds include:
1. Ionic bonds: Form when electrons are transferred between atoms
2. Covalent bonds: Form when atoms share electrons
3. Metallic bonds: Form between metal atoms"""
                },
                {
                    "title": "Ionic Bonds",
                    "content_type": "text",
                    "content": """Ionic bonds form between metals and non-metals when electrons are transferred from the metal to the non-metal.
                    
For example, sodium (Na) and chlorine (Cl) form an ionic bond in table salt (NaCl). Sodium gives up one electron to chlorine, resulting in Na+ and Cl- ions that are attracted to each other."""
                },
                {
                    "title": "Bond Strength Comparison",
                    "content_type": "chart",
                    "chart_type": "bar",
                    "title": "Bond Strength Comparison",
                    "x_label": "Bond Type",
                    "y_label": "Bond Energy (kJ/mol)",
                    "x_data": ["Ionic", "Covalent", "Hydrogen", "Van der Waals"],
                    "y_data": [700, 400, 20, 5]
                }
            ],
            "quiz_questions": [
                {
                    "question_text": "Which type of bond forms when electrons are transferred between atoms?",
                    "question_type": "multiple_choice",
                    "options": ["Ionic bond", "Covalent bond", "Hydrogen bond", "Metallic bond"],
                    "correct_answer": "Ionic bond",
                    "explanation": "Ionic bonds form when one atom transfers electrons to another atom, creating oppositely charged ions that attract each other."
                },
                {
                    "question_text": "In a covalent bond, what is shared between atoms?",
                    "question_type": "multiple_choice",
                    "options": ["Electrons", "Protons", "Neutrons", "Ions"],
                    "correct_answer": "Electrons",
                    "explanation": "Covalent bonds form when atoms share electron pairs, allowing each atom to achieve a stable electron configuration."
                }
            ]
        },
        {
            "title": "The Periodic Table Patterns",
            "description": "Learn about the organization and patterns in the periodic table of elements.",
            "icon": "🧪",
            "sections": [
                {
                    "title": "Periodic Table Organization",
                    "content_type": "text",
                    "content": """The periodic table is organized based on atomic number (number of protons) and electron configuration.
                    
Elements are arranged in:
- Periods (rows): Elements in the same period have the same number of electron shells
- Groups (columns): Elements in the same group have similar chemical properties"""
                },
                {
                    "title": "Trends in the Periodic Table",
                    "content_type": "text",
                    "content": """The periodic table exhibits several important trends:

1. Atomic radius: Generally decreases across a period and increases down a group
2. Electronegativity: Generally increases across a period and decreases down a group
3. Ionization energy: Generally increases across a period and decreases down a group"""
                }
            ],
            "quiz_questions": [
                {
                    "question_text": "What determines the position of an element in the periodic table?",
                    "question_type": "multiple_choice",
                    "options": ["Atomic number", "Atomic mass", "Number of neutrons", "Number of electrons"],
                    "correct_answer": "Atomic number",
                    "explanation": "Elements in the periodic table are arranged in order of increasing atomic number, which is the number of protons in the nucleus."
                }
            ]
        }
    ],
    "Physics": [
        {
            "title": "Basics of Motion",
            "description": "Understand the fundamental concepts of motion, velocity, and acceleration.",
            "icon": "🚀",
            "sections": [
                {
                    "title": "Distance vs. Displacement",
                    "content_type": "text",
                    "content": """Distance is a scalar quantity that refers to how much ground an object has covered during its motion.
                    
Displacement is a vector quantity that refers to how far out of place an object is. It is the object's overall change in position."""
                },
                {
                    "title": "Velocity vs. Speed",
                    "content_type": "text",
                    "content": """Speed is a scalar quantity that refers to how fast an object is moving.
                    
Velocity is a vector quantity that refers to the rate at which an object changes its position in a specific direction."""
                },
                {
                    "title": "Distance-Time Graph",
                    "content_type": "chart",
                    "chart_type": "line",
                    "title": "Distance-Time Graph for Different Types of Motion",
                    "x_label": "Time (s)",
                    "y_label": "Distance (m)",
                    "x_data": [0, 1, 2, 3, 4, 5],
                    "y_data": [0, 5, 10, 15, 20, 25]
                }
            ],
            "quiz_questions": [
                {
                    "question_text": "What is the difference between speed and velocity?",
                    "question_type": "multiple_choice",
                    "options": [
                        "Speed is scalar, velocity is vector",
                        "Speed is faster than velocity",
                        "Velocity is always positive, speed can be negative",
                        "There is no difference"
                    ],
                    "correct_answer": "Speed is scalar, velocity is vector",
                    "explanation": "Speed is a scalar quantity that only considers how fast an object moves. Velocity is a vector quantity that considers both speed and direction."
                }
            ]
        }
    ],
    "Biology": [
        {
            "title": "Cell Structure and Function",
            "description": "Explore the basic unit of life: the cell, and understand its components and functions.",
            "icon": "🧫",
            "sections": [
                {
                    "title": "Types of Cells",
                    "content_type": "text",
                    "content": """There are two basic types of cells:
                    
1. Prokaryotic cells: Simpler, smaller cells without a nucleus or membrane-bound organelles (e.g., bacteria)
2. Eukaryotic cells: More complex cells with a nucleus and membrane-bound organelles (e.g., plant and animal cells)"""
                },
                {
                    "title": "Cell Organelles",
                    "content_type": "text",
                    "content": """Eukaryotic cells contain various organelles, each with specific functions:

- Nucleus: Controls cell activities and contains genetic material
- Mitochondria: Produces energy (ATP) through cellular respiration
- Endoplasmic reticulum: Synthesizes proteins and lipids
- Golgi apparatus: Modifies, sorts, and packages proteins for transport
- Lysosomes: Contain digestive enzymes for breaking down waste"""
                },
                {
                    "title": "Cell Size Comparison",
                    "content_type": "chart",
                    "chart_type": "bar",
                    "title": "Average Cell Size Comparison",
                    "x_label": "Cell Type",
                    "y_label": "Size (micrometers)",
                    "x_data": ["Bacterial cell", "Red blood cell", "Nerve cell", "Egg cell"],
                    "y_data": [1, 8, 100, 130]
                }
            ],
            "quiz_questions": [
                {
                    "question_text": "Which organelle is responsible for producing energy in the cell?",
                    "question_type": "multiple_choice",
                    "options": ["Mitochondria", "Nucleus", "Golgi apparatus", "Endoplasmic reticulum"],
                    "correct_answer": "Mitochondria",
                    "explanation": "Mitochondria are often called the 'powerhouse of the cell' because they produce ATP (adenosine triphosphate), the main energy currency of the cell, through cellular respiration."
                }
            ]
        }
    ],
    "Astronomy": [
        {
            "title": "Our Solar System",
            "description": "Learn about the Sun, planets, and other objects that make up our solar system.",
            "icon": "🪐",
            "sections": [
                {
                    "title": "The Sun and Planets",
                    "content_type": "text",
                    "content": """Our solar system consists of the Sun and everything that orbits around it, including:

- 8 planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune
- Dwarf planets: Pluto, Ceres, Eris, and others
- Moons: 200+ natural satellites orbiting the planets
- Asteroids, comets, and meteors"""
                },
                {
                    "title": "Types of Planets",
                    "content_type": "text",
                    "content": """The planets in our solar system can be classified into two main types:

1. Terrestrial planets: The four inner planets (Mercury, Venus, Earth, Mars) that are small, rocky, and dense
2. Gas giants: The four outer planets (Jupiter, Saturn, Uranus, Neptune) that are large, gaseous, and less dense"""
                },
                {
                    "title": "Planet Sizes",
                    "content_type": "chart",
                    "chart_type": "bar",
                    "title": "Relative Diameters of Planets",
                    "x_label": "Planet",
                    "y_label": "Equatorial Diameter (km)",
                    "x_data": ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"],
                    "y_data": [4879, 12104, 12756, 6792, 142984, 120536, 51118, 49528]
                }
            ],
            "quiz_questions": [
                {
                    "question_text": "Which planet is the largest in our solar system?",
                    "question_type": "multiple_choice",
                    "options": ["Jupiter", "Saturn", "Neptune", "Uranus"],
                    "correct_answer": "Jupiter",
                    "explanation": "Jupiter is the largest planet in our solar system with a diameter of about 143,000 km, more than 11 times the diameter of Earth."
                }
            ]
        }
    ]
}

def get_topic_categories() -> List[str]:
    """Get a list of all available topic categories
    
    Returns:
        List[str]: List of category names
    """
    return list(TOPIC_TEMPLATES.keys())

def get_topics_by_category(category: str) -> List[Dict[str, Any]]:
    """Get a list of topic templates for a given category
    
    Args:
        category (str): The category name
        
    Returns:
        List[Dict[str, Any]]: List of topic templates
    """
    return TOPIC_TEMPLATES.get(category, [])

def get_all_topics() -> List[Dict[str, Any]]:
    """Get a list of all available topic templates
    
    Returns:
        List[Dict[str, Any]]: List of all topic templates
    """
    all_topics = []
    for category in TOPIC_TEMPLATES:
        all_topics.extend(TOPIC_TEMPLATES[category])
    return all_topics

def get_random_topics(count: int = 5) -> List[Dict[str, Any]]:
    """Get a random selection of topic templates
    
    Args:
        count (int): Number of random topics to return
        
    Returns:
        List[Dict[str, Any]]: List of random topic templates
    """
    all_topics = get_all_topics()
    if count >= len(all_topics):
        return all_topics
    return random.sample(all_topics, count)

def get_similar_topics(keyword: str, count: int = 5) -> List[Dict[str, Any]]:
    """Get topics that match a keyword
    
    Args:
        keyword (str): Keyword to search for in topic titles and descriptions
        count (int): Maximum number of topics to return
        
    Returns:
        List[Dict[str, Any]]: List of matching topic templates
    """
    keyword = keyword.lower()
    matching_topics = []
    
    for category in TOPIC_TEMPLATES:
        for topic in TOPIC_TEMPLATES[category]:
            if (keyword in topic['title'].lower() or 
                keyword in topic['description'].lower()):
                matching_topics.append(topic)
    
    if count >= len(matching_topics):
        return matching_topics
    return matching_topics[:count]

def generate_content_section(section_type: str = "text") -> Dict[str, Any]:
    """
    Generate a template for a new content section
    
    Args:
        section_type (str): Type of content to generate - 'text' or 'chart_data'
        
    Returns:
        Dict[str, Any]: Template for the section
    """
    if section_type == "text":
        return {
            "title": "New Section",
            "content_type": "text",
            "content": "Add your content here. This can include explanations, definitions, examples, and more."
        }
    elif section_type == "chart_data":
        return {
            "title": "Data Visualization",
            "content_type": "chart",
            "chart_type": "bar",
            "title": "Chart Title",
            "x_label": "X-Axis Label",
            "y_label": "Y-Axis Label",
            "x_data": ["Category 1", "Category 2", "Category 3", "Category 4", "Category 5"],
            "y_data": [10, 25, 15, 30, 20]
        }
    else:
        return {"error": "Unsupported content section type"}

def generate_quiz_questions(topic_title: str, difficulty: str = "medium", count: int = 5) -> List[Dict[str, Any]]:
    """
    Generate template quiz questions
    
    Args:
        topic_title (str): The title of the topic
        difficulty (str): Difficulty level - 'easy', 'medium', or 'hard'
        count (int): Number of questions to generate
        
    Returns:
        List[Dict[str, Any]]: List of template quiz questions
    """
    # Basic templates for different question types
    multiple_choice_template = {
        "question_text": "Question text goes here?",
        "question_type": "multiple_choice",
        "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
        "correct_answer": "Option 1",
        "explanation": "Explanation of the correct answer"
    }
    
    text_input_template = {
        "question_text": "Question text goes here?",
        "question_type": "text_input",
        "correct_answer": "Answer",
        "explanation": "Explanation of the correct answer"
    }
    
    # Create specified number of questions alternating between types
    questions = []
    for i in range(count):
        if i % 2 == 0:
            question = multiple_choice_template.copy()
            question["question_text"] = f"Multiple-choice question {i+1} about {topic_title}?"
        else:
            question = text_input_template.copy()
            question["question_text"] = f"Short-answer question {i+1} about {topic_title}?"
        
        questions.append(question)
    
    return questions