"""
Module to process element descriptions for quizzes.
"""

import re

def process_korean_description(desc, element_name=None, symbol=None):
    """Process Korean descriptions to remove element hints
    
    Args:
        desc (str): Element description in Korean
        element_name (str, optional): Element name to remove from description
        symbol (str, optional): Element symbol to remove from description
        
    Returns:
        str: Processed description with sensitive information hidden
    """
    if not desc:
        return ""
    
    # Step 1: Remove standard prefixes that reveal element identities
    # Remove the common pattern "X는/은 원자 번호 Y번(의) 화학 원소이다"
    desc = re.sub(r'^[가-힣]+[은는]\s*원자\s*번호\s*\d+[번]?[의]?\s*화학\s*원소[이]?[다]?\.?\s*', '', desc)
    
    # Remove similar patterns with element name
    if element_name and element_name:
        korean_name = element_name
        if symbol:
            # Also try with symbol pattern "X(Y)"
            symbol_pattern = f"{korean_name}\\({symbol}\\)"
            desc = re.sub(symbol_pattern, '', desc, flags=re.IGNORECASE)
        
        # Remove element name directly 
        desc = re.sub(re.escape(korean_name), '', desc, flags=re.IGNORECASE)
    
    # Step 2: Remove all atomic number references
    desc = re.sub(r'[가-힣]+[은는]\s*원자\s*번호\s*\d+', '', desc)
    desc = re.sub(r'원자\s*번호\s*\d+', '', desc)
    desc = re.sub(r'\d+번\s*원소', '', desc)
    desc = re.sub(r'\d+번째\s*원소', '', desc)
    
    # Step 3: Remove symbol references
    if symbol:
        desc = re.sub(r'기호\s*' + re.escape(symbol), '', desc, flags=re.IGNORECASE)
        desc = re.sub(r'심볼\s*' + re.escape(symbol), '', desc, flags=re.IGNORECASE)
        desc = re.sub(r'원소\s*기호\s*' + re.escape(symbol), '', desc, flags=re.IGNORECASE)
    
    # Step 4: Remove period and group references that could give away identity
    desc = re.sub(r'\d+주기\s*\d+족', '주기율표상', desc)
    desc = re.sub(r'\d+족', '주기율표의 한 족', desc)
    desc = re.sub(r'\d+주기', '주기율표의 한 주기', desc)
    
    # Step 5: Clean up punctuation and whitespace after our removals
    desc = desc.strip()
    desc = re.sub(r'^[.,;:\s]+', '', desc)  # Remove leading punctuation
    desc = re.sub(r'^\s*,\s*', '', desc)    # Remove leading commas
    desc = re.sub(r'\s{2,}', ' ', desc)     # Replace multiple spaces with single space
    
    # If the result is too short after processing, it might not be useful
    if len(desc) < 10:
        return "이 원소에 대한 설명을 참조하십시오."
    
    return desc

def process_english_description(desc, element_name=None, symbol=None):
    """Process English descriptions to remove element hints
    
    Args:
        desc (str): Element description in English
        element_name (str, optional): Element name to remove from description
        symbol (str, optional): Element symbol to remove from description
        
    Returns:
        str: Processed description with sensitive information hidden
    """
    # Remove element name from description if provided
    if element_name:
        name_pattern = re.compile(r'\b' + re.escape(element_name) + r'\b', re.IGNORECASE)
        desc = name_pattern.sub("[ELEMENT]", desc)
    
    # Remove element symbol if provided
    if symbol:
        symbol_pattern = re.compile(r'\b' + re.escape(symbol) + r'\b')
        desc = symbol_pattern.sub("[SYMBOL]", desc)
    
    # Remove common prefixes about chemical elements
    desc = re.sub(r'^.*?(is a chemical element|chemical element with|with the symbol|atomic number|is an element|has an atomic number|is a metallic element|is a nonmetal)[^.]*\.','', desc, flags=re.IGNORECASE)
    
    # Remove secondary sentences that might contain generic information
    desc = re.sub(r'(It is|It was|It has|It can|This element|The element) (a chemical element|an element with|with symbol)[^.]*\.','', desc, flags=re.IGNORECASE)
    
    # Remove specific mentions of atomic number
    desc = re.sub(r'atomic number\s*\d+', '[ATOMIC NUMBER]', desc, flags=re.IGNORECASE)
    desc = re.sub(r'atomic number\s*of\s*\d+', '[ATOMIC NUMBER]', desc, flags=re.IGNORECASE)
    desc = re.sub(r'with atomic number \d+', '', desc, flags=re.IGNORECASE)
    
    # Clean up any leading spaces or punctuation
    desc = desc.strip()
    desc = re.sub(r'^[.,;:\s]+', '', desc)
    
    return desc