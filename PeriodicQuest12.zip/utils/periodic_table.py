"""
Module for creating an interactive periodic table visualization.
"""

import plotly.graph_objects as go
import pandas as pd
import numpy as np
import streamlit as st
from data.elements import elements_df, CATEGORIES, get_element_color

def create_periodic_table(highlight_atomic_number=None, mobile_mode=False):
    """Create an interactive periodic table using Plotly
    
    Args:
        highlight_atomic_number (int, optional): Atomic number of element to highlight
        mobile_mode (bool, optional): Whether to use mobile-friendly layout
        
    Returns:
        go.Figure: The interactive periodic table figure
    """
    # Create a copy of the elements dataframe
    df = elements_df.copy()
    
    # Replace NaN values with empty strings for hover text
    df = df.fillna('')
    
    # Add a column to track if an element should be highlighted
    df['highlighted'] = False
    
    # Set the highlighted element if provided
    if highlight_atomic_number is not None:
        df.loc[df['atomic_number'] == highlight_atomic_number, 'highlighted'] = True
    
    # Create hover text
    hover_text = []
    for i, row in df.iterrows():
        # Add Korean name if available
        korean_display = f"Korean Name: {row['korean_name']}<br>" if row.get('korean_name', '') else ""
        
        hover_text.append(
            f"<b>{row['name']} ({row['symbol']})</b><br>" +
            f"Atomic Number: {row['atomic_number']}<br>" +
            f"Atomic Weight: {row['atomic_weight']}<br>" +
            f"Category: {row['category']}<br>" +
            korean_display +
            (f"Electron Config: {row['electron_configuration']}<br>" if row['electron_configuration'] else "")
        )
    
    # Create a grid for positioning elements
    # Add empty cells for lanthanides and actinides
    x_positions = []
    y_positions = []
    
    for _, row in df.iterrows():
        group = row['group'] if row['group'] is not None else 3
        period = row['period']
        
        # Adjust for lanthanides and actinides
        if 57 <= row['atomic_number'] <= 71:  # Lanthanides
            x_pos = row['atomic_number'] - 57 + 3
            y_pos = 8.5  # Below the main table
        elif 89 <= row['atomic_number'] <= 103:  # Actinides
            x_pos = row['atomic_number'] - 89 + 3
            y_pos = 9.5  # Below lanthanides
        else:
            x_pos = group
            y_pos = period
        
        x_positions.append(x_pos)
        y_positions.append(y_pos)
    
    # Add x and y positions to DataFrame
    df['x'] = x_positions
    df['y'] = y_positions
    
    # Get colors based on categories
    df['color'] = df['category'].apply(get_element_color)
    
    # Create the figure
    fig = go.Figure()
    
    # Add rectangles for each element first (so they're behind the text)
    for i, row in df.iterrows():
        # Set different border style for highlighted element
        if row['highlighted']:
            # Highlighted element gets a thicker border and different style
            line_color = 'red'
            line_width = 3
            line_dash = 'solid'
            opacity = 1.0
        else:
            # Normal elements get standard styling
            line_color = 'black'
            line_width = 1
            line_dash = None
            opacity = 0.8
            
        fig.add_shape(
            type='rect',
            x0=row['x'] - 0.45,
            y0=row['y'] - 0.45,
            x1=row['x'] + 0.45,
            y1=row['y'] + 0.45,
            fillcolor=row['color'],
            opacity=opacity,
            line=dict(
                color=line_color,
                width=line_width,
                dash=line_dash
            )
        )
    
    # Add text for atomic numbers at the top of each element box
    fig.add_trace(go.Scatter(
        x=df['x'],
        y=df['y'] - 0.25,  # Position at the bottom of the box
        mode='text',
        text=df['atomic_number'],
        textfont=dict(
            family='Arial',
            size=9,
            color='black'
        ),
        hoverinfo='none'
    ))
    
    # Add element symbols (main element identifier)
    fig.add_trace(go.Scatter(
        x=df['x'],
        y=df['y'],
        mode='text',
        text=df['symbol'],
        hovertext=hover_text,
        hoverinfo='text',
        textfont=dict(
            family='Arial',
            size=16,  # Larger font for better visibility
            color='black',
            weight='bold'  # Make symbols bold
        ),
        customdata=df[['atomic_number', 'name']].values,  # Add custom data for click events
        # Ensure clicks are properly detected
        marker=dict(
            opacity=0,       # Transparent markers but still clickable
            size=20,         # Large enough to be easily clickable
            line=dict(width=0)
        ),
    ))
    
    # Add element names in smaller text below the symbols
    fig.add_trace(go.Scatter(
        x=df['x'],
        y=df['y'] + 0.25,  # Position below the symbol
        mode='text',
        text=[name[:8] + "..." if len(name) > 8 else name for name in df['name']],  # Truncate long names
        textfont=dict(
            family='Arial',
            size=7,  # Small size for the names
            color='black'
        ),
        hoverinfo='none'
    ))
    
    # Add annotations for lanthanides and actinides
    fig.add_annotation(
        x=2,
        y=8.5,
        text="Lanthanides",
        showarrow=False,
        font=dict(size=12, color='black'),
        xshift=-50,
        bgcolor='rgba(206, 145, 120, 0.3)',  # Light background color for visibility
        bordercolor='black',
        borderwidth=1,
        borderpad=4,
        opacity=0.8
    )
    
    fig.add_annotation(
        x=2,
        y=9.5,
        text="Actinides",
        showarrow=False,
        font=dict(size=12, color='black'),
        xshift=-50,
        bgcolor='rgba(163, 164, 168, 0.3)',  # Light background color for visibility
        bordercolor='black',
        borderwidth=1,
        borderpad=4,
        opacity=0.8
    )
    
    # We'll remove the legend from the plot as we have a separate category display
    # in the Streamlit interface below the periodic table
    
    # Set default values
    width = 1000 if mobile_mode else None
    
    # Define layout settings based on mobile mode
    if mobile_mode:
        # Mobile-friendly layout with much smaller scale for scrollability
        title_text = 'Periodic Table (Mobile View - Scroll to See All)'
        height = 450  # Very compact height for mobile screens
        # width is already set to 1000 above
        title_font_size = 14
        
        # Modify text sizes for mobile
        for trace in fig.data:
            if hasattr(trace, 'textfont') and trace.textfont is not None:
                if trace.textfont.size == 16:  # Element symbols
                    trace.textfont.size = 10  # Smaller symbols
                elif trace.textfont.size == 7:  # Element names
                    trace.textfont.size = 4    # Very small names or remove
                elif trace.textfont.size == 9:  # Atomic numbers
                    trace.textfont.size = 6    # Smaller atomic numbers
        
        # Special adjustments for lanthanides/actinides text
        for annotation in fig.layout.annotations:
            annotation.font.size = 8
            
        # Adjust margins for mobile view - minimal margins
        margins = dict(
            l=2,   # Minimal left margin
            r=2,   # Minimal right margin
            b=40,  # Smaller bottom margin
            t=30,  # Smaller top margin
            pad=0  # No padding
        )
        
    else:
        # Desktop layout (normal)
        title_text = 'Interactive Periodic Table of Elements'
        height = 800
        title_font_size = 20
        margins = dict(
            l=50,
            r=50,
            b=150,  # Increase bottom margin for lanthanides and actinides
            t=100,
            pad=4
        )
    
    # Update layout with the appropriate settings
    layout_args = {
        'title': title_text,
        'title_font_size': title_font_size,
        'height': height,
        'showlegend': False,
        'plot_bgcolor': 'rgba(0,0,0,0)',
        'margin': margins,
        'xaxis': dict(
            showgrid=False,
            zeroline=False,
            showticklabels=False,
            range=[0, 19],
            fixedrange=True  # Prevent zooming on all devices
        ),
        'yaxis': dict(
            showgrid=False,
            zeroline=False,
            showticklabels=False,
            range=[11, 0],  # Extend range to show lanthanides and actinides
            fixedrange=True  # Prevent zooming on all devices
        ),
        'hovermode': 'closest',
        'dragmode': 'pan' if mobile_mode else False,  # Enable pan on mobile
        'clickmode': 'event',  # Ensure click events are properly captured
        'paper_bgcolor': 'rgba(240,240,240,0.1)',
        'hoverlabel': dict(
            bgcolor='white',
            font_size=14,
            font_family='Arial'
        )
    }
    
    # For mobile mode, set a fixed width to ensure we have a scrollable table
    if mobile_mode:
        layout_args['width'] = width
        layout_args['autosize'] = False
    else:
        layout_args['autosize'] = True
    
    fig.update_layout(**layout_args)
    
    return fig
