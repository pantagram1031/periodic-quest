"""
AI Helper module for the Science Learning Platform.
This module provides integration with OpenAI's GPT models to help users
generate custom learning content and quizzes.
"""
import os
import json
import streamlit as st
from typing import List, Dict, Any, Optional
from openai import OpenAI

# Initialize OpenAI client
def get_openai_client():
    """Get OpenAI client with API key from environment variables"""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        return None
    return OpenAI(api_key=api_key)

def has_api_key():
    """Check if OpenAI API key is available"""
    return os.environ.get("OPENAI_API_KEY") is not None

def generate_topic_ideas(subject: str, count: int = 5) -> List[Dict[str, str]]:
    """
    Generate custom topic ideas based on a subject
    
    Args:
        subject (str): The subject to generate topics for
        count (int): Number of topic ideas to generate
        
    Returns:
        List[Dict[str, str]]: List of topic ideas with title, description, and icon
    """
    if not has_api_key():
        return [{"error": "No OpenAI API key provided"}]
    
    client = get_openai_client()
    
    prompt = f"""Generate {count} interesting and educational topic ideas for a science learning platform about {subject}.
    
    For each topic, provide:
    1. A short, catchy title (max 50 characters)
    2. A brief description (2-3 sentences)
    3. An appropriate emoji icon
    
    Format the response as a JSON array with objects containing 'title', 'description', and 'icon' keys.
    """
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[{"role": "system", "content": "You are a helpful educational content creator assistant."},
                     {"role": "user", "content": prompt}],
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        if "topics" in result:
            return result["topics"]
        return result
    except Exception as e:
        return [{"error": f"Failed to generate topic ideas: {str(e)}"}]

def generate_content_section(topic_title: str, section_type: str = "text") -> Dict[str, Any]:
    """
    Generate content for a section of a custom topic
    
    Args:
        topic_title (str): The title of the topic
        section_type (str): Type of content to generate - 'text', 'chart_data', etc.
        
    Returns:
        Dict[str, Any]: Generated content for the section
    """
    if not has_api_key():
        return {"error": "No OpenAI API key provided"}
    
    client = get_openai_client()
    
    if section_type == "text":
        prompt = f"""Create an educational text section about '{topic_title}' for a science learning platform.
        
        The text should be:
        1. Informative and accurate
        2. Written for high school students
        3. 2-3 paragraphs long
        4. Include key concepts and interesting facts
        
        Format the response as a JSON object with 'title' and 'content' keys.
        """
    elif section_type == "chart_data":
        prompt = f"""Create data for a chart about '{topic_title}' for a science learning platform.
        
        The data should:
        1. Be relevant to the topic
        2. Be suitable for visualization (e.g. bar chart, line chart)
        3. Include a title for the chart
        4. Include labels for x and y axes
        5. Include 5-10 data points
        
        Format the response as a JSON object with 'chart_type', 'title', 'x_label', 'y_label', 'x_data', and 'y_data' keys.
        """
    else:
        return {"error": "Unsupported content section type"}
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[{"role": "system", "content": "You are a helpful educational content creator assistant."},
                     {"role": "user", "content": prompt}],
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        return result
    except Exception as e:
        return {"error": f"Failed to generate content: {str(e)}"}

def generate_quiz_questions(topic_title: str, difficulty: str = "medium", count: int = 5) -> List[Dict[str, Any]]:
    """
    Generate quiz questions for a custom topic
    
    Args:
        topic_title (str): The title of the topic
        difficulty (str): Difficulty level - 'easy', 'medium', or 'hard'
        count (int): Number of questions to generate
        
    Returns:
        List[Dict[str, Any]]: List of generated quiz questions
    """
    if not has_api_key():
        return [{"error": "No OpenAI API key provided"}]
    
    client = get_openai_client()
    
    prompt = f"""Create {count} {difficulty} difficulty quiz questions about '{topic_title}' for a science learning platform.
    
    For each question:
    1. Provide a clear question text
    2. For multiple-choice questions, provide 4 options including the correct answer
    3. Clearly indicate the correct answer
    4. Include a brief explanation of why the answer is correct
    
    Create a mix of multiple-choice and text input questions.
    
    Format the response as a JSON array with objects containing:
    - 'question_text': The question
    - 'question_type': Either 'multiple_choice' or 'text_input'
    - 'options': Array of options (for multiple_choice only)
    - 'correct_answer': The correct answer
    - 'explanation': Why the answer is correct
    """
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[{"role": "system", "content": "You are a helpful educational quiz creator assistant."},
                     {"role": "user", "content": prompt}],
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        if "questions" in result:
            return result["questions"]
        return result
    except Exception as e:
        return [{"error": f"Failed to generate quiz questions: {str(e)}"}]

def improve_quiz_question(question: Dict[str, Any]) -> Dict[str, Any]:
    """
    Improve an existing quiz question with better wording, options, etc.
    
    Args:
        question (Dict[str, Any]): The existing question to improve
        
    Returns:
        Dict[str, Any]: Improved version of the question
    """
    if not has_api_key():
        return {"error": "No OpenAI API key provided"}
    
    client = get_openai_client()
    
    question_json = json.dumps(question)
    
    prompt = f"""Improve the following quiz question to make it clearer, more educational, and more engaging:
    
    {question_json}
    
    Maintain the same question type, but feel free to:
    1. Clarify the wording
    2. Make the options more plausible (for multiple-choice)
    3. Enhance the explanation
    4. Fix any factual errors
    
    Return the improved question in the same JSON format.
    """
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[{"role": "system", "content": "You are a helpful educational quiz creator assistant."},
                     {"role": "user", "content": prompt}],
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        return result
    except Exception as e:
        return {"error": f"Failed to improve quiz question: {str(e)}"}

def chat_with_ai_helper(messages: List[Dict[str, str]], system_prompt: Optional[str] = None) -> str:
    """
    Generic chat interface with the AI helper
    
    Args:
        messages (List[Dict[str, str]]): List of message objects with 'role' and 'content'
        system_prompt (Optional[str]): System prompt to customize assistant behavior
        
    Returns:
        str: The AI's response
    """
    if not has_api_key():
        return "Error: No OpenAI API key provided. Please add your API key in the settings."
    
    client = get_openai_client()
    
    if system_prompt:
        messages = [{"role": "system", "content": system_prompt}] + messages
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=messages
        )
        
        return response.choices[0].message.content
    except Exception as e:
        return f"Error: Failed to get AI response: {str(e)}"