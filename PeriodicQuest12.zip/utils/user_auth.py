"""
Module for handling user authentication and account management.
"""
import streamlit as st
import json
import os
import hashlib
import datetime
from pathlib import Path
import uuid
import secrets
import string

# Create data directory if it doesn't exist
DATA_DIR = Path("./user_data")
DATA_DIR.mkdir(exist_ok=True)

# User database file
USER_DB_FILE = DATA_DIR / "users.json"
if not USER_DB_FILE.exists():
    with open(USER_DB_FILE, "w") as f:
        json.dump({}, f)

def generate_reset_token():
    """Generate a secure reset token"""
    return ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(32))

def hash_password(password):
    """Hash a password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def load_users():
    """Load user database from file"""
    with open(USER_DB_FILE, "r") as f:
        return json.load(f)

def save_users(users):
    """Save user database to file"""
    with open(USER_DB_FILE, "w") as f:
        json.dump(users, f)

def register_user(username, password, display_name=None, email=None):
    """Register a new user
    
    Args:
        username (str): The unique username
        password (str): The user's password
        display_name (str, optional): User's display name
        email (str, optional): User's email for password recovery
        
    Returns:
        tuple: (success, message)
    """
    users = load_users()
    
    # Check if username already exists
    if username in users:
        return False, "Username already exists"
    
    # Create new user
    user_id = str(uuid.uuid4())
    users[username] = {
        "user_id": user_id,
        "password_hash": hash_password(password),
        "display_name": display_name or username,
        "email": email,
        "created_at": datetime.datetime.now().isoformat(),
        "last_login": None,
        "quiz_history": [],
        "settings": {
            "language": "English",
            "theme": "light",
            "notifications": True,
            "email_notifications": False
        },
        "reset_token": None,
        "reset_token_expiry": None,
        "profile": {
            "bio": "",
            "interests": [],
            "education_level": "",
            "avatar": None
        }
    }
    
    save_users(users)
    return True, "Registration successful"

def request_password_reset(username):
    """Request a password reset for a user
    
    Args:
        username (str): The username
        
    Returns:
        tuple: (success, message)
    """
    users = load_users()
    
    if username not in users:
        return False, "Username not found"
    
    # Generate reset token
    reset_token = generate_reset_token()
    expiry = datetime.datetime.now() + datetime.timedelta(hours=24)
    
    users[username]["reset_token"] = reset_token
    users[username]["reset_token_expiry"] = expiry.isoformat()
    
    save_users(users)
    return True, reset_token

def reset_password(username, reset_token, new_password):
    """Reset a user's password using a reset token
    
    Args:
        username (str): The username
        reset_token (str): The reset token
        new_password (str): The new password
        
    Returns:
        tuple: (success, message)
    """
    users = load_users()
    
    if username not in users:
        return False, "Username not found"
    
    user = users[username]
    
    if not user["reset_token"] or not user["reset_token_expiry"]:
        return False, "No password reset requested"
    
    if user["reset_token"] != reset_token:
        return False, "Invalid reset token"
    
    expiry = datetime.datetime.fromisoformat(user["reset_token_expiry"])
    if datetime.datetime.now() > expiry:
        return False, "Reset token expired"
    
    # Update password and clear reset token
    user["password_hash"] = hash_password(new_password)
    user["reset_token"] = None
    user["reset_token_expiry"] = None
    
    save_users(users)
    return True, "Password reset successful"

def authenticate_user(username, password):
    """Authenticate a user
    
    Args:
        username (str): The username
        password (str): The user's password
        
    Returns:
        tuple: (success, message)
    """
    users = load_users()
    
    # Check if username exists
    if username not in users:
        return False, "Invalid username or password"
    
    # Check password
    if users[username]["password_hash"] != hash_password(password):
        return False, "Invalid username or password"
    
    # Update last login
    users[username]["last_login"] = datetime.datetime.now().isoformat()
    save_users(users)
    
    return True, "Login successful"

def get_user_data(username):
    """Get user data
    
    Args:
        username (str): The username
        
    Returns:
        dict: User data or None if user doesn't exist
    """
    users = load_users()
    return users.get(username)

def update_user_data(username, field, value):
    """Update a specific field in the user data
    
    Args:
        username (str): The username
        field (str): The field to update (dot notation supported for nested fields)
        value: The new value
        
    Returns:
        bool: Success status
    """
    users = load_users()
    
    if username not in users:
        return False
    
    # Handle nested fields with dot notation
    if "." in field:
        parts = field.split(".")
        current = users[username]
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
        current[parts[-1]] = value
    else:
        users[username][field] = value
    
    save_users(users)
    return True

def save_quiz_result(username, quiz_data):
    """Save quiz result for a user
    
    Args:
        username (str): The username
        quiz_data (dict): Quiz result data including:
            - topic: str (elements, particles)
            - score: int
            - total_questions: int
            - incorrect_answers: list of questions and answers
            - quiz_options: dict of quiz options
            
    Returns:
        bool: Success status
    """
    users = load_users()
    
    if username not in users:
        return False
    
    # Add timestamp and quiz ID
    quiz_data["timestamp"] = datetime.datetime.now().isoformat()
    quiz_data["quiz_id"] = str(uuid.uuid4())
    
    # Add to quiz history
    users[username]["quiz_history"].append(quiz_data)
    
    save_users(users)
    return True

def get_quiz_history(username):
    """Get quiz history for a user
    
    Args:
        username (str): The username
        
    Returns:
        list: List of quiz results
    """
    user_data = get_user_data(username)
    if not user_data:
        return []
    
    return user_data.get("quiz_history", [])

def get_quiz_stats(username):
    """Get quiz statistics for a user
    
    Args:
        username (str): The username
        
    Returns:
        dict: Quiz statistics
    """
    quiz_history = get_quiz_history(username)
    
    if not quiz_history:
        return {
            "total_quizzes": 0,
            "total_score": 0,
            "total_questions": 0,
            "accuracy": 0,
            "by_topic": {}
        }
    
    total_score = sum(quiz["score"] for quiz in quiz_history)
    total_questions = sum(quiz["total_questions"] for quiz in quiz_history)
    
    # Organize by topic
    topics = {}
    for quiz in quiz_history:
        topic = quiz.get("topic", "unknown")
        if topic not in topics:
            topics[topic] = {
                "quizzes": 0,
                "score": 0,
                "questions": 0
            }
        
        topics[topic]["quizzes"] += 1
        topics[topic]["score"] += quiz["score"]
        topics[topic]["questions"] += quiz["total_questions"]
    
    # Calculate accuracy
    accuracy = (total_score / total_questions) * 100 if total_questions > 0 else 0
    
    # Calculate topic accuracy
    for topic in topics:
        if topics[topic]["questions"] > 0:
            topics[topic]["accuracy"] = (topics[topic]["score"] / topics[topic]["questions"]) * 100
        else:
            topics[topic]["accuracy"] = 0
    
    return {
        "total_quizzes": len(quiz_history),
        "total_score": total_score,
        "total_questions": total_questions,
        "accuracy": accuracy,
        "by_topic": topics
    }

def create_test_user_if_needed():
    """Create a test user account if no users exist"""
    users = load_users()
    if not users:
        # Create a test user for ease of development
        test_username = "testuser"
        test_password = "testpassword"  # In a real system, never hardcode passwords
        user_id = str(uuid.uuid4())
        users[test_username] = {
            "user_id": user_id,
            "password_hash": hash_password(test_password),
            "display_name": "Test User",
            "created_at": datetime.datetime.now().isoformat(),
            "last_login": None,
            "quiz_history": [],
            "settings": {
                "language": "English",
                "theme": "light"
            }
        }
        save_users(users)

def is_logged_in():
    """Check if a user is logged in
    
    Returns:
        bool: True if user is logged in
    """
    return "username" in st.session_state and st.session_state.username is not None

def get_current_user():
    """Get current logged in user
    
    Returns:
        str: Username or None if not logged in
    """
    return st.session_state.get("username")

def get_current_user_display_name():
    """Get current user's display name
    
    Returns:
        str: Display name or username if not found
    """
    if not is_logged_in():
        return None
    
    username = get_current_user()
    user_data = get_user_data(username)
    
    if not user_data:
        return username
    
    return user_data.get("display_name", username)

def logout():
    """Log out the current user"""
    if "username" in st.session_state:
        del st.session_state["username"]
    if "user_id" in st.session_state:
        del st.session_state["user_id"]

def update_user_profile(username, profile_data):
    """Update user profile information
    
    Args:
        username (str): The username
        profile_data (dict): The profile data to update
        
    Returns:
        bool: Success status
    """
    users = load_users()
    
    if username not in users:
        return False
    
    if "profile" not in users[username]:
        users[username]["profile"] = {}
    
    users[username]["profile"].update(profile_data)
    save_users(users)
    return True

def update_user_settings(username, settings_data):
    """Update user settings
    
    Args:
        username (str): The username
        settings_data (dict): The settings data to update
        
    Returns:
        bool: Success status
    """
    users = load_users()
    
    if username not in users:
        return False
    
    if "settings" not in users[username]:
        users[username]["settings"] = {}
    
    users[username]["settings"].update(settings_data)
    save_users(users)
    return True