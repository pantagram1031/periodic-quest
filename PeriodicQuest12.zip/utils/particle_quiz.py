"""
Module for handling the quiz functionality for Standard Model particles.
"""

import random
import time
import streamlit as st
from typing import Union, List, Dict, Any, Optional
from data.standard_model.particles import get_all_particles, get_particle_by_name, search_particles

# Global stats variable to store quiz statistics
if "particle_quiz_stats" not in st.session_state:
    st.session_state.particle_quiz_stats = {
        "total_questions": 0,
        "correct_answers": 0,
        "quiz_history": []
    }

class ParticleQuizGenerator:
    """Class for generating quiz questions about Standard Model particles"""
    
    def __init__(self, quiz_mode: str = "multiple_choice", quiz_type: Union[str, List[str]] = "all", 
                 particle_filter: Optional[Dict[str, Any]] = None, difficulty: str = "easy"):
        """Initialize the quiz generator
        
        Args:
            quiz_mode (str): The quiz mode - "multiple_choice" or "text_input"
            quiz_type (Union[str, list]): The type of questions to generate. Can be a string for a single type or a list of types.
                             Valid types: "all", "symbol", "name", "category", 
                             "charge", "mass", "spin", "force", "generation"
            particle_filter (dict): Filter for particles to include in the quiz
                - {'type': 'all'}: Include all particles
                - {'type': 'category', 'value': category_name}: Include particles of specific category
                - {'type': 'generation', 'value': generation_number}: Include particles of specific generation
            difficulty (str): Difficulty level of the quiz - "easy", "medium", or "hard"
        """
        self.quiz_mode = quiz_mode
        
        # Handle both string and list for quiz_type
        if isinstance(quiz_type, str):
            if quiz_type == "all":
                self.quiz_types = ["symbol", "name", "category", "charge", "mass", "spin", "force", "generation"]
            else:
                self.quiz_types = [quiz_type]
        else:
            if "all" in quiz_type:
                self.quiz_types = ["symbol", "name", "category", "charge", "mass", "spin", "force", "generation"]
            else:
                self.quiz_types = quiz_type
                
        # Set default particle filter if none is provided
        if particle_filter is None:
            self.particle_filter = {'type': 'all'}
        else:
            self.particle_filter = particle_filter
            
        self.difficulty = difficulty
        
        # Load all particles based on the filter
        self.particles = self._filter_particles()
        
    def _filter_particles(self):
        """Filter particles based on the configured filter"""
        all_particles = get_all_particles()
        
        if self.particle_filter['type'] == 'all':
            return all_particles
        
        elif self.particle_filter['type'] == 'category':
            category = self.particle_filter['value'].lower()
            return [p for p in all_particles if p['category'].lower() == category]
        
        elif self.particle_filter['type'] == 'generation':
            generation = int(self.particle_filter['value'])
            return [p for p in all_particles if 'generation' in p and p['generation'] == generation]
        
        # Default to all particles if filter is invalid
        return all_particles
    
    def generate_question(self):
        """Generate a random quiz question based on the configured mode and type"""
        # Ensure we have particles to work with
        if not self.particles:
            return {
                "question_text": "No particles available for the selected filter",
                "correct_answer": "",
                "options": [],
                "particle": None,
                "question_type": "error"
            }
        
        # Filter out question types that aren't applicable to the filtered particles
        available_types = self.quiz_types.copy()
        
        # Check if 'generation' questions are applicable (only for quarks and leptons)
        if "generation" in available_types:
            has_generations = any('generation' in p for p in self.particles)
            if not has_generations:
                available_types.remove("generation")
                
        # Check if 'force' questions are applicable (only for bosons)
        if "force" in available_types:
            has_force = any('force' in p and p['force'] is not None for p in self.particles)
            if not has_force:
                available_types.remove("force")
        
        # Select a random question type
        if not available_types:
            # If no applicable types, default to name and symbol
            available_types = ["name", "symbol"]
            
        question_type = random.choice(available_types)
        
        # Generate the appropriate question based on the mode and type
        if self.quiz_mode == "text_input":
            if question_type == "name":
                return self._generate_name_text_question()
            elif question_type == "symbol":
                return self._generate_symbol_text_question()
            elif question_type == "category":
                return self._generate_category_text_question()
            elif question_type == "charge":
                return self._generate_charge_text_question()
            elif question_type == "mass":
                return self._generate_mass_text_question()
            elif question_type == "spin":
                return self._generate_spin_text_question()
            elif question_type == "force":
                return self._generate_force_text_question()
            elif question_type == "generation":
                return self._generate_generation_text_question()
        else:  # multiple_choice
            if question_type == "name":
                return self._generate_name_question()
            elif question_type == "symbol":
                return self._generate_symbol_question()
            elif question_type == "category":
                return self._generate_category_question()
            elif question_type == "charge":
                return self._generate_charge_question()
            elif question_type == "mass":
                return self._generate_mass_question()
            elif question_type == "spin":
                return self._generate_spin_question()
            elif question_type == "force":
                return self._generate_force_question()
            elif question_type == "generation":
                return self._generate_generation_question()
        
        # Default fallback
        return self._generate_name_question()
    
    def _generate_name_text_question(self):
        """Generate a text input question about particle names"""
        particle = random.choice(self.particles)
        
        return {
            "question_text": f"What is the name of the particle with symbol {particle['symbol']}?",
            "correct_answer": particle['name'],
            "options": [],
            "particle": particle,
            "question_type": "name"
        }
    
    def _generate_symbol_text_question(self):
        """Generate a text input question about particle symbols"""
        particle = random.choice(self.particles)
        
        return {
            "question_text": f"What is the symbol for {particle['name']}?",
            "correct_answer": particle['symbol'],
            "options": [],
            "particle": particle,
            "question_type": "symbol"
        }
    
    def _generate_category_text_question(self):
        """Generate a text input question about particle categories"""
        particle = random.choice(self.particles)
        
        return {
            "question_text": f"What category of particle is {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['category'],
            "options": [],
            "particle": particle,
            "question_type": "category"
        }
        
    def _generate_charge_text_question(self):
        """Generate a text input question about particle charges"""
        particle = random.choice(self.particles)
        
        return {
            "question_text": f"What is the electric charge of {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['charge'],
            "options": [],
            "particle": particle,
            "question_type": "charge"
        }
        
    def _generate_mass_text_question(self):
        """Generate a text input question about particle masses"""
        particle = random.choice(self.particles)
        
        return {
            "question_text": f"What is the mass of {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['mass'],
            "options": [],
            "particle": particle,
            "question_type": "mass"
        }
        
    def _generate_spin_text_question(self):
        """Generate a text input question about particle spins"""
        particle = random.choice(self.particles)
        
        return {
            "question_text": f"What is the spin of {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['spin'],
            "options": [],
            "particle": particle,
            "question_type": "spin"
        }
        
    def _generate_force_text_question(self):
        """Generate a text input question about particle forces"""
        # Filter to get only particles that have a force property
        particles_with_force = [p for p in self.particles if 'force' in p and p['force'] is not None]
        
        if not particles_with_force:
            return self._generate_name_text_question()  # Fallback to a name question
            
        particle = random.choice(particles_with_force)
        
        return {
            "question_text": f"Which fundamental force is carried by the {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['force'],
            "options": [],
            "particle": particle,
            "question_type": "force"
        }
        
    def _generate_generation_text_question(self):
        """Generate a text input question about particle generations"""
        # Filter to get only particles that have a generation property
        particles_with_generation = [p for p in self.particles if 'generation' in p]
        
        if not particles_with_generation:
            return self._generate_name_text_question()  # Fallback to a name question
            
        particle = random.choice(particles_with_generation)
        
        return {
            "question_text": f"Which generation does the {particle['name']} ({particle['symbol']}) belong to?",
            "correct_answer": str(particle['generation']),
            "options": [],
            "particle": particle,
            "question_type": "generation"
        }
    
    def _generate_name_question(self):
        """Generate a question about particle names"""
        particle = random.choice(self.particles)
        
        # Create wrong options from other particles
        other_particles = [p for p in self.particles if p['name'] != particle['name']]
        if len(other_particles) < 3:
            wrong_options = [p['name'] for p in other_particles]
            # If we don't have enough particles, add some dummy options
            dummy_options = ["Graviton", "Preon", "Axion", "Majoron"]
            wrong_options.extend([o for o in dummy_options if o != particle['name']])
            wrong_options = wrong_options[:3]  # Ensure only 3 options
        else:
            wrong_options = [p['name'] for p in random.sample(other_particles, 3)]
            
        options = [particle['name']] + wrong_options
        random.shuffle(options)
        
        return {
            "question_text": f"What is the name of the particle with symbol {particle['symbol']}?",
            "correct_answer": particle['name'],
            "options": options,
            "particle": particle,
            "question_type": "name"
        }
    
    def _generate_symbol_question(self):
        """Generate a question about particle symbols"""
        particle = random.choice(self.particles)
        
        # Create options with the correct symbol and potentially bait symbols based on difficulty
        correct_answer = particle['symbol']
        options = [correct_answer]
        
        # Adjust bait symbol frequency based on difficulty
        bait_chance = 0.3  # Base chance for easy difficulty
        max_baits = 1      # Default max number of baits for easy
        
        if self.difficulty == "medium":
            bait_chance = 0.6   # Medium has moderate bait chance
            max_baits = 2       # Up to 2 baits for medium difficulty
        elif self.difficulty == "hard":
            bait_chance = 0.9   # Hard has high bait chance
            max_baits = 3       # Up to 3 baits for hard difficulty
            
        # Randomly decide if we use bait symbols at all
        use_bait = random.random() < bait_chance
        
        if use_bait:
            # Create bait symbols that are similar to the correct symbol
            bait_symbols = self._generate_bait_symbols(correct_answer)
            if bait_symbols:  # Only add if we actually have bait symbols
                options.extend(bait_symbols[:max_baits])  # Take limited number of bait symbols
        
        # Add remaining options from other real particles if needed
        other_particles = [p for p in self.particles if p['symbol'] != particle['symbol']]
        remaining_slots = 4 - len(options)
        
        if remaining_slots > 0:
            if len(other_particles) >= remaining_slots:
                # We have enough real particles to fill the slots
                random_particles = random.sample(other_particles, remaining_slots)
                options.extend([p['symbol'] for p in random_particles])
            else:
                # Use all available real particles
                options.extend([p['symbol'] for p in other_particles])
                
                # If we still need more options, add generic dummy options
                still_needed = 4 - len(options)
                if still_needed > 0:
                    # These are more valid-looking particle symbols
                    dummy_options = ["G", "X", "Ω", "Δ", "η", "ξ", "Σ"] 
                    # Filter out options that are already in our list
                    dummy_options = [o for o in dummy_options if o not in options]
                    if dummy_options:
                        options.extend(random.sample(dummy_options, min(still_needed, len(dummy_options))))
        
        # Shuffle options
        random.shuffle(options)
        
        # Ensure we have exactly 4 options
        options = options[:4]
        
        return {
            "question_text": f"What is the symbol for {particle['name']}?",
            "correct_answer": particle['symbol'],
            "options": options,
            "particle": particle,
            "question_type": "symbol"
        }
    
    def _generate_category_question(self):
        """Generate a question about particle categories"""
        particle = random.choice(self.particles)
        
        # Get unique categories
        all_categories = list(set(p['category'] for p in self.particles))
        
        # Create wrong options from other categories
        wrong_categories = [c for c in all_categories if c != particle['category']]
        if len(wrong_categories) < 3:
            wrong_options = wrong_categories
            # If we don't have enough categories, add some dummy options
            dummy_options = ["exotic meson", "anyon", "technicolor", "monopole"]
            wrong_options.extend([o for o in dummy_options if o != particle['category']])
            wrong_options = wrong_options[:3]  # Ensure only 3 options
        else:
            wrong_options = random.sample(wrong_categories, 3)
            
        options = [particle['category']] + wrong_options
        random.shuffle(options)
        
        return {
            "question_text": f"What category of particle is {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['category'],
            "options": options,
            "particle": particle,
            "question_type": "category"
        }
        
    def _generate_charge_question(self):
        """Generate a question about particle charges"""
        particle = random.choice(self.particles)
        
        # Get unique charges
        all_charges = list(set(p['charge'] for p in self.particles))
        
        # Create wrong options from other charges
        wrong_charges = [c for c in all_charges if c != particle['charge']]
        if len(wrong_charges) < 3:
            wrong_options = wrong_charges
            # If we don't have enough charges, add some dummy options
            dummy_options = ["+3", "-3", "+4/3", "-4/3"]
            wrong_options.extend([o for o in dummy_options if o != particle['charge']])
            wrong_options = wrong_options[:3]  # Ensure only 3 options
        else:
            wrong_options = random.sample(wrong_charges, 3)
            
        options = [particle['charge']] + wrong_options
        random.shuffle(options)
        
        return {
            "question_text": f"What is the electric charge of {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['charge'],
            "options": options,
            "particle": particle,
            "question_type": "charge"
        }
        
    def _generate_mass_question(self):
        """Generate a question about particle masses"""
        particle = random.choice(self.particles)
        
        # Get unique masses
        all_masses = list(set(p['mass'] for p in self.particles))
        
        # Create wrong options from other masses
        wrong_masses = [m for m in all_masses if m != particle['mass']]
        if len(wrong_masses) < 3:
            wrong_options = wrong_masses
            # If we don't have enough masses, add some dummy options
            dummy_options = ["125 GeV/c²", "80.4 GeV/c²", "91.2 GeV/c²", "1.5 GeV/c²"]
            wrong_options.extend([o for o in dummy_options if o != particle['mass']])
            wrong_options = wrong_options[:3]  # Ensure only 3 options
        else:
            wrong_options = random.sample(wrong_masses, 3)
            
        options = [particle['mass']] + wrong_options
        random.shuffle(options)
        
        return {
            "question_text": f"What is the mass of {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['mass'],
            "options": options,
            "particle": particle,
            "question_type": "mass"
        }
        
    def _generate_spin_question(self):
        """Generate a question about particle spins"""
        particle = random.choice(self.particles)
        
        # Get unique spins
        all_spins = list(set(p['spin'] for p in self.particles))
        
        # Create wrong options from other spins
        wrong_spins = [s for s in all_spins if s != particle['spin']]
        if len(wrong_spins) < 3:
            wrong_options = wrong_spins
            # If we don't have enough spins, add some dummy options
            dummy_options = ["0", "1", "1/2", "2"]
            wrong_options.extend([o for o in dummy_options if o != particle['spin']])
            wrong_options = wrong_options[:3]  # Ensure only 3 options
        else:
            wrong_options = random.sample(wrong_spins, 3)
            
        options = [particle['spin']] + wrong_options
        random.shuffle(options)
        
        return {
            "question_text": f"What is the spin of {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['spin'],
            "options": options,
            "particle": particle,
            "question_type": "spin"
        }
        
    def _generate_force_question(self):
        """Generate a question about particle forces"""
        # Filter to get only particles that have a force property
        particles_with_force = [p for p in self.particles if 'force' in p and p['force'] is not None]
        
        if not particles_with_force:
            return self._generate_name_question()  # Fallback to a name question
            
        particle = random.choice(particles_with_force)
        
        # Get unique forces
        all_forces = list(set(p['force'] for p in particles_with_force if p['force'] is not None))
        
        # Create wrong options from other forces
        wrong_forces = [f for f in all_forces if f != particle['force']]
        if len(wrong_forces) < 3:
            wrong_options = wrong_forces
            # If we don't have enough forces, add some dummy options
            dummy_options = ["Gravitational", "Electromagnetic", "Weak", "Strong", "Higgs"]
            wrong_options.extend([o for o in dummy_options if o != particle['force']])
            wrong_options = wrong_options[:3]  # Ensure only 3 options
        else:
            wrong_options = random.sample(wrong_forces, 3)
            
        options = [particle['force']] + wrong_options
        random.shuffle(options)
        
        return {
            "question_text": f"Which fundamental force is carried by the {particle['name']} ({particle['symbol']})?",
            "correct_answer": particle['force'],
            "options": options,
            "particle": particle,
            "question_type": "force"
        }
        
    def _generate_generation_question(self):
        """Generate a question about particle generations"""
        # Filter to get only particles that have a generation property
        particles_with_generation = [p for p in self.particles if 'generation' in p]
        
        if not particles_with_generation:
            return self._generate_name_question()  # Fallback to a name question
            
        particle = random.choice(particles_with_generation)
        
        # Create options for generations (typically 1, 2, or 3)
        options = ["1", "2", "3"]
        
        return {
            "question_text": f"Which generation does the {particle['name']} ({particle['symbol']}) belong to?",
            "correct_answer": str(particle['generation']),
            "options": options,
            "particle": particle,
            "question_type": "generation"
        }
        
    def _generate_bait_symbols(self, symbol):
        """Generate plausible but incorrect bait symbols for a given particle symbol
        
        Args:
            symbol (str): The correct particle symbol
            
        Returns:
            list: List of bait symbols
        """
        bait_symbols = []
        
        # Common particle bait symbols (expanded with more options and proper capitalization)
        common_mistakes = {
            # Quarks (following standard notation with proper capitalization)
            'u': ['d', 'c', 's', 'q'], 'd': ['u', 'b', 's', 'q'], 
            's': ['d', 'c', 'b', 'q'], 'c': ['s', 'u', 't', 'q'], 
            't': ['b', 'c', 'τ', 'q'], 'b': ['d', 't', 's', 'q'],
            
            # Leptons (following standard notation)
            'e': ['μ', 'τ', 'ε'], 'μ': ['e', 'τ', 'm'],
            'τ': ['μ', 'e', 't'], 'νe': ['ve', 'v', 'ne', 'e'],
            'νμ': ['vm', 'vμ', 'nm', 'μ'], 'ντ': ['vt', 'vτ', 'nt', 'τ'],
            
            # Alternative lepton notations
            've': ['νe', 'e', 'v'], 'vμ': ['νμ', 'μ', 'vm'],
            'vτ': ['ντ', 'τ', 'vt'],
            
            # Gauge bosons (following standard notation)
            'g': ['γ', 'G', 'f'], 'γ': ['g', 'ɣ', 'y', 'p'],
            'Z': ['W', 'X', 'Z0'], 'W': ['Z', 'V', 'W±'],
            'Z⁰': ['Z', 'W±', 'X⁰'], 'W⁺': ['W', 'Z⁰', 'H⁺'], 'W⁻': ['W', 'Z⁰', 'H⁻'],
            
            # Scalar boson
            'H': ['h', 'X', 'Φ', 'B'],
            
            # Common symbols with variant forms
            'ν': ['v', 'n', 'μ'], 'v': ['ν', 'w', 'u'],
            'Λ': ['Δ', 'Σ', 'λ'], 'Σ': ['Δ', 'Λ', 'σ'],
            'Ω': ['Δ', 'η', 'ω'], 'Θ': ['Φ', 'Ψ', 'θ']
        }
        
        # Add predefined common mistakes if available
        if symbol in common_mistakes:
            bait_symbols.extend(common_mistakes[symbol])
        
        # Strategy 1: Intelligent case handling based on particle type
        is_boson = symbol[0].isupper() if symbol else False
        is_fermion = symbol[0].islower() if symbol else False
        
        if is_boson:
            # For bosons (normally capitalized), create lowercase versions as bait
            if len(symbol) == 1:
                bait_symbols.append(symbol.lower())
            elif len(symbol) > 1:
                # Keep the same form but flip the capitalization of first letter
                bait_symbols.append(symbol[0].lower() + symbol[1:])
                
        elif is_fermion:
            # For fermions (normally lowercase), create capitalized versions as bait
            if len(symbol) == 1:
                bait_symbols.append(symbol.upper())
            elif len(symbol) > 1:
                # Keep the same form but flip the capitalization of first letter
                bait_symbols.append(symbol[0].upper() + symbol[1:])
            
        # Strategy 2: For neutrinos - swap notation style (νe -> ve, or ve -> νe)
        if symbol in ['νe', 'νμ', 'ντ']:
            # Convert Greek symbol to Latin "v" (common mistake)
            latin_version = 'v' + symbol[1:]
            bait_symbols.append(latin_version)
        elif symbol in ['ve', 'vμ', 'vτ', 'vm', 'vt']:
            # Try to convert Latin "v" to Greek "ν"
            if len(symbol) > 1:
                greek_version = 'ν' + symbol[1:]
                bait_symbols.append(greek_version)
                
        # Strategy 3: For composite symbols, split or combine them
        if len(symbol) == 1:
            bait_symbols.append(symbol + '⁺')
            bait_symbols.append(symbol + '⁻')
            bait_symbols.append(symbol + '*')
            
        # Strategy 4: Replace with similar-looking Unicode characters
        unicode_replacements = {
            'a': 'α', 'b': 'β', 'c': 'ç', 'd': 'δ', 'e': 'ε', 
            'g': 'γ', 'l': 'λ', 'm': 'μ', 'n': 'η', 'o': 'ω', 
            'p': 'ρ', 'r': 'π', 's': 'σ', 't': 'τ', 'u': 'υ',
            'w': 'ω', 'x': 'χ', 'y': 'ψ', 'z': 'ζ'
        }
        
        if len(symbol) == 1 and symbol.lower() in unicode_replacements:
            bait_symbols.append(unicode_replacements[symbol.lower()])
            
        # Ensure we only return unique symbols
        unique_bait_symbols = list(set(bait_symbols))
        
        # Remove any that match the original symbol
        unique_bait_symbols = [s for s in unique_bait_symbols if s != symbol]
        
        # Filter out any that are actual particle symbols
        existing_symbols = [p['symbol'] for p in self.particles]
        final_bait_symbols = [s for s in unique_bait_symbols if s not in existing_symbols]
        
        return final_bait_symbols

def evaluate_particle_answer(question, selected_answer):
    """Evaluate if the selected answer is correct for a particle quiz question"""
    correct_answer = question["correct_answer"]
    
    # Normalize answers for comparison
    normalized_selected = str(selected_answer).strip().lower()
    normalized_correct = str(correct_answer).strip().lower()
    
    # For generation questions, convert to string for comparison
    if question["question_type"] == "generation":
        normalized_correct = str(normalized_correct)
    
    # Simple comparison
    is_correct = normalized_selected == normalized_correct
    
    # Treat "gauge boson" and "scalar boson" entries specially
    if question["question_type"] == "category" and "boson" in normalized_selected:
        if normalized_selected in normalized_correct or normalized_correct in normalized_selected:
            is_correct = True
    
    # Initialize stats if needed
    if "particle_quiz_stats" not in st.session_state:
        st.session_state.particle_quiz_stats = {
            "total_questions": 0,
            "correct_answers": 0,
            "quiz_history": []
        }
        
    # Update statistics
    st.session_state.particle_quiz_stats["total_questions"] += 1
    if is_correct:
        st.session_state.particle_quiz_stats["correct_answers"] += 1
    
    return is_correct

def get_particle_quiz_statistics():
    """Get statistics about particle quiz performance"""
    # Initialize stats if needed
    if "particle_quiz_stats" not in st.session_state:
        st.session_state.particle_quiz_stats = {
            "total_questions": 0,
            "correct_answers": 0,
            "quiz_history": []
        }
    return st.session_state.particle_quiz_stats

def reset_particle_quiz_statistics():
    """Reset the particle quiz statistics"""
    st.session_state.particle_quiz_stats = {
        "total_questions": 0,
        "correct_answers": 0,
        "quiz_history": []
    }