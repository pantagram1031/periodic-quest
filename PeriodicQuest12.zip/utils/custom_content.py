"""
Module for managing custom user-defined content for the Science Learning Platform.
This module handles the storage, retrieval, and management of custom learning topics
and quiz content created by users.
"""
import json
import os
import uuid
import datetime
from pathlib import Path

# Create data directory if it doesn't exist
DATA_DIR = Path("./user_data")
DATA_DIR.mkdir(exist_ok=True)

# Custom content database file
CUSTOM_CONTENT_FILE = DATA_DIR / "custom_content.json"
if not CUSTOM_CONTENT_FILE.exists():
    with open(CUSTOM_CONTENT_FILE, "w") as f:
        json.dump({
            "topics": [],
            "quizzes": []
        }, f)

def load_custom_content():
    """Load custom content database from file"""
    with open(CUSTOM_CONTENT_FILE, "r") as f:
        return json.load(f)

def save_custom_content(content):
    """Save custom content database to file"""
    with open(CUSTOM_CONTENT_FILE, "w") as f:
        json.dump(content, f)

def get_custom_topics():
    """Get all custom topics
    
    Returns:
        list: List of custom topic dictionaries
    """
    content = load_custom_content()
    return content.get("topics", [])

def get_custom_topic(topic_id):
    """Get a specific custom topic by ID
    
    Args:
        topic_id (str): The topic ID
        
    Returns:
        dict: The topic data or None if not found
    """
    topics = get_custom_topics()
    for topic in topics:
        if topic["id"] == topic_id:
            return topic
    return None

def create_custom_topic(title, description, icon, created_by):
    """Create a new custom topic
    
    Args:
        title (str): The topic title
        description (str): Topic description
        icon (str): Emoji or icon for the topic
        created_by (str): Username of creator
        
    Returns:
        dict: The newly created topic
    """
    content = load_custom_content()
    
    # Create new topic
    topic_id = str(uuid.uuid4())
    new_topic = {
        "id": topic_id,
        "title": title,
        "description": description,
        "icon": icon or "📚",  # Default icon
        "created_by": created_by,
        "created_at": datetime.datetime.now().isoformat(),
        "modified_at": datetime.datetime.now().isoformat(),
        "content_sections": [],
    }
    
    content["topics"].append(new_topic)
    save_custom_content(content)
    
    return new_topic

def update_custom_topic(topic_id, title=None, description=None, icon=None, content_sections=None):
    """Update an existing custom topic
    
    Args:
        topic_id (str): The topic ID to update
        title (str, optional): New title
        description (str, optional): New description
        icon (str, optional): New icon
        content_sections (list, optional): New content sections
        
    Returns:
        dict: The updated topic or None if not found
    """
    content = load_custom_content()
    
    for i, topic in enumerate(content["topics"]):
        if topic["id"] == topic_id:
            if title is not None:
                topic["title"] = title
            if description is not None:
                topic["description"] = description
            if icon is not None:
                topic["icon"] = icon
            if content_sections is not None:
                topic["content_sections"] = content_sections
                
            topic["modified_at"] = datetime.datetime.now().isoformat()
            
            content["topics"][i] = topic
            save_custom_content(content)
            return topic
            
    return None

def delete_custom_topic(topic_id):
    """Delete a custom topic
    
    Args:
        topic_id (str): The topic ID to delete
        
    Returns:
        bool: Success status
    """
    content = load_custom_content()
    
    for i, topic in enumerate(content["topics"]):
        if topic["id"] == topic_id:
            del content["topics"][i]
            save_custom_content(content)
            return True
            
    return False

def add_content_section(topic_id, title, content_type, content_data):
    """Add a content section to a topic
    
    Args:
        topic_id (str): The topic ID
        title (str): Section title
        content_type (str): Type of content ('text', 'image_url', 'chart', etc.)
        content_data (dict): The content data
        
    Returns:
        dict: The updated topic or None if not found
    """
    topic = get_custom_topic(topic_id)
    
    if not topic:
        return None
        
    # Create new section
    section_id = str(uuid.uuid4())
    new_section = {
        "id": section_id,
        "title": title,
        "content_type": content_type,
        "content_data": content_data,
        "created_at": datetime.datetime.now().isoformat()
    }
    
    if "content_sections" not in topic:
        topic["content_sections"] = []
        
    topic["content_sections"].append(new_section)
    
    return update_custom_topic(topic_id, content_sections=topic["content_sections"])

def update_content_section(topic_id, section_id, title=None, content_type=None, content_data=None):
    """Update a content section
    
    Args:
        topic_id (str): The topic ID
        section_id (str): The section ID to update
        title (str, optional): New title
        content_type (str, optional): New content type
        content_data (dict, optional): New content data
        
    Returns:
        dict: The updated topic or None if not found
    """
    topic = get_custom_topic(topic_id)
    
    if not topic or "content_sections" not in topic:
        return None
        
    for i, section in enumerate(topic["content_sections"]):
        if section["id"] == section_id:
            if title is not None:
                section["title"] = title
            if content_type is not None:
                section["content_type"] = content_type
            if content_data is not None:
                section["content_data"] = content_data
                
            topic["content_sections"][i] = section
            return update_custom_topic(topic_id, content_sections=topic["content_sections"])
            
    return None

def delete_content_section(topic_id, section_id):
    """Delete a content section
    
    Args:
        topic_id (str): The topic ID
        section_id (str): The section ID to delete
        
    Returns:
        dict: The updated topic or None if not found
    """
    topic = get_custom_topic(topic_id)
    
    if not topic or "content_sections" not in topic:
        return None
        
    for i, section in enumerate(topic["content_sections"]):
        if section["id"] == section_id:
            del topic["content_sections"][i]
            return update_custom_topic(topic_id, content_sections=topic["content_sections"])
            
    return None

# Custom Quiz Functions
def get_custom_quizzes(topic_id=None):
    """Get all custom quizzes or filter by topic_id
    
    Args:
        topic_id (str, optional): If provided, only return quizzes for this topic
    
    Returns:
        list: List of custom quiz dictionaries
    """
    content = load_custom_content()
    quizzes = content.get("quizzes", [])
    
    # If topic_id is provided, filter the quizzes
    if topic_id:
        return [quiz for quiz in quizzes if quiz.get("topic_id") == topic_id]
    
    return quizzes

def get_custom_quiz(quiz_id):
    """Get a specific custom quiz by ID
    
    Args:
        quiz_id (str): The quiz ID
        
    Returns:
        dict: The quiz data or None if not found
    """
    quizzes = get_custom_quizzes()
    for quiz in quizzes:
        if quiz["id"] == quiz_id:
            return quiz
    return None

def create_custom_quiz(title, description, topic_id, created_by, difficulty="medium"):
    """Create a new custom quiz
    
    Args:
        title (str): The quiz title
        description (str): Quiz description
        topic_id (str): Associated topic ID (can be built-in or custom)
        created_by (str): Username of creator
        difficulty (str, optional): Quiz difficulty (easy, medium, hard)
        
    Returns:
        dict: The newly created quiz
    """
    content = load_custom_content()
    
    # Create new quiz
    quiz_id = str(uuid.uuid4())
    new_quiz = {
        "id": quiz_id,
        "title": title,
        "description": description,
        "topic_id": topic_id,
        "created_by": created_by,
        "created_at": datetime.datetime.now().isoformat(),
        "modified_at": datetime.datetime.now().isoformat(),
        "difficulty": difficulty,
        "questions": [],
    }
    
    content["quizzes"].append(new_quiz)
    save_custom_content(content)
    
    return new_quiz

def update_custom_quiz(quiz_id, title=None, description=None, difficulty=None, questions=None):
    """Update an existing custom quiz
    
    Args:
        quiz_id (str): The quiz ID to update
        title (str, optional): New title
        description (str, optional): New description
        difficulty (str, optional): New difficulty
        questions (list, optional): New questions list
        
    Returns:
        dict: The updated quiz or None if not found
    """
    content = load_custom_content()
    
    for i, quiz in enumerate(content["quizzes"]):
        if quiz["id"] == quiz_id:
            if title is not None:
                quiz["title"] = title
            if description is not None:
                quiz["description"] = description
            if difficulty is not None:
                quiz["difficulty"] = difficulty
            if questions is not None:
                quiz["questions"] = questions
                
            quiz["modified_at"] = datetime.datetime.now().isoformat()
            
            content["quizzes"][i] = quiz
            save_custom_content(content)
            return quiz
            
    return None

def delete_custom_quiz(quiz_id):
    """Delete a custom quiz
    
    Args:
        quiz_id (str): The quiz ID to delete
        
    Returns:
        bool: Success status
    """
    content = load_custom_content()
    
    for i, quiz in enumerate(content["quizzes"]):
        if quiz["id"] == quiz_id:
            del content["quizzes"][i]
            save_custom_content(content)
            return True
            
    return False

def add_quiz_question(quiz_id, question_text, question_type, correct_answer, options=None, explanation=None):
    """Add a question to a quiz
    
    Args:
        quiz_id (str): The quiz ID
        question_text (str): The question text
        question_type (str): Type of question ('multiple_choice', 'text_input')
        correct_answer (str): The correct answer
        options (list, optional): List of options for multiple choice
        explanation (str, optional): Explanation of the answer
        
    Returns:
        dict: The updated quiz or None if not found
    """
    quiz = get_custom_quiz(quiz_id)
    
    if not quiz:
        return None
        
    # Create new question
    question_id = str(uuid.uuid4())
    new_question = {
        "id": question_id,
        "question_text": question_text,
        "question_type": question_type,
        "correct_answer": correct_answer,
        "created_at": datetime.datetime.now().isoformat()
    }
    
    if options:
        new_question["options"] = options
    
    if explanation:
        new_question["explanation"] = explanation
        
    if "questions" not in quiz:
        quiz["questions"] = []
        
    quiz["questions"].append(new_question)
    
    return update_custom_quiz(quiz_id, questions=quiz["questions"])

def update_quiz_question(quiz_id, question_id, question_text=None, correct_answer=None, options=None, explanation=None):
    """Update a quiz question
    
    Args:
        quiz_id (str): The quiz ID
        question_id (str): The question ID to update
        question_text (str, optional): New question text
        correct_answer (str, optional): New correct answer
        options (list, optional): New options list
        explanation (str, optional): New explanation
        
    Returns:
        dict: The updated quiz or None if not found
    """
    quiz = get_custom_quiz(quiz_id)
    
    if not quiz or "questions" not in quiz:
        return None
        
    for i, question in enumerate(quiz["questions"]):
        if question["id"] == question_id:
            if question_text is not None:
                question["question_text"] = question_text
            if correct_answer is not None:
                question["correct_answer"] = correct_answer
            if options is not None:
                question["options"] = options
            if explanation is not None:
                question["explanation"] = explanation
                
            quiz["questions"][i] = question
            return update_custom_quiz(quiz_id, questions=quiz["questions"])
            
    return None

def delete_quiz_question(quiz_id, question_id):
    """Delete a quiz question
    
    Args:
        quiz_id (str): The quiz ID
        question_id (str): The question ID to delete
        
    Returns:
        dict: The updated quiz or None if not found
    """
    quiz = get_custom_quiz(quiz_id)
    
    if not quiz or "questions" not in quiz:
        return None
        
    for i, question in enumerate(quiz["questions"]):
        if question["id"] == question_id:
            del quiz["questions"][i]
            return update_custom_quiz(quiz_id, questions=quiz["questions"])
            
    return None