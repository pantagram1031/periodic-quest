# Custom Topic Generator for Science Learning Platform

## Instructions
Create a complete custom topic for a science learning platform. The output should be in valid JSON format with proper fields and structure. Please replace all placeholders with appropriate content.

## Required Structure
```json
{
  "id": "UNIQUE_ID_HERE",
  "title": "TOPIC_TITLE",
  "description": "DETAILED_TOPIC_DESCRIPTION",
  "icon": "EMOJI_ICON",
  "created_by": "username",
  "created_at": "2023-06-15T00:00:00",
  "entity_name_singular": "ENTITY_NAME",
  "entity_name_plural": "ENTITY_NAMES",
  "view_settings": {
    "default_view": "cards",
    "available_views": ["cards", "table"],
    "sort_by": "name"
  },
  "properties": [
    {
      "id": "name",
      "name": "Name",
      "type": "text",
      "description": "The name of the entity",
      "is_required": true,
      "is_primary": true
    },
    {
      "id": "symbol",
      "name": "Symbol",
      "type": "text",
      "description": "The symbol or abbreviation",
      "is_required": true,
      "is_secondary": true
    },
    {
      "id": "description",
      "name": "Description",
      "type": "text_long",
      "description": "Detailed description of the entity",
      "is_required": true
    },
    {
      "id": "CUSTOM_PROPERTY_ID",
      "name": "CUSTOM_PROPERTY_NAME",
      "type": "PROPERTY_TYPE",
      "description": "PROPERTY_DESCRIPTION",
      "is_required": true/false
    }
    // ADD MORE PROPERTIES AS NEEDED
  ],
  "entities": [
    {
      "id": "ENTITY_ID_1",
      "name": "ENTITY_NAME_1",
      "symbol": "SYMBOL_1",
      "description": "DETAILED_DESCRIPTION_1",
      "CUSTOM_PROPERTY_ID": "PROPERTY_VALUE"
      // ADD VALUES FOR ALL PROPERTIES
    },
    {
      "id": "ENTITY_ID_2",
      "name": "ENTITY_NAME_2",
      "symbol": "SYMBOL_2",
      "description": "DETAILED_DESCRIPTION_2",
      "CUSTOM_PROPERTY_ID": "PROPERTY_VALUE"
      // ADD VALUES FOR ALL PROPERTIES
    }
    // ADD MORE ENTITIES AS NEEDED
  ],
  "quiz_settings": {
    "questions_per_quiz": 5,
    "time_limit_minutes": 5,
    "difficulty_levels": ["easy", "medium", "hard"],
    "default_difficulty": "medium"
  }
}
```

## Property Types
- "text": Short text field
- "text_long": Multi-line text description
- "number": Numeric value
- "boolean": True/False value
- "date": Date value
- "image_url": URL to an image

## Guidelines
1. Choose a specific scientific topic (e.g., "Solar System Planets", "Types of Clouds", "Dinosaur Species")
2. Create at least 5 entities (items) within your topic, each with complete information
3. Define at least 5 properties (including the required ones above)
4. Include detailed descriptions for each entity (at least 3-4 sentences)
5. Make sure all IDs are unique (use simple alphanumeric strings)
6. Use appropriate emojis for the topic icon
7. Entity names should be unique and representative
8. Try to cover the topic comprehensively

## Example Topic Ideas
- Mountain Ranges of the World
- Endangered Animal Species
- Notable Scientific Discoveries
- Types of Geological Formations
- Famous Astronomers and Their Contributions
- Renewable Energy Technologies
- Major Biomes of Earth
- Important Chemical Compounds
- Meteorological Phenomena
- Ancient Civilizations

When you're done, provide the complete JSON object with no additional text or explanations.