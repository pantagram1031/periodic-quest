import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path
import sys
import importlib.util
import os

# Set page configuration - must be the first Streamlit command
st.set_page_config(
    page_title="Science Learning Platform",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Define a function to import modules directly from file paths
def import_module_from_path(module_name, file_path):
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None:
        raise ImportError(f"Could not find module {module_name} at {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module

# Add the current directory to the Python path
current_dir = Path.cwd()
sys.path.append(str(current_dir))

# Import the modules directly from their file paths
home_module = import_module_from_path("home", os.path.join(current_dir, "pages", "home.py"))
element_details_module = import_module_from_path("element_details", os.path.join(current_dir, "pages", "element_details.py"))
quiz_module = import_module_from_path("quiz_new", os.path.join(current_dir, "pages", "quiz_new.py"))
periodic_table_module = import_module_from_path("periodic_table", os.path.join(current_dir, "pages", "periodic_table.py"))
quiz_history_module = import_module_from_path("quiz_history", os.path.join(current_dir, "pages", "quiz_history.py"))
account_module = import_module_from_path("account", os.path.join(current_dir, "pages", "account.py"))

# Import Standard Model modules
standard_model_home_module = import_module_from_path("standard_model_home", os.path.join(current_dir, "pages", "standard_model_home.py"))
standard_model_particles_module = import_module_from_path("standard_model_particles", os.path.join(current_dir, "pages", "standard_model_particles.py"))

# Import login module
login_module = import_module_from_path("login", os.path.join(current_dir, "pages", "login.py"))

# Import Custom Content modules
custom_content_module = import_module_from_path("custom_content", os.path.join(current_dir, "pages", "custom_content.py"))
custom_topic_view_module = import_module_from_path("custom_topic_view", os.path.join(current_dir, "pages", "custom_topic_view.py"))

# Import Template Content Assistant module
template_content_assistant_module = import_module_from_path("template_content_assistant", os.path.join(current_dir, "pages", "template_content_assistant.py"))

# Import Topic Builder module
topic_builder_module = import_module_from_path("topic_builder", os.path.join(current_dir, "pages", "topic_builder.py"))

# Import Custom Learning modules
custom_learning_home_module = import_module_from_path("custom_learning_home", os.path.join(current_dir, "pages", "custom_learning_home.py"))
custom_topic_explorer_module = import_module_from_path("custom_topic_explorer", os.path.join(current_dir, "pages", "custom_topic_explorer.py"))
topic_grid_editor_module = import_module_from_path("topic_grid_editor", os.path.join(current_dir, "pages", "topic_grid_editor.py"))
custom_topic_selector_module = import_module_from_path("custom_topic_selector", os.path.join(current_dir, "pages", "custom_topic_selector.py"))
preset_template_selector_module = import_module_from_path("preset_template_selector", os.path.join(current_dir, "pages", "preset_template_selector.py"))
topic_create_module = import_module_from_path("topic_create", os.path.join(current_dir, "pages", "topic_create.py"))

# Import topic builder utilities
from utils.topic_builder import get_all_topics, load_topic

# Get the render functions for Custom Learning modules
custom_learning_home_render = custom_learning_home_module.render
custom_topic_explorer_render = custom_topic_explorer_module.render
topic_grid_editor_render = topic_grid_editor_module.render
custom_topic_selector_render = custom_topic_selector_module.render
preset_template_selector_render = preset_template_selector_module.render
topic_create_render = topic_create_module.render

# Get the render functions from each module
home_render = home_module.render
element_details_render = element_details_module.render
quiz_render = quiz_module.render
periodic_table_render = periodic_table_module.render
quiz_history_render = quiz_history_module.render
account_render = account_module.render
login_render = login_module.render
standard_model_home_render = standard_model_home_module.render
standard_model_particles_render = standard_model_particles_module.render
custom_content_render = custom_content_module.render
custom_topic_view_render = custom_topic_view_module.render
template_content_assistant_render = template_content_assistant_module.render
topic_builder_render = topic_builder_module.render

# Define available main topics and their pages
MAIN_TOPICS = {
    "Chemical Elements": {
        "icon": "⚗️",
        "pages": {
            "home": home_render,
            "periodic_table": periodic_table_render,
            "element_details": element_details_render,
            "quiz": quiz_render,
            "quiz_history": quiz_history_render,
        },
        "default_page": "home"
    },
    "Standard Model": {
        "icon": "⚛️",
        "pages": {
            "home": standard_model_home_render,
            "particles": standard_model_particles_render,
            "quiz": quiz_render,  # Reuse the same quiz system but with different topics
            "quiz_history": quiz_history_render,  # Reuse the same history system
        },
        "default_page": "home"
    },
    "Custom Learning": {
        "icon": "📚",
        "pages": {
            "home": custom_learning_home_render,  # Use new custom learning home
            "custom_topic_explorer": custom_topic_explorer_render,  # New topic explorer
            "topic_create": topic_create_render,  # New topic creation page
            "topic_builder": topic_builder_render,  # Keep existing topic builder
            "custom_content": custom_content_render,  # Keep existing content manager
            "ai_assistant": template_content_assistant_render,  # Keep template assistant
            "topic_view": custom_topic_view_render,  # Keep existing topic view
            "quiz": quiz_render,  # Keep quiz system but need special handling
            "quiz_history": quiz_history_render,  # Keep quiz history
        },
        "page_display_names": {  # Custom display names for navigation
            "home": "Home",
            "custom_topic_explorer": "Topic Explorer",
            "topic_create": "Create New Topic",
            "topic_builder": "Topic Builder",
            "topic_grid_editor": "Entity & Aspect Editor",
            "custom_content": "Content Manager",
            "ai_assistant": "Content Helper",
            "topic_view": "View Topic",
            "quiz": "Universal Quiz",
            "quiz_history": "Quiz History"
        },
        "default_page": "home"
    }
}

# For backward compatibility, create SCIENCE_TOPICS dictionary 
# that only includes the science topics (not Custom Learning)
SCIENCE_TOPICS = {topic: config for topic, config in MAIN_TOPICS.items() 
                 if topic in ["Chemical Elements", "Standard Model"]}

# Define Custom Learning with customized navigation
CUSTOM_LEARNING = {
    "icon": "📚",
    "pages": {
        "home": custom_learning_home_render,
        "custom_topic_selector": custom_topic_selector_render,
        "preset_template_selector": preset_template_selector_render,
        "topic_create": topic_create_render,
        "topic_builder": topic_builder_render,
        "topic_grid_editor": topic_grid_editor_render,
        "quiz": quiz_render,
        "quiz_history": quiz_history_render,
        "import_export": topic_builder_render,
    },
    "navigation_pages": [
        "home",                     # Home
        "custom_topic_selector",    # Create custom topic
        "preset_template_selector", # Select preset template
        "topic_create",            # Create new topic
        "topic_builder",           # Topic builder
        "topic_grid_editor",       # Custom entity/quiz editor
        "quiz",                    # Universal quiz
        "quiz_history",            # Universal quiz history
        "import_export",           # Import/Export topic
    ],
    "page_display_names": {
        "home": "Home",
        "custom_topic_selector": "Create Custom Topic",
        "preset_template_selector": "Select Preset Template",
        "topic_create": "Create New Topic",
        "topic_builder": "Topic Builder",
        "topic_grid_editor": "Custom Entity/Quiz Editor",
        "quiz": "Universal Quiz",
        "quiz_history": "Universal Quiz History",
        "import_export": "Import/Export Topic"
    },
    "default_page": "home"
}

# Import the translations function
translations_module = import_module_from_path("translations", os.path.join(current_dir, "utils", "translations.py"))
get_translation = translations_module.get_translation
TRANSLATIONS = translations_module.TRANSLATIONS

# Import user auth module and ensure we have a test user for development
user_auth_module = import_module_from_path("user_auth", os.path.join(current_dir, "utils", "user_auth.py"))
# Create a test user if no users exist yet
user_auth_module.create_test_user_if_needed()

# Auto-login for development purposes - this should be removed in production
if "username" not in st.session_state:
    # Auto-login the test user
    st.session_state.username = "testuser"
    # Get user data for the test user
    user_data = user_auth_module.get_user_data("testuser")
    if user_data:
        st.session_state.user_id = user_data.get("user_id")
        # Set language preference if available
        if "settings" in user_data and "language" in user_data["settings"]:
            st.session_state.language = user_data["settings"]["language"]

# Initialize session state if not already done
if "page" not in st.session_state:
    st.session_state.page = "home"
if "selected_element" not in st.session_state:
    st.session_state.selected_element = None
if "quiz_score" not in st.session_state:
    st.session_state.quiz_score = 0
if "quiz_total" not in st.session_state:
    st.session_state.quiz_total = 0
if "quiz_history" not in st.session_state:
    st.session_state.quiz_history = []
if "completed_quizzes" not in st.session_state:
    st.session_state.completed_quizzes = []  # Add initialization for completed_quizzes
if "tab_index" not in st.session_state:
    st.session_state.tab_index = 0
if "language" not in st.session_state:
    st.session_state.language = "English"  # Default language is English
if "mobile_mode" not in st.session_state:
    st.session_state.mobile_mode = False  # Default mobile mode is off
if "current_topic" not in st.session_state:
    st.session_state.current_topic = "Chemical Elements"  # Default topic
# Initialize custom learning mode to False by default
if "custom_learning" not in st.session_state:
    st.session_state.custom_learning = False  # Default to science topics
# Initialize sidebar tab
if "active_sidebar_tab" not in st.session_state:
    # Default to Science Topics tab unless custom learning is active
    st.session_state.active_sidebar_tab = "Custom Learning" if st.session_state.custom_learning else "Science Topics"

# Periodic table specific state variables
if "current_element_description" not in st.session_state:
    st.session_state.current_element_description = None
if "show_element_description" not in st.session_state:
    st.session_state.show_element_description = False
if "highlight_element" not in st.session_state:
    st.session_state.highlight_element = None
if "element_sort_by" not in st.session_state:
    st.session_state.element_sort_by = "atomic_number"
if "element_layout" not in st.session_state:
    st.session_state.element_layout = "horizontal"  # Default layout is horizontal
if "direct_navigation" not in st.session_state:
    st.session_state.direct_navigation = False

# Custom Learning state variables
if "selected_topic_id" not in st.session_state:
    st.session_state.selected_topic_id = None
if "topic_creation_step" not in st.session_state:
    st.session_state.topic_creation_step = 1
if "topic_template" not in st.session_state:
    st.session_state.topic_template = None
if "topic_data" not in st.session_state:
    st.session_state.topic_data = {}
if "custom_topic_explorer_page" not in st.session_state:
    st.session_state.custom_topic_explorer_page = "overview"

# Custom CSS for styling the navigation
st.markdown("""
<style>
    /* Move navigation to top of sidebar */
    section[data-testid="stSidebar"] > div:first-child {
        padding-top: 1rem !important;
    }
    
    /* Style the navigation buttons to look like squares instead of circles */
    div.st-emotion-cache-1erivf3.e1vs0wn30, div.st-emotion-cache-1erivf3.e1vs0wn31 {
        border-radius: 4px !important;
    }
    
    /* Change the selected button style */
    div.st-emotion-cache-1erivf3.e1vs0wn30 [data-testid="stMarkdownContainer"] p {
        font-weight: bold;
    }
    
    /* Make selected button darker instead of colored */
    div.st-emotion-cache-1erivf3.e1vs0wn31 {
        background-color: rgba(128, 128, 128, 0.2) !important;
    }
    
    /* Reduce navigation padding */
    div.st-emotion-cache-16txtl3.eczjsme4 {
        padding-top: 0 !important;
        padding-bottom: 0 !important;
    }
</style>
""", unsafe_allow_html=True)

# Define a function to handle language change
def change_language():
    st.rerun()

# Function to change science topic
def change_science_topic():
    # Reset page to home for the new science topic
    current_topic = st.session_state.current_topic
    
    # Check if we're in Custom Learning mode
    if current_topic == "Custom Learning":
        st.session_state.page = CUSTOM_LEARNING["default_page"]
    else:
        st.session_state.page = SCIENCE_TOPICS[current_topic]["default_page"]
    
    # Ensure custom learning is off when using science topics
    st.session_state.custom_learning = (current_topic == "Custom Learning")
    
    st.rerun()

# Function to enable custom learning
def enable_custom_learning():
    # Set custom learning mode on and navigate to custom learning home
    st.session_state.custom_learning = True
    st.session_state.page = CUSTOM_LEARNING["default_page"]
    st.rerun()

# Navigation sidebar
with st.sidebar:
    # Main tab selector with four options now
    main_tabs = ["Science Topics", "Custom Learning", "Custom Topic Viewing", "Settings"]
    
    if "active_sidebar_tab" not in st.session_state:
        # Default to Science Topics tab unless custom learning is active
        st.session_state.active_sidebar_tab = "Custom Learning" if st.session_state.custom_learning else "Science Topics"
    
    # Create a tab-like selector using horizontal radio buttons - now with 4 columns
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        science_tab_selected = st.button(
            "🧪 Science Topics", 
            use_container_width=True,
            key="science_tab_btn",
            type="primary" if st.session_state.active_sidebar_tab == "Science Topics" else "secondary"
        )
        if science_tab_selected:
            st.session_state.active_sidebar_tab = "Science Topics"
            # If switching from Custom Learning, turn it off
            if st.session_state.custom_learning:
                st.session_state.custom_learning = False
                st.session_state.current_topic = "Chemical Elements" 
                st.session_state.page = SCIENCE_TOPICS["Chemical Elements"]["default_page"]
            st.rerun()
            
    with col2:
        custom_tab_selected = st.button(
            "📚 Custom Learning", 
            use_container_width=True,
            key="custom_tab_btn",
            type="primary" if st.session_state.active_sidebar_tab == "Custom Learning" else "secondary"
        )
        if custom_tab_selected:
            st.session_state.active_sidebar_tab = "Custom Learning"
            # If not already in custom learning mode, enable it
            if not st.session_state.custom_learning:
                st.session_state.custom_learning = True
                st.session_state.current_topic = "Custom Learning"
                st.session_state.page = CUSTOM_LEARNING["default_page"]
            st.rerun()
    
    with col3:
        topic_view_tab_selected = st.button(
            "🔎 Topic Viewer", 
            use_container_width=True,
            key="topic_view_tab_btn",
            type="primary" if st.session_state.active_sidebar_tab == "Custom Topic Viewing" else "secondary"
        )
        if topic_view_tab_selected:
            st.session_state.active_sidebar_tab = "Custom Topic Viewing"
            # Enable custom learning mode but with topic explorer page
            st.session_state.custom_learning = True
            st.session_state.current_topic = "Custom Learning"
            st.session_state.page = "custom_topic_explorer"  # Force to topic explorer
            st.rerun()
            
    with col4:
        settings_tab_selected = st.button(
            "⚙️ Settings", 
            use_container_width=True,
            key="settings_tab_btn",
            type="primary" if st.session_state.active_sidebar_tab == "Settings" else "secondary"
        )
        if settings_tab_selected:
            st.session_state.active_sidebar_tab = "Settings"
            st.rerun()
    
    st.divider()
    
    # Display content based on selected tab
    if st.session_state.active_sidebar_tab == "Science Topics":
        # SCIENCE TOPICS SECTION
        st.markdown(f"<h2 style='margin-bottom:0.5rem; margin-top:0.5rem;'>Science Topics</h2>", unsafe_allow_html=True)
        
        # Create a list of science topic options with icons
        science_topic_options = list(SCIENCE_TOPICS.keys())
        science_topic_display = [f"{SCIENCE_TOPICS[t]['icon']} {t}" for t in science_topic_options]
        
        # Create the science topic selector
        science_topic_index = science_topic_options.index(st.session_state.current_topic) if st.session_state.current_topic in science_topic_options else 0
        science_topic_display = st.selectbox(
            "Select Science Topic",
            options=science_topic_display,
            index=science_topic_index,
            key="science_topic_selector",
            on_change=change_science_topic
        )
        
        # Extract the actual topic name from the display text (remove icon)
        selected_science_topic = science_topic_display.split(' ', 1)[1]
        
        # Update session state if the science topic changed
        if selected_science_topic != st.session_state.current_topic:
            st.session_state.current_topic = selected_science_topic
            change_science_topic()
            
        # Science Topics Navigation
        st.markdown(f"<h3 style='margin-bottom:0.5rem; margin-top:1rem;'>Navigation</h3>", unsafe_allow_html=True)
        
        # Get current topic data
        current_topic = st.session_state.current_topic
        current_topic_data = SCIENCE_TOPICS[current_topic]
        available_pages = list(current_topic_data["pages"].keys())
        
        # Filter out element_details as it's not a main navigation item
        nav_pages = [page for page in available_pages if page != "element_details"]
        
        # Create navigation options
        nav_options = []
        for page in nav_pages:
            # Use translation if available, or fallback to capitalized page name
            if page in ["home", "periodic_table", "quiz", "quiz_history"]:
                translated_name = get_translation(page)
            else:
                translated_name = page.replace("_", " ").capitalize()
            nav_options.append(translated_name)
            
        # Determine current index
        current_page = st.session_state.page
        try:
            current_index = nav_pages.index(current_page)
        except ValueError:
            current_index = 0
            
        # Use radio buttons for navigation
        nav_option = st.radio(
            "Science Navigation",
            nav_options,
            index=min(current_index, len(nav_options)-1),
            key="science_nav_radio",
            label_visibility="collapsed"
        )
        
        # Handle navigation based on selection
        for i, page_name in enumerate(nav_options):
            page_key = nav_pages[i]
            if nav_option == page_name and st.session_state.page != page_key:
                st.session_state.page = page_key
                st.rerun()
        
        # View Selected Element button if applicable
        if st.session_state.current_topic == "Chemical Elements" and st.session_state.selected_element is not None:
            st.divider()
            if st.button(get_translation("view_selected_element"), use_container_width=True, key="view_selected_element"):
                st.session_state.page = "element_details"
                st.rerun()
                
    elif st.session_state.active_sidebar_tab == "Custom Learning":
        # CUSTOM LEARNING SECTION
        st.markdown(f"<h2 style='margin-bottom:0.5rem; margin-top:0.5rem;'>📚 Custom Learning</h2>", unsafe_allow_html=True)
        
        # Ensure custom learning is enabled
        if not st.session_state.custom_learning:
            st.session_state.custom_learning = True
            st.session_state.current_topic = "Custom Learning"
            st.session_state.page = CUSTOM_LEARNING["default_page"]
            st.rerun()
        
        # Add custom topic selector
        if "custom_topics" not in st.session_state:
            # Get all topics from the system
            all_topics = get_all_topics()
            st.session_state.custom_topics = {
                topic["title"]: {
                    "icon": topic.get("icon", "📚"),
                    "description": topic.get("description", ""),
                    "id": topic.get("id")
                }
                for topic in all_topics
            }
        
        # Check if we have a selected custom topic
        if "selected_custom_topic" not in st.session_state:
            # Default to first topic or None if no topics
            custom_topic_keys = list(st.session_state.custom_topics.keys())
            st.session_state.selected_custom_topic = custom_topic_keys[0] if custom_topic_keys else None
        
        # Create a formatted list of topics with icons
        custom_topic_options = list(st.session_state.custom_topics.keys())
        if custom_topic_options:
            custom_topic_display = [f"{st.session_state.custom_topics[t]['icon']} {t}" for t in custom_topic_options]
            
            # Get current selected topic index
            current_topic_index = 0
            if st.session_state.selected_custom_topic in custom_topic_options:
                current_topic_index = custom_topic_options.index(st.session_state.selected_custom_topic)
            
            # Create the custom topic selector
            st.markdown(f"<h3 style='margin-bottom:0.5rem; margin-top:0.5rem;'>Select Custom Topic</h3>", unsafe_allow_html=True)
            selected_topic_display = st.selectbox(
                "Select Custom Topic",
                options=custom_topic_display,
                index=current_topic_index,
                key="custom_topic_selector",
                help="Select a custom topic to explore"
            )
            
            # Extract the actual topic name from the display text (remove icon)
            selected_topic = selected_topic_display.split(' ', 1)[1]
            
            # Update session state if the topic changed
            if selected_topic != st.session_state.selected_custom_topic:
                st.session_state.selected_custom_topic = selected_topic
                # Set the selected topic ID
                st.session_state.selected_topic_id = st.session_state.custom_topics[selected_topic]["id"]
                st.rerun()
        else:
            st.info("No custom topics available. Create a topic to get started.")
            
        # Custom Learning Navigation - using the filtered navigation pages
        st.markdown(f"<h3 style='margin-bottom:0.5rem; margin-top:1rem;'>Navigation</h3>", unsafe_allow_html=True)
        
        # Get only the pages that should be in the navigation
        nav_pages = CUSTOM_LEARNING["navigation_pages"]
        
        # Create navigation options with custom display names
        nav_options = []
        for page in nav_pages:
            display_name = CUSTOM_LEARNING["page_display_names"].get(page, page.replace("_", " ").capitalize())
            nav_options.append(display_name)
            
        # Determine current index
        current_page = st.session_state.page
        try:
            current_index = nav_pages.index(current_page)
        except ValueError:
            current_index = 0
            
        # Use radio buttons for navigation
        nav_option = st.radio(
            "Custom Learning Navigation",
            nav_options,
            index=min(current_index, len(nav_options)-1),
            key="custom_nav_radio",
            label_visibility="collapsed"
        )
        
        # Handle navigation based on selection
        for i, display_name in enumerate(nav_options):
            page_key = nav_pages[i]
            if nav_option == display_name and st.session_state.page != page_key:
                st.session_state.page = page_key
                st.rerun()
                
    elif st.session_state.active_sidebar_tab == "Custom Topic Viewing":
        # CUSTOM TOPIC VIEWING SECTION - Shows the explorer, quiz, and quiz history for the selected topic
        st.markdown(f"<h2 style='margin-bottom:0.5rem; margin-top:0.5rem;'>🔎 Topic Viewer</h2>", unsafe_allow_html=True)
        
        # Add custom topic selector - same as in Custom Learning
        if "custom_topics" not in st.session_state:
            # Get all topics from the system
            all_topics = get_all_topics()
            st.session_state.custom_topics = {
                topic["title"]: {
                    "icon": topic.get("icon", "📚"),
                    "description": topic.get("description", ""),
                    "id": topic.get("id")
                }
                for topic in all_topics
            }
        
        # Check if we have a selected custom topic
        if "selected_custom_topic" not in st.session_state:
            # Default to first topic or None if no topics
            custom_topic_keys = list(st.session_state.custom_topics.keys())
            st.session_state.selected_custom_topic = custom_topic_keys[0] if custom_topic_keys else None
        
        # Create a formatted list of topics with icons
        custom_topic_options = list(st.session_state.custom_topics.keys())
        if custom_topic_options:
            custom_topic_display = [f"{st.session_state.custom_topics[t]['icon']} {t}" for t in custom_topic_options]
            
            # Get current selected topic index
            current_topic_index = 0
            if st.session_state.selected_custom_topic in custom_topic_options:
                current_topic_index = custom_topic_options.index(st.session_state.selected_custom_topic)
            
            # Create the custom topic selector
            st.markdown(f"<h3 style='margin-bottom:0.5rem; margin-top:0.5rem;'>Select Custom Topic</h3>", unsafe_allow_html=True)
            selected_topic_display = st.selectbox(
                "Select Custom Topic",
                options=custom_topic_display,
                index=current_topic_index,
                key="topic_viewer_selector",
                help="Select a custom topic to explore"
            )
            
            # Extract the actual topic name from the display text (remove icon)
            selected_topic = selected_topic_display.split(' ', 1)[1]
            
            # Update session state if the topic changed
            if selected_topic != st.session_state.selected_custom_topic:
                st.session_state.selected_custom_topic = selected_topic
                # Set the selected topic ID
                st.session_state.selected_topic_id = st.session_state.custom_topics[selected_topic]["id"]
                st.rerun()
            
            # NAVIGATION FOR TOPIC VIEWER
            st.markdown(f"<h3 style='margin-bottom:0.5rem; margin-top:1rem;'>Navigation</h3>", unsafe_allow_html=True)
            
            # Navigation options for the topic viewer
            viewer_options = [
                "Topic Explorer",    # Explore the topic
                "Universal Quiz",    # Take quizzes on this topic
                "Quiz History"       # View quiz history for this topic
            ]
            
            # Initialize selected option if needed
            if "topic_viewer_nav" not in st.session_state:
                st.session_state.topic_viewer_nav = viewer_options[0]
                
            # Create the navigation radio buttons
            selected_viewer_option = st.radio(
                "Topic Viewer Navigation",
                options=viewer_options,
                index=viewer_options.index(st.session_state.topic_viewer_nav),
                key="topic_viewer_nav_radio",
                label_visibility="collapsed"
            )
            
            # Handle navigation based on selection
            if selected_viewer_option != st.session_state.topic_viewer_nav:
                st.session_state.topic_viewer_nav = selected_viewer_option
                
                # Map navigation to pages
                if selected_viewer_option == "Topic Explorer":
                    st.session_state.page = "custom_topic_explorer"
                elif selected_viewer_option == "Universal Quiz":
                    st.session_state.page = "quiz"
                elif selected_viewer_option == "Quiz History":
                    st.session_state.page = "quiz_history"
                    
                st.rerun()
                
            # Return to Custom Learning button
            st.divider()
            if st.button("Return to Custom Learning", use_container_width=True, key="return_to_custom_learning"):
                st.session_state.active_sidebar_tab = "Custom Learning"
                st.rerun()
        else:
            st.info("No custom topics available. Create a topic to get started.")
            
            # Return to Custom Learning button
            if st.button("Go to Custom Learning", use_container_width=True, key="go_to_custom_learning"):
                st.session_state.active_sidebar_tab = "Custom Learning"
                st.rerun()
                
    elif st.session_state.active_sidebar_tab == "Settings":
        # SETTINGS SECTION
        st.markdown(f"<h2 style='margin-bottom:0.5rem; margin-top:0.5rem;'>{get_translation('settings')}</h2>", unsafe_allow_html=True)
        
        # Language selector
        st.markdown(f"<h3 style='margin-bottom:0.5rem; margin-top:1rem;'>{get_translation('language_selector')}</h3>", unsafe_allow_html=True)
        selected_language = st.selectbox(
            get_translation('select_language'),
            options=list(TRANSLATIONS.keys()),
            index=list(TRANSLATIONS.keys()).index(st.session_state.language),
            key="language_selector",
            on_change=change_language
        )
        
        # Update the language in session state if changed
        if selected_language != st.session_state.language:
            st.session_state.language = selected_language
        
        # Display settings
        st.markdown(f"<h3 style='margin-bottom:0.5rem; margin-top:1rem;'>{get_translation('display_mode')}</h3>", unsafe_allow_html=True)
        mobile_mode = st.toggle(
            get_translation('mobile_mode'),
            value=st.session_state.mobile_mode,
            key="mobile_mode_toggle",
            help=get_translation('mobile_mode_help')
        )
        
        if mobile_mode != st.session_state.mobile_mode:
            st.session_state.mobile_mode = mobile_mode
            st.rerun()
    
    # Add user account section to every tab
    st.divider()
    st.markdown("<h3 style='text-align:center'>⭐ User Access</h3>", unsafe_allow_html=True)
    
    # Display login status and buttons
    if "username" in st.session_state and st.session_state.username:
        # User is logged in
        st.success(f"👤 {get_translation('logged_in_as', 'Logged in as')}: {st.session_state.username}")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Go to account management
            if st.button(get_translation("account", "Account"), use_container_width=True, key="sidebar_account_btn"):
                st.session_state.page = "account"
                st.rerun()
        
        with col2:
            # Logout button
            if st.button(get_translation("logout", "Logout"), use_container_width=True, key="sidebar_logout_btn"):
                # Clear user session data
                if "username" in st.session_state:
                    del st.session_state.username
                if "user_id" in st.session_state:
                    del st.session_state.user_id
                st.rerun()
    else:
        # User is not logged in
        st.info(get_translation("not_logged_in", "You are not logged in"))
        
        if st.button(get_translation("login_register", "Login / Register"), use_container_width=True, key="sidebar_login_btn"):
            st.session_state.page = "login"
            st.rerun()
    
    # Move the copyright to the bottom with CSS
    st.markdown(
        f"""
        <div style="position: fixed; bottom: 0; left: 0; padding: 1rem; width: 100%; text-align: center; font-size: 0.8rem; color: #888;">
            {get_translation("copyright")}
        </div>
        """, 
        unsafe_allow_html=True
    )

# Make sure we have a current topic defined
if "current_topic" not in st.session_state:
    st.session_state.current_topic = "Chemical Elements"
current_topic = st.session_state.current_topic

# Set up app title based on current mode
if st.session_state.custom_learning:
    # Show Custom Learning title
    current_title = "Custom Learning"
    current_icon = CUSTOM_LEARNING["icon"]
else:
    # Show regular topic title
    current_title = f"{current_topic} Explorer"
    current_icon = SCIENCE_TOPICS[current_topic]["icon"]

# Create a header with application title and account access
col1, col2 = st.columns([3, 1])

with col1:
    # Display title
    st.title(f"{current_icon} {current_title}")

with col2:
    # Add prominent login/account access buttons
    st.markdown("<br>", unsafe_allow_html=True)  # Add some space
    
    if "username" in st.session_state and st.session_state.username:
        # Show user is logged in with Account button
        if st.button("👤 " + st.session_state.username, use_container_width=True, key="header_account_button"):
            # Force specific login page and immediate rerun
            st.session_state.page = "login"
            st.rerun()
    else:
        # Show Login button
        if st.button("🔑 " + get_translation("login", "Login"), use_container_width=True, key="header_login_button"):
            # Force specific login page and immediate rerun
            st.session_state.page = "login"
            st.rerun()

# Get the pages for the current mode
current_page = st.session_state.page
current_topic = st.session_state.current_topic

# Determine which page set to use based on custom learning mode
if st.session_state.custom_learning:
    render_pages = CUSTOM_LEARNING["pages"]
    default_page = CUSTOM_LEARNING["default_page"]
else:
    render_pages = SCIENCE_TOPICS[current_topic]["pages"]
    default_page = SCIENCE_TOPICS[current_topic]["default_page"]

# Direct override for critical pages
if current_page == "login":
    # Always render login page regardless of topic
    login_render()
elif current_page == "account":
    # Always render account page if requested
    account_render()
elif current_page in render_pages:
    # Call the render function for the current page
    render_pages[current_page]()
else:
    # If the page isn't available, default to home
    st.session_state.page = default_page
    st.rerun()