"""
Module containing the elements data and helper functions
for accessing and filtering the data.
"""

import pandas as pd
import numpy as np

# Define element categories and their colors
CATEGORIES = {
    "alkali metal": "#FF6B6B",
    "alkaline earth metal": "#4ECDC4",
    "transition metal": "#F9844A",
    "post-transition metal": "#4A90E2",
    "metalloid": "#9775FA",
    "nonmetal": "#28C76F",
    "halogen": "#FF9F43",
    "noble gas": "#7367F0",
    "lanthanide": "#CE9178",
    "actinide": "#A3A4A8",
    "unknown": "#CCCCCC"
}

# Korean category translations
CATEGORY_TRANSLATIONS = {
    "alkali metal": "알칼리 금속",
    "alkaline earth metal": "알칼리 토금속",
    "transition metal": "전이 금속",
    "post-transition metal": "후전이 금속",
    "metalloid": "준금속",
    "nonmetal": "비금속",
    "halogen": "할로겐",
    "noble gas": "비활성 기체",
    "lanthanide": "란타넘족",
    "actinide": "악티늄족",
    "unknown": "미확인"
}

# Create a comprehensive elements dataset
def create_elements_data():
    """Create a comprehensive dataset of chemical elements"""
    elements_data = [
        {"atomic_number": 1, "symbol": "H", "name": "Hydrogen", "korean_name": "수소", "atomic_weight": 1.008, "category": "nonmetal", "group": 1, "period": 1,
         "electron_configuration": "1s¹", "electronegativity": 2.20, "density": 0.00008988, "melting_point": 14.01, "boiling_point": 20.28,
         "discovery_year": 1766, "discovered_by": "Henry Cavendish", 
         "description": "Hydrogen is the lightest element. Under ordinary conditions, it is a colorless, odorless, tasteless, non-toxic, nonmetallic, highly combustible gas with the molecular formula H₂.",
         "beginner_description": "Hydrogen is the simplest and most common element in the universe. It's a gas that makes up most of the Sun and stars. On Earth, we use it in fuel and in making important chemicals.",
         "advanced_description": "Hydrogen (atomic number 1) is the most abundant chemical substance in the universe, constituting roughly 75% of all baryonic mass. It exists as a diatomic gas (H₂) under standard conditions and is highly flammable when mixed with oxygen. Hydrogen's electron configuration (1s¹) gives it unique properties as it can lose its electron to form H+ (proton), gain an electron to form H- (hydride), or share its electron to form covalent bonds. It has three isotopes: protium (¹H), deuterium (²H), and tritium (³H), with the latter being radioactive. Hydrogen plays a crucial role in fusion processes that power stars and is being explored as a clean energy carrier."},
        
        {"atomic_number": 2, "symbol": "He", "name": "Helium", "korean_name": "헬륨", "atomic_weight": 4.0026, "category": "noble gas", "group": 18, "period": 1,
         "electron_configuration": "1s²", "electronegativity": None, "density": 0.0001785, "melting_point": 0.95, "boiling_point": 4.22,
         "discovery_year": 1868, "discovered_by": "Pierre Janssen, Norman Lockyer", 
         "description": "Helium is a colorless, odorless, tasteless, non-toxic, inert, monatomic gas. It is the first in the noble gas group in the periodic table and its boiling point is the lowest among all the elements.",
         "beginner_description": "Helium is the gas that makes balloons float. It's very light and safe to breathe in small amounts, which is why it can make your voice sound funny. It's found deep underground and is used in birthday balloons and airships.",
         "advanced_description": "Helium is the second element in the periodic table with atomic number 2. It has two protons and two electrons in a completed 1s orbital, making it extremely stable and chemically inert. It has the lowest boiling point of any element at -268.9°C and cannot be solidified at standard pressure. Helium is produced by radioactive decay in the Earth's crust and is harvested from natural gas reserves. It's critical for cooling superconducting magnets in MRI machines and has applications in cryogenics, leak detection, and pressurizing rocket fuel systems."},
        
        {"atomic_number": 3, "symbol": "Li", "name": "Lithium", "korean_name": "리튬", "atomic_weight": 6.94, "category": "alkali metal", "group": 1, "period": 2,
         "electron_configuration": "[He] 2s¹", "electronegativity": 0.98, "density": 0.534, "melting_point": 453.69, "boiling_point": 1560,
         "discovery_year": 1817, "discovered_by": "Johan August Arfwedson", 
         "description": "Lithium is a chemical element with the symbol Li and atomic number 3. It is a soft, silvery-white alkali metal. Under standard conditions, it is the lightest metal and the lightest solid element.",
         "beginner_description": "Lithium is a soft, silver-colored metal that's very light. It's used in rechargeable batteries for phones, laptops, and electric cars. Doctors also use lithium as a medicine to help people with certain mood disorders.",
         "advanced_description": "Lithium (atomic number 3) is the lightest alkali metal and third element in the periodic table. With a single valence electron in its 2s orbital ([He]2s¹), it readily forms ionic compounds by losing this electron. Despite its low atomic mass of 6.94 amu, lithium has an unusually high melting point (180.5°C) compared to other alkali metals due to its small atomic radius and strong metallic bonding. Lithium compounds are widely used in rechargeable batteries, where the high electrochemical potential and large energy-to-weight ratio make it ideal for energy storage. Lithium-6 and lithium-7 are its two stable isotopes, with lithium-7 being the predominant one (92.5% natural abundance)."},
        
        {"atomic_number": 4, "symbol": "Be", "name": "Beryllium", "korean_name": "베릴륨", "atomic_weight": 9.0122, "category": "alkaline earth metal", "group": 2, "period": 2,
         "electron_configuration": "[He] 2s²", "electronegativity": 1.57, "density": 1.85, "melting_point": 1560, "boiling_point": 2742,
         "discovery_year": 1798, "discovered_by": "Louis Nicolas Vauquelin", 
         "description": "Beryllium is a relatively rare element in the universe. It is a divalent element which occurs naturally only in combination with other elements in minerals.",
         "beginner_description": "Beryllium is a light, strong metal that's often mixed with other metals to make them stronger. It's used in things like springs, electrical contacts, and aerospace parts. It's rare and can be harmful if its dust is breathed in.",
         "advanced_description": "Beryllium (atomic number 4) is an alkaline earth metal with electron configuration [He]2s². Despite its low atomic number, it has an unusually high melting point (1287°C) and exceptional stiffness-to-weight ratio. Beryllium has one of the highest thermal conductivities among metals yet is transparent to X-rays, making it valuable for X-ray windows in medical and scientific instruments. It forms a passive oxide layer (BeO) that protects it from corrosion. Its toxicity in particulate form presents occupational hazards, as inhalation can cause chronic beryllium disease. In nuclear applications, beryllium serves as a neutron reflector and moderator due to its low neutron absorption and high scattering properties."},
        
        {"atomic_number": 5, "symbol": "B", "name": "Boron", "korean_name": "붕소", "atomic_weight": 10.81, "category": "metalloid", "group": 13, "period": 2,
         "electron_configuration": "[He] 2s² 2p¹", "electronegativity": 2.04, "density": 2.34, "melting_point": 2349, "boiling_point": 4200,
         "discovery_year": 1808, "discovered_by": "Joseph Louis Gay-Lussac, Louis Jacques Thénard, Humphry Davy", 
         "description": "Boron is a chemical element with the symbol B and atomic number 5. Produced entirely by cosmic ray spallation and supernovae, it is a low-abundance element in the Solar System and in the Earth's crust.",
         "beginner_description": "Boron is a dark powder that is used in many household products like laundry detergent and as a bug killer. It's also found in some foods like nuts and beans. Some forms of boron are very hard and used to make sports equipment like tennis rackets.",
         "advanced_description": "Boron (atomic number 5) is a metalloid with electron configuration [He]2s²2p¹, possessing properties of both metals and nonmetals. Its most distinctive feature is its electron deficiency, with only three valence electrons available for bonding, leading to unique molecular structures including three-center, two-electron bonds in boranes. Boron forms strong covalent bonds and creates complex compounds including borosilicate glass, boron carbide (one of the hardest known materials), and boron nitride (which forms structures similar to carbon). Isotopically, natural boron consists of two stable isotopes, ¹⁰B and ¹¹B, with the former having significant neutron-capturing capabilities used in nuclear applications. Boron is essential for plant growth but has a narrow range between deficiency and toxicity in biological systems."},
        
        {"atomic_number": 6, "symbol": "C", "name": "Carbon", "korean_name": "탄소", "atomic_weight": 12.011, "category": "nonmetal", "group": 14, "period": 2,
         "electron_configuration": "[He] 2s² 2p²", "electronegativity": 2.55, "density": 2.267, "melting_point": 3800, "boiling_point": 4300,
         "discovery_year": None, "discovered_by": "Ancient civilizations", 
         "description": "Carbon is a chemical element with the symbol C and atomic number 6. It is nonmetallic and tetravalent—making four electrons available to form covalent chemical bonds. It belongs to group 14 of the periodic table.",
         "beginner_description": "Carbon is an element found in all living things. It makes up the basic building blocks of life. You can find carbon in different forms like graphite (pencil lead), diamond, and coal. It's what makes plants and animals grow.",
         "advanced_description": "Carbon, with atomic number 6, is the foundation of organic chemistry and biochemistry. It has a unique ability to form strong covalent bonds with itself and other elements, creating long chains, rings, and complex 3D structures. Carbon exists in several allotropes including diamond (sp³ hybridization), graphite (sp² hybridization), and fullerenes. Its electron configuration [He]2s²2p² allows it to form four bonds, making it exceptionally versatile in forming millions of organic compounds. The carbon cycle is fundamental to Earth's biogeochemical processes, with carbon-14 being crucial in radiocarbon dating."},
        
        {"atomic_number": 7, "symbol": "N", "name": "Nitrogen", "korean_name": "질소", "atomic_weight": 14.007, "category": "nonmetal", "group": 15, "period": 2,
         "electron_configuration": "[He] 2s² 2p³", "electronegativity": 3.04, "density": 0.0012506, "melting_point": 63.15, "boiling_point": 77.36,
         "discovery_year": 1772, "discovered_by": "Daniel Rutherford", 
         "description": "Nitrogen is a chemical element with the symbol N and atomic number 7. It was first discovered and isolated by Scottish physician Daniel Rutherford in 1772. It is the fifth most abundant element in the universe.",
         "beginner_description": "Nitrogen is a gas that makes up most of the air we breathe (about 78%). Plants need nitrogen to grow, which is why it's in fertilizers. Liquid nitrogen is extremely cold and is used to freeze things very quickly.",
         "advanced_description": "Nitrogen (atomic number 7) has electron configuration [He]2s²2p³, with its three unpaired electrons making it moderately reactive. At standard conditions, it exists as diatomic N₂ molecules with a strong triple bond (946 kJ/mol), one of the strongest in nature, making molecular nitrogen relatively inert. This stability explains why nitrogen gas constitutes 78% of Earth's atmosphere. Nitrogen undergoes a complex biogeochemical cycle, being fixed by bacteria into ammonia, then oxidized to nitrites and nitrates before returning to the atmosphere through denitrification. Industrially, the Haber-Bosch process converts atmospheric nitrogen to ammonia for fertilizer production, a process crucial for supporting global agriculture. Nitrogen forms oxides with various oxidation states from +1 to +5, and its compounds play vital roles in biochemistry, including amino acids, nucleic acids, and proteins."},
        
        {"atomic_number": 8, "symbol": "O", "name": "Oxygen", "korean_name": "산소", "atomic_weight": 15.999, "category": "nonmetal", "group": 16, "period": 2,
         "electron_configuration": "[He] 2s² 2p⁴", "electronegativity": 3.44, "density": 0.001429, "melting_point": 54.36, "boiling_point": 90.20,
         "discovery_year": 1774, "discovered_by": "Carl Wilhelm Scheele, Joseph Priestley", 
         "description": "Oxygen is a chemical element with the symbol O and atomic number 8. It is a member of the chalcogen group in the periodic table, a highly reactive nonmetal, and an oxidizing agent that readily forms oxides with most elements.",
         "beginner_description": "Oxygen is the air element we need to breathe to stay alive. Plants make oxygen, and we breathe it in. It makes up about 21% of the air around us. Without oxygen, fires can't burn.",
         "advanced_description": "Oxygen (atomic number 8) is critical for cellular respiration in aerobic organisms. Its electron configuration [He]2s²2p⁴ makes it highly electronegative (3.44 on the Pauling scale), readily forming oxide compounds with most elements. Molecular oxygen (O₂) contains a double bond and exists as a diradical with two unpaired electrons, making it paramagnetic. Oxygen has three stable isotopes (¹⁶O, ¹⁷O, and ¹⁸O) and is produced in stars through the CNO cycle. It's essential for combustion processes and constitutes approximately 21% of Earth's atmosphere by volume."},
        
        {"atomic_number": 9, "symbol": "F", "name": "Fluorine", "korean_name": "플루오린", "atomic_weight": 18.998, "category": "halogen", "group": 17, "period": 2,
         "electron_configuration": "[He] 2s² 2p⁵", "electronegativity": 3.98, "density": 0.001696, "melting_point": 53.53, "boiling_point": 85.03,
         "discovery_year": 1886, "discovered_by": "Henri Moissan", 
         "description": "Fluorine is a chemical element with the symbol F and atomic number 9. It is the lightest halogen and exists as a highly toxic pale yellow diatomic gas at standard conditions.",
         "beginner_description": "Fluorine is a gas that's extremely reactive and dangerous. It's used in toothpaste (as fluoride) to help protect teeth from cavities. It's also used in making non-stick cookware and many other products.",
         "advanced_description": "Fluorine (atomic number 9) is the most electronegative element (3.98 on the Pauling scale) with electron configuration [He]2s²2p⁵. This extreme electronegativity makes it the most reactive non-metal, vigorously attacking even gold and platinum. At standard conditions, fluorine exists as a pale yellow diatomic gas (F₂) that is highly toxic and corrosive. It forms compounds with almost all elements (except helium and neon), typically achieving a stable octet by gaining one electron to form F⁻ ions. Fluorine compounds are widely used in applications ranging from water fluoridation (to prevent dental caries) to the production of polymers like polytetrafluoroethylene (PTFE/Teflon). The element has one stable isotope, fluorine-19, and is produced industrially through the electrolysis of potassium bifluoride."},
        
        {"atomic_number": 10, "symbol": "Ne", "name": "Neon", "korean_name": "네온", "atomic_weight": 20.180, "category": "noble gas", "group": 18, "period": 2,
         "electron_configuration": "[He] 2s² 2p⁶", "electronegativity": None, "density": 0.0008999, "melting_point": 24.56, "boiling_point": 27.07,
         "discovery_year": 1898, "discovered_by": "William Ramsay, Morris Travers", 
         "description": "Neon is a chemical element with the symbol Ne and atomic number 10. It is a noble gas. Neon is a colorless, odorless, inert monatomic gas under standard conditions, with about two-thirds the density of air.",
         "beginner_description": "Neon is a colorless gas that glows bright orange-red when electricity passes through it. It's used to make the colorful glowing signs you see in store windows and advertisements. Neon doesn't react with other elements.",
         "advanced_description": "Neon (atomic number 10) is the second noble gas in the periodic table with electron configuration [He]2s²2p⁶, representing a complete outer shell that makes it extremely non-reactive. It has the narrowest liquid range of any element (2.6°C) between its melting point (-248.6°C) and boiling point (-246.0°C). When electricity is passed through neon gas in a discharge tube, it produces a distinctive bright orange-red glow, with the highest number of spectral lines of all the elements. Unlike most other noble gases, neon forms no known stable compounds. It is commercially extracted from liquid air through fractional distillation and used primarily in neon signs, lasers, and as a cryogenic refrigerant. Neon has three stable isotopes, with neon-20 being the most abundant (90.5%)."},
        
        # Adding more elements (abbreviated list for brevity)
        {"atomic_number": 11, "symbol": "Na", "name": "Sodium", "korean_name": "나트륨", "atomic_weight": 22.990, "category": "alkali metal", "group": 1, "period": 3,
         "electron_configuration": "[Ne] 3s¹", "electronegativity": 0.93, "density": 0.971, "melting_point": 370.87, "boiling_point": 1156,
         "discovery_year": 1807, "discovered_by": "Humphry Davy", 
         "description": "Sodium is a chemical element with the symbol Na and atomic number 11. It is a soft, silvery-white, highly reactive metal.",
         "beginner_description": "Sodium is a soft, silver-colored metal that reacts strongly with water. You know it best as part of table salt (sodium chloride). Your body needs some sodium for your nerves and muscles to work properly, but too much can be unhealthy.",
         "advanced_description": "Sodium (atomic number 11) is the sixth most abundant element in Earth's crust, with electron configuration [Ne]3s¹. This single valence electron makes it highly reactive, readily losing this electron to form Na⁺ ions in compounds. Pure sodium metal reacts violently with water, producing hydrogen gas and sodium hydroxide in an exothermic reaction that often ignites the hydrogen. Sodium is essential for biological functions, particularly nerve impulse transmission and fluid balance through the sodium-potassium pump. The element was isolated by Humphry Davy in 1807 through electrolysis of sodium hydroxide. Industrially, sodium compounds are vital in numerous applications, including glass manufacturing (sodium carbonate), soap production (sodium hydroxide), and as a heat transfer medium in certain nuclear reactors (liquid sodium)."},
        
        {"atomic_number": 12, "symbol": "Mg", "name": "Magnesium", "korean_name": "마그네슘", "atomic_weight": 24.305, "category": "alkaline earth metal", "group": 2, "period": 3,
         "electron_configuration": "[Ne] 3s²", "electronegativity": 1.31, "density": 1.738, "melting_point": 923, "boiling_point": 1363,
         "discovery_year": 1808, "discovered_by": "Humphry Davy", 
         "description": "Magnesium is a chemical element with the symbol Mg and atomic number 12. It is a shiny gray solid which bears a close physical resemblance to the other five elements in the second column of the periodic table.",
         "beginner_description": "Magnesium is a light, silver-white metal that burns with a bright white flame. It's used in fireworks and flares. Your body needs magnesium for healthy bones and muscles. It's found in green vegetables, nuts, and seeds.",
         "advanced_description": "Magnesium (atomic number 12) is an alkaline earth metal with electron configuration [Ne]3s². It's the eighth most abundant element in Earth's crust (2.1%) and the third most abundant element dissolved in seawater. Magnesium has high thermal and electrical conductivity and a relatively low density (1.74 g/cm³), making it valuable for lightweight structural applications, particularly in aluminum alloys used in aerospace and automotive industries. In biological systems, magnesium ions (Mg²⁺) play a critical role as cofactors in over 300 enzymatic reactions and are essential for DNA and RNA stability. Magnesium is also the central atom in chlorophyll, the molecule responsible for photosynthesis in plants. The element burns with a characteristic brilliant white light and was historically used in photography flash bulbs."},
        
        # Add more elements to make the dataset more comprehensive
        # Adding key elements from various parts of the periodic table
        
        {"atomic_number": 17, "symbol": "Cl", "name": "Chlorine", "korean_name": "염소", "atomic_weight": 35.45, "category": "halogen", "group": 17, "period": 3,
         "electron_configuration": "[Ne] 3s² 3p⁵", "electronegativity": 3.16, "density": 0.003214, "melting_point": 171.6, "boiling_point": 239.11,
         "discovery_year": 1774, "discovered_by": "Carl Wilhelm Scheele", 
         "description": "Chlorine is a chemical element with the symbol Cl and atomic number 17. The second-lightest of the halogens, it appears between fluorine and bromine in the periodic table and its properties are mostly intermediate between them.",
         "beginner_description": "Chlorine is a greenish-yellow gas with a strong smell. It's used to keep swimming pools clean and to purify drinking water. When combined with sodium, it makes table salt (sodium chloride). Pure chlorine gas can be harmful to breathe.",
         "advanced_description": "Chlorine (atomic number 17) is a halogen with electron configuration [Ne]3s²3p⁵, making it highly electronegative (3.16 on the Pauling scale) and reactive. At standard conditions, it exists as a diatomic gas (Cl₂) with a characteristic yellow-green color and pungent odor. Chlorine readily forms the chloride ion (Cl⁻) by gaining an electron to achieve a stable octet configuration. It's the 21st most abundant element in Earth's crust, primarily found in salt deposits as sodium chloride. Industrially, chlorine is produced through the electrolysis of sodium chloride solutions and is essential in water treatment, disinfection, and the production of numerous organic compounds including PVC. Chlorine has two stable isotopes (³⁵Cl and ³⁷Cl) and can exist in various oxidation states from -1 to +7, making it versatile in chemical reactions."},
        
        {"atomic_number": 26, "symbol": "Fe", "name": "Iron", "korean_name": "철", "atomic_weight": 55.845, "category": "transition metal", "group": 8, "period": 4,
         "electron_configuration": "[Ar] 3d⁶ 4s²", "electronegativity": 1.83, "density": 7.874, "melting_point": 1538, "boiling_point": 3134,
         "discovery_year": None, "discovered_by": "Ancient civilizations", 
         "description": "Iron is a chemical element with symbol Fe and atomic number 26. It is a metal that belongs to the first transition series and group 8 of the periodic table. It is by mass the most common element on Earth, and is the fourth most common element in the Earth's crust.",
         "beginner_description": "Iron is a strong metal used to make tools, buildings, and vehicles. It's what makes your blood red because it helps carry oxygen around your body. Iron is found in the Earth's crust and is one of the most common metals in the world.",
         "advanced_description": "Iron (atomic number 26) is the most abundant element by mass in the Earth, forming much of the planet's inner and outer core. Its electron configuration [Ar]3d⁶4s² contributes to its ferromagnetic properties below the Curie temperature of 770°C. Iron exists in multiple oxidation states, primarily +2 and +3, and forms numerous compounds essential to biological and industrial processes. In biological systems, iron is crucial for oxygen transport via hemoglobin and plays a key role in electron transfer reactions. Industrially, iron is processed into steel through carbon addition and is fundamental to modern infrastructure. The element undergoes corrosion in moist environments, forming iron oxides (rust)."},
        
        {"atomic_number": 29, "symbol": "Cu", "name": "Copper", "korean_name": "구리", "atomic_weight": 63.546, "category": "transition metal", "group": 11, "period": 4,
         "electron_configuration": "[Ar] 3d¹⁰ 4s¹", "electronegativity": 1.90, "density": 8.96, "melting_point": 1357.77, "boiling_point": 2835,
         "discovery_year": None, "discovered_by": "Ancient civilizations", 
         "description": "Copper is a chemical element with the symbol Cu and atomic number 29. It is a soft, malleable, and ductile metal with very high thermal and electrical conductivity.",
         "beginner_description": "Copper is a reddish-brown metal used to make electrical wires, water pipes, and coins. It's a good conductor of electricity and heat. When copper is exposed to air for a long time, it turns green (like the Statue of Liberty).",
         "advanced_description": "Copper (atomic number 29) has a distinctive reddish-orange metallic luster and the electron configuration [Ar]3d¹⁰4s¹. It has exceptional thermal and electrical conductivity (second only to silver), which makes it essential for electrical wiring and electronics. As a transition metal, copper can exist in multiple oxidation states, primarily +1 and +2, with Cu²⁺ compounds typically blue or green in color. Copper is naturally bacteriostatic, meaning it inhibits bacterial growth on its surface. It was one of the first metals used by humans (dating back to 8000 BCE) and was crucial in the Bronze Age when alloyed with tin. In biological systems, copper serves as a cofactor for numerous enzymes and is essential for cellular respiration, neurotransmitter synthesis, and iron metabolism. The metal naturally occurs in Earth's crust in various copper ores including chalcopyrite, bornite, and malachite."},
        
        {"atomic_number": 47, "symbol": "Ag", "name": "Silver", "korean_name": "은", "atomic_weight": 107.87, "category": "transition metal", "group": 11, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰ 5s¹", "electronegativity": 1.93, "density": 10.49, "melting_point": 1234.93, "boiling_point": 2435,
         "discovery_year": None, "discovered_by": "Ancient civilizations", 
         "description": "Silver is a chemical element with the symbol Ag and atomic number 47. A soft, white, lustrous transition metal, it exhibits the highest electrical conductivity, thermal conductivity, and reflectivity of any metal.",
         "beginner_description": "Silver is a shiny, white metal used to make jewelry, coins, and silverware. It's the best metal for conducting electricity and heat. Silver tarnishes (turns black) when exposed to air, which is why silver items need polishing to stay shiny.",
         "advanced_description": "Silver (atomic number 47) has the highest electrical and thermal conductivity of any element with electron configuration [Kr]4d¹⁰5s¹. This transition metal is relatively rare in Earth's crust (0.075 ppm) but has been valued throughout human history for its lustrous appearance and malleability. Silver primarily exists in the +1 oxidation state in compounds, forming colorless Ag⁺ ions. Silver halides are notably light-sensitive, which made them fundamental to traditional photography. The metal has significant antimicrobial properties, leading to applications in medicine and water purification. Silver readily forms alloys with other metals, with sterling silver (92.5% silver, 7.5% copper) being the most common for jewelry and tableware. Despite its resistance to oxidation, silver tarnishes in air containing sulfur compounds, forming a black layer of silver sulfide on the surface."},
        


        {"atomic_number": 92, "symbol": "U", "name": "Uranium", "korean_name": "우라늄", "atomic_weight": 238.03, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f³ 6d¹ 7s²", "electronegativity": 1.38, "density": 19.1, "melting_point": 1405.3, "boiling_point": 4404,
         "discovery_year": 1789, "discovered_by": "Martin Heinrich Klaproth", "description": "Uranium is a chemical element with the symbol U and atomic number 92. It is a silvery-grey metal in the actinide series of the periodic table. A uranium atom has 92 protons and 92 electrons, of which 6 are valence electrons."},
         
        # Additional elements to make the dataset more comprehensive
        {"atomic_number": 13, "symbol": "Al", "name": "Aluminum", "korean_name": "알루미늄", "atomic_weight": 26.982, "category": "post-transition metal", "group": 13, "period": 3,
         "electron_configuration": "[Ne] 3s² 3p¹", "electronegativity": 1.61, "density": 2.70, "melting_point": 933.47, "boiling_point": 2743,
         "discovery_year": 1825, "discovered_by": "Hans Christian Ørsted", 
         "description": "Aluminum is a silvery-white, soft, non-magnetic and ductile metal in the boron group. It is the third most abundant element in the Earth's crust after oxygen and silicon.",
         "beginner_description": "Aluminum is a lightweight, silver-colored metal used to make cans, foil, airplane parts, and many everyday items. It doesn't rust like iron but forms a thin protective layer when exposed to air. Aluminum is easy to recycle.",
         "advanced_description": "Aluminum (atomic number 13) has electron configuration [Ne]3s²3p¹ and is the most abundant metal in Earth's crust (8.1%). Despite this abundance, it wasn't isolated until 1825 due to its strong affinity for oxygen and tendency to form extremely stable compounds. Pure aluminum is characterized by its low density (2.7 g/cm³, approximately one-third that of steel), excellent thermal and electrical conductivity, and high reflectivity. Upon exposure to air, aluminum rapidly forms a thin, transparent oxide layer (Al₂O₃) that prevents further oxidation, making it highly corrosion-resistant. The Hall–Héroult electrolytic process, developed in 1886, enabled commercial production by reducing aluminum oxide in molten cryolite. Aluminum's combination of low density and high strength makes it crucial for aerospace applications, while its recyclability (requiring only 5% of the energy needed for primary production) makes it environmentally significant."},
         
        {"atomic_number": 14, "symbol": "Si", "name": "Silicon", "korean_name": "규소", "atomic_weight": 28.085, "category": "metalloid", "group": 14, "period": 3,
         "electron_configuration": "[Ne] 3s² 3p²", "electronegativity": 1.90, "density": 2.33, "melting_point": 1687, "boiling_point": 3538,
         "discovery_year": 1824, "discovered_by": "Jöns Jacob Berzelius", "description": "Silicon is a chemical element with the symbol Si and atomic number 14. It is a hard, brittle crystalline solid with a blue-grey metallic lustre, and is a tetravalent metalloid and semiconductor."},
        
        {"atomic_number": 15, "symbol": "P", "name": "Phosphorus", "korean_name": "인", "atomic_weight": 30.974, "category": "nonmetal", "group": 15, "period": 3,
         "electron_configuration": "[Ne] 3s² 3p³", "electronegativity": 2.19, "density": 1.82, "melting_point": 317.3, "boiling_point": 553.6,
         "discovery_year": 1669, "discovered_by": "Hennig Brand", "description": "Phosphorus is a chemical element with the symbol P and atomic number 15. Elemental phosphorus exists in two major forms, white phosphorus and red phosphorus."},
        
        {"atomic_number": 16, "symbol": "S", "name": "Sulfur", "korean_name": "황", "atomic_weight": 32.06, "category": "nonmetal", "group": 16, "period": 3,
         "electron_configuration": "[Ne] 3s² 3p⁴", "electronegativity": 2.58, "density": 2.07, "melting_point": 388.36, "boiling_point": 717.87,
         "discovery_year": None, "discovered_by": "Ancient civilizations", "description": "Sulfur is a chemical element with the symbol S and atomic number 16. It is abundant, multivalent and nonmetallic. Under normal conditions, sulfur atoms form cyclic octatomic molecules with a chemical formula S₈."},
        
        {"atomic_number": 18, "symbol": "Ar", "name": "Argon", "korean_name": "아르곤", "atomic_weight": 39.948, "category": "noble gas", "group": 18, "period": 3,
         "electron_configuration": "[Ne] 3s² 3p⁶", "electronegativity": None, "density": 0.001784, "melting_point": 83.80, "boiling_point": 87.30,
         "discovery_year": 1894, "discovered_by": "Lord Rayleigh, Sir William Ramsay", "description": "Argon is a chemical element with the symbol Ar and atomic number 18. It is in group 18 of the periodic table and is a noble gas. Argon is the third-most abundant gas in the Earth's atmosphere."},
        
        {"atomic_number": 20, "symbol": "Ca", "name": "Calcium", "korean_name": "칼슘", "atomic_weight": 40.078, "category": "alkaline earth metal", "group": 2, "period": 4,
         "electron_configuration": "[Ar] 4s²", "electronegativity": 1.00, "density": 1.55, "melting_point": 1115, "boiling_point": 1757,
         "discovery_year": 1808, "discovered_by": "Humphry Davy", 
         "description": "Calcium is a chemical element with the symbol Ca and atomic number 20. As an alkaline earth metal, calcium is a reactive metal that forms a dark oxide-nitride layer when exposed to air.",
         "beginner_description": "Calcium is a silver-colored metal that's essential for building strong bones and teeth. It's found in dairy products like milk and cheese. Calcium compounds are used to make cement, plaster, and chalk.",
         "advanced_description": "Calcium (atomic number 20) is the fifth most abundant element in Earth's crust with electron configuration [Ar]4s². This alkaline earth metal readily forms the Ca²⁺ ion, which plays critical roles in biological systems. Calcium is essential for bone and teeth formation, with hydroxyapatite (Ca₁₀(PO₄)₆(OH)₂) being the primary mineral component. In cellular biology, calcium ions serve as important secondary messengers, regulating muscle contraction, nerve impulse transmission, and enzyme activity. The element was isolated by Humphry Davy in 1808 through electrolysis of lime. Industrially, calcium compounds are vital to cement production (calcium carbonate), agriculture (lime), and construction materials. Pure calcium metal is silvery-white and relatively soft but reacts rapidly with oxygen and water, making it rarely found in its elemental form in nature."},
        
        {"atomic_number": 30, "symbol": "Zn", "name": "Zinc", "korean_name": "아연", "atomic_weight": 65.38, "category": "transition metal", "group": 12, "period": 4,
         "electron_configuration": "[Ar] 3d¹⁰ 4s²", "electronegativity": 1.65, "density": 7.14, "melting_point": 692.68, "boiling_point": 1180,
         "discovery_year": None, "discovered_by": "Indian metallurgists", "description": "Zinc is a chemical element with the symbol Zn and atomic number 30. Zinc is a slightly brittle metal at room temperature and has a blue-silvery appearance when oxidation is removed."},
        
        {"atomic_number": 35, "symbol": "Br", "name": "Bromine", "korean_name": "브로민", "atomic_weight": 79.904, "category": "halogen", "group": 17, "period": 4,
         "electron_configuration": "[Ar] 3d¹⁰ 4s² 4p⁵", "electronegativity": 2.96, "density": 3.1028, "melting_point": 265.8, "boiling_point": 332.0,
         "discovery_year": 1825, "discovered_by": "Antoine Jérôme Balard", "description": "Bromine is a chemical element with the symbol Br and atomic number 35. It is the third-lightest halogen, and is a fuming red-brown liquid at room temperature that evaporates readily to form a similarly coloured gas."},
        
        {"atomic_number": 36, "symbol": "Kr", "name": "Krypton", "korean_name": "크립톤", "atomic_weight": 83.798, "category": "noble gas", "group": 18, "period": 4,
         "electron_configuration": "[Ar] 3d¹⁰ 4s² 4p⁶", "electronegativity": 3.00, "density": 0.003733, "melting_point": 115.78, "boiling_point": 119.93,
         "discovery_year": 1898, "discovered_by": "Sir William Ramsay, Morris Travers", "description": "Krypton is a chemical element with the symbol Kr and atomic number 36. It is a colorless, odorless, tasteless noble gas that occurs in trace amounts in the atmosphere."},
        
        {"atomic_number": 50, "symbol": "Sn", "name": "Tin", "korean_name": "주석", "atomic_weight": 118.71, "category": "post-transition metal", "group": 14, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰ 5s² 5p²", "electronegativity": 1.96, "density": 7.287, "melting_point": 505.08, "boiling_point": 2875,
         "discovery_year": None, "discovered_by": "Ancient civilizations", "description": "Tin is a chemical element with the symbol Sn and atomic number 50. It is a silvery-colored metal that characteristically has a faint yellow hue due to slight oxidation."},
        
        {"atomic_number": 53, "symbol": "I", "name": "Iodine", "korean_name": "아이오딘", "atomic_weight": 126.90, "category": "halogen", "group": 17, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰ 5s² 5p⁵", "electronegativity": 2.66, "density": 4.933, "melting_point": 386.85, "boiling_point": 457.4,
         "discovery_year": 1811, "discovered_by": "Bernard Courtois", "description": "Iodine is a chemical element with the symbol I and atomic number 53. The heaviest of the stable halogens, it exists as a lustrous, purple-black non-metallic solid at standard conditions that melts to form a deep violet liquid at 114 °C."},
         
        # Adding more elements to complete the full set (118 elements)
        {"atomic_number": 19, "symbol": "K", "name": "Potassium", "korean_name": "칼륨", "atomic_weight": 39.098, "category": "alkali metal", "group": 1, "period": 4,
         "electron_configuration": "[Ar] 4s¹", "electronegativity": 0.82, "density": 0.862, "melting_point": 336.53, "boiling_point": 1032,
         "discovery_year": 1807, "discovered_by": "Humphry Davy", "description": "Potassium is a chemical element with the symbol K and atomic number 19. It is a silvery-white metal that is soft enough to be cut with a knife with little force."},
         
        {"atomic_number": 21, "symbol": "Sc", "name": "Scandium", "korean_name": "스칸듐", "atomic_weight": 44.956, "category": "transition metal", "group": 3, "period": 4,
         "electron_configuration": "[Ar] 3d¹ 4s²", "electronegativity": 1.36, "density": 2.985, "melting_point": 1814, "boiling_point": 3109,
         "discovery_year": 1879, "discovered_by": "Lars Fredrik Nilson", "description": "Scandium is a chemical element with the symbol Sc and atomic number 21. A silvery-white metallic d-block element, it has historically been classified as a rare-earth element."},
         
        {"atomic_number": 22, "symbol": "Ti", "name": "Titanium", "korean_name": "티타늄", "atomic_weight": 47.867, "category": "transition metal", "group": 4, "period": 4,
         "electron_configuration": "[Ar] 3d² 4s²", "electronegativity": 1.54, "density": 4.507, "melting_point": 1941, "boiling_point": 3560,
         "discovery_year": 1791, "discovered_by": "William Gregor", "description": "Titanium is a chemical element with the symbol Ti and atomic number 22. It is a lustrous transition metal with a silver color, low density, and high strength."},
         
        {"atomic_number": 23, "symbol": "V", "name": "Vanadium", "korean_name": "바나듐", "atomic_weight": 50.942, "category": "transition metal", "group": 5, "period": 4,
         "electron_configuration": "[Ar] 3d³ 4s²", "electronegativity": 1.63, "density": 6.11, "melting_point": 2183, "boiling_point": 3680,
         "discovery_year": 1801, "discovered_by": "Andrés Manuel del Río", "description": "Vanadium is a chemical element with the symbol V and atomic number 23. It is a hard, silvery-grey, malleable transition metal."},
         
        {"atomic_number": 24, "symbol": "Cr", "name": "Chromium", "korean_name": "크롬", "atomic_weight": 51.996, "category": "transition metal", "group": 6, "period": 4,
         "electron_configuration": "[Ar] 3d⁵ 4s¹", "electronegativity": 1.66, "density": 7.19, "melting_point": 2180, "boiling_point": 2944,
         "discovery_year": 1797, "discovered_by": "Louis Nicolas Vauquelin", "description": "Chromium is a chemical element with the symbol Cr and atomic number 24. It is the first element in group 6. It is a steely-grey, lustrous, hard and brittle transition metal."},
        
        {"atomic_number": 54, "symbol": "Xe", "name": "Xenon", "atomic_weight": 131.29, "category": "noble gas", "group": 18, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰ 5s² 5p⁶", "electronegativity": 2.60, "density": 0.005887, "melting_point": 161.40, "boiling_point": 165.03,
         "discovery_year": 1898, "discovered_by": "Sir William Ramsay, Morris Travers", "description": "Xenon is a chemical element with the symbol Xe and atomic number 54. It is a colorless, dense, odorless noble gas found in Earth's atmosphere in trace amounts."},
        

        {"atomic_number": 82, "symbol": "Pb", "name": "Lead", "atomic_weight": 207.2, "category": "post-transition metal", "group": 14, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²", "electronegativity": 2.33, "density": 11.34, "melting_point": 600.61, "boiling_point": 2022,
         "discovery_year": None, "discovered_by": "Ancient civilizations", "description": "Lead is a chemical element with the symbol Pb and atomic number 82. It is a heavy metal that is denser than most common materials."},
        
        {"atomic_number": 86, "symbol": "Rn", "name": "Radon", "korean_name": "라돈", "atomic_weight": 222, "category": "noble gas", "group": 18, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁶", "electronegativity": 2.20, "density": 0.00973, "melting_point": 202, "boiling_point": 211.5,
         "discovery_year": 1900, "discovered_by": "Friedrich Ernst Dorn", "description": "Radon is a chemical element with the symbol Rn and atomic number 86. It is a radioactive, colorless, odorless, tasteless noble gas."},
         
        {"atomic_number": 25, "symbol": "Mn", "name": "Manganese", "korean_name": "망간", "atomic_weight": 54.938, "category": "transition metal", "group": 7, "period": 4,
         "electron_configuration": "[Ar] 3d⁵ 4s²", "electronegativity": 1.55, "density": 7.21, "melting_point": 1519, "boiling_point": 2334,
         "discovery_year": 1774, "discovered_by": "Johan Gottlieb Gahn", "description": "Manganese is a chemical element with the symbol Mn and atomic number 25. It is a hard, brittle, silvery metal, often found in minerals in combination with iron."},
         
        {"atomic_number": 27, "symbol": "Co", "name": "Cobalt", "korean_name": "코발트", "atomic_weight": 58.933, "category": "transition metal", "group": 9, "period": 4,
         "electron_configuration": "[Ar] 3d⁷ 4s²", "electronegativity": 1.88, "density": 8.90, "melting_point": 1768, "boiling_point": 3200,
         "discovery_year": 1735, "discovered_by": "Georg Brandt", "description": "Cobalt is a chemical element with the symbol Co and atomic number 27. It is a lustrous, hard, silver-gray transition metal with a bluish tinge."},
         
        {"atomic_number": 28, "symbol": "Ni", "name": "Nickel", "korean_name": "니켈", "atomic_weight": 58.693, "category": "transition metal", "group": 10, "period": 4,
         "electron_configuration": "[Ar] 3d⁸ 4s²", "electronegativity": 1.91, "density": 8.908, "melting_point": 1728, "boiling_point": 3186,
         "discovery_year": 1751, "discovered_by": "Axel Fredrik Cronstedt", "description": "Nickel is a chemical element with the symbol Ni and atomic number 28. It is a silvery-white lustrous metal with a slight golden tinge."},
         
        {"atomic_number": 31, "symbol": "Ga", "name": "Gallium", "korean_name": "갈륨", "atomic_weight": 69.723, "category": "post-transition metal", "group": 13, "period": 4,
         "electron_configuration": "[Ar] 3d¹⁰ 4s² 4p¹", "electronegativity": 1.81, "density": 5.91, "melting_point": 302.91, "boiling_point": 2673,
         "discovery_year": 1875, "discovered_by": "Lecoq de Boisbaudran", "description": "Gallium is a chemical element with the symbol Ga and atomic number 31. It is in group 13 of the periodic table, and thus has similarities to the other metals of the group, aluminum, indium, and thallium."},
         
        {"atomic_number": 32, "symbol": "Ge", "name": "Germanium", "korean_name": "게르마늄", "atomic_weight": 72.630, "category": "metalloid", "group": 14, "period": 4,
         "electron_configuration": "[Ar] 3d¹⁰ 4s² 4p²", "electronegativity": 2.01, "density": 5.323, "melting_point": 1211.4, "boiling_point": 3106,
         "discovery_year": 1886, "discovered_by": "Clemens Winkler", "description": "Germanium is a chemical element with the symbol Ge and atomic number 32. It is a lustrous, hard-brittle, grayish-white metalloid in the carbon group."},
         
        {"atomic_number": 33, "symbol": "As", "name": "Arsenic", "korean_name": "비소", "atomic_weight": 74.922, "category": "metalloid", "group": 15, "period": 4,
         "electron_configuration": "[Ar] 3d¹⁰ 4s² 4p³", "electronegativity": 2.18, "density": 5.727, "melting_point": 1090, "boiling_point": 887,
         "discovery_year": None, "discovered_by": "Ancient civilizations", "description": "Arsenic is a chemical element with the symbol As and atomic number 33. It is a metalloid. Arsenic occurs in many minerals, usually in combination with sulfur and metals."},
         
        {"atomic_number": 34, "symbol": "Se", "name": "Selenium", "korean_name": "셀레늄", "atomic_weight": 78.971, "category": "nonmetal", "group": 16, "period": 4,
         "electron_configuration": "[Ar] 3d¹⁰ 4s² 4p⁴", "electronegativity": 2.55, "density": 4.81, "melting_point": 494, "boiling_point": 958,
         "discovery_year": 1817, "discovered_by": "Jöns Jakob Berzelius", "description": "Selenium is a chemical element with the symbol Se and atomic number 34. It is a nonmetal with properties that are intermediate between the elements above and below in the periodic table, sulfur and tellurium."},
         
        {"atomic_number": 37, "symbol": "Rb", "name": "Rubidium", "korean_name": "루비듐", "atomic_weight": 85.468, "category": "alkali metal", "group": 1, "period": 5,
         "electron_configuration": "[Kr] 5s¹", "electronegativity": 0.82, "density": 1.532, "melting_point": 312.46, "boiling_point": 961,
         "discovery_year": 1861, "discovered_by": "Robert Bunsen, Gustav Kirchhoff", "description": "Rubidium is a chemical element with the symbol Rb and atomic number 37. It is a very soft, silvery-white metal in the alkali metal group."},
         
        {"atomic_number": 38, "symbol": "Sr", "name": "Strontium", "korean_name": "스트론튬", "atomic_weight": 87.62, "category": "alkaline earth metal", "group": 2, "period": 5,
         "electron_configuration": "[Kr] 5s²", "electronegativity": 0.95, "density": 2.64, "melting_point": 1050, "boiling_point": 1655,
         "discovery_year": 1790, "discovered_by": "Adair Crawford", "description": "Strontium is a chemical element with the symbol Sr and atomic number 38. An alkaline earth metal, strontium is a soft silver-white yellowish metallic element that is highly chemically reactive."},
         
        {"atomic_number": 39, "symbol": "Y", "name": "Yttrium", "korean_name": "이트륨", "atomic_weight": 88.906, "category": "transition metal", "group": 3, "period": 5,
         "electron_configuration": "[Kr] 4d¹ 5s²", "electronegativity": 1.22, "density": 4.472, "melting_point": 1799, "boiling_point": 3609,
         "discovery_year": 1794, "discovered_by": "Johan Gadolin", "description": "Yttrium is a chemical element with the symbol Y and atomic number 39. It is a silvery-metallic transition metal chemically similar to the lanthanides and has often been classified as a \"rare-earth element\"."},
         
        {"atomic_number": 40, "symbol": "Zr", "name": "Zirconium", "korean_name": "지르코늄", "atomic_weight": 91.224, "category": "transition metal", "group": 4, "period": 5,
         "electron_configuration": "[Kr] 4d² 5s²", "electronegativity": 1.33, "density": 6.52, "melting_point": 2128, "boiling_point": 4682,
         "discovery_year": 1789, "discovered_by": "Martin Heinrich Klaproth", "description": "Zirconium is a chemical element with the symbol Zr and atomic number 40. The name zirconium is taken from the name of the mineral zircon, the most important source of zirconium."},
         
        {"atomic_number": 41, "symbol": "Nb", "name": "Niobium", "korean_name": "니오븀", "atomic_weight": 92.906, "category": "transition metal", "group": 5, "period": 5,
         "electron_configuration": "[Kr] 4d⁴ 5s¹", "electronegativity": 1.6, "density": 8.57, "melting_point": 2750, "boiling_point": 5017,
         "discovery_year": 1801, "discovered_by": "Charles Hatchett", "description": "Niobium is a chemical element with the symbol Nb and atomic number 41. It is a light grey, crystalline, and ductile transition metal."},
         
        {"atomic_number": 42, "symbol": "Mo", "name": "Molybdenum", "korean_name": "몰리브데넘", "atomic_weight": 95.95, "category": "transition metal", "group": 6, "period": 5,
         "electron_configuration": "[Kr] 4d⁵ 5s¹", "electronegativity": 2.16, "density": 10.28, "melting_point": 2896, "boiling_point": 4912,
         "discovery_year": 1778, "discovered_by": "Carl Wilhelm Scheele", "description": "Molybdenum is a chemical element with the symbol Mo and atomic number 42. The name is from Neo-Latin molybdaenum, which is based on Ancient Greek Μόλυβδος molybdos, meaning lead."},
        
        {"atomic_number": 43, "symbol": "Tc", "name": "Technetium", "korean_name": "테크네튬", "atomic_weight": 98, "category": "transition metal", "group": 7, "period": 5,
         "electron_configuration": "[Kr] 4d⁵ 5s²", "electronegativity": 1.9, "density": 11.5, "melting_point": 2430, "boiling_point": 4538,
         "discovery_year": 1937, "discovered_by": "Carlo Perrier, Emilio Segrè", "description": "Technetium is a chemical element with the symbol Tc and atomic number 43. It is the lightest element whose isotopes are all radioactive; none are stable, excluding the fully ionized state of ⁹⁷Tc."},
         
        {"atomic_number": 44, "symbol": "Ru", "name": "Ruthenium", "korean_name": "루테늄", "atomic_weight": 101.07, "category": "transition metal", "group": 8, "period": 5,
         "electron_configuration": "[Kr] 4d⁷ 5s¹", "electronegativity": 2.2, "density": 12.37, "melting_point": 2607, "boiling_point": 4423,
         "discovery_year": 1844, "discovered_by": "Karl Ernst Claus", "description": "Ruthenium is a chemical element with the symbol Ru and atomic number 44. It is a rare transition metal belonging to the platinum group of the periodic table."},
         
        {"atomic_number": 45, "symbol": "Rh", "name": "Rhodium", "korean_name": "로듐", "atomic_weight": 102.91, "category": "transition metal", "group": 9, "period": 5,
         "electron_configuration": "[Kr] 4d⁸ 5s¹", "electronegativity": 2.28, "density": 12.41, "melting_point": 2237, "boiling_point": 3968,
         "discovery_year": 1803, "discovered_by": "William Hyde Wollaston", "description": "Rhodium is a chemical element with the symbol Rh and atomic number 45. It is a rare, silvery-white, hard, corrosion-resistant, and chemically inert transition metal."},
         
        {"atomic_number": 46, "symbol": "Pd", "name": "Palladium", "korean_name": "팔라듐", "atomic_weight": 106.42, "category": "transition metal", "group": 10, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰", "electronegativity": 2.20, "density": 12.023, "melting_point": 1828.05, "boiling_point": 3236,
         "discovery_year": 1803, "discovered_by": "William Hyde Wollaston", "description": "Palladium is a chemical element with the symbol Pd and atomic number 46. It is a rare and lustrous silvery-white metal discovered in 1803 by the English chemist William Hyde Wollaston."},
         
        {"atomic_number": 48, "symbol": "Cd", "name": "Cadmium", "korean_name": "카드뮴", "atomic_weight": 112.41, "category": "transition metal", "group": 12, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰ 5s²", "electronegativity": 1.69, "density": 8.65, "melting_point": 594.22, "boiling_point": 1040,
         "discovery_year": 1817, "discovered_by": "Karl Samuel Leberecht Hermann, Friedrich Stromeyer", "description": "Cadmium is a chemical element with the symbol Cd and atomic number 48. This soft, silvery-white metal is chemically similar to the two other stable metals in group 12, zinc and mercury."},
         
        {"atomic_number": 49, "symbol": "In", "name": "Indium", "korean_name": "인듐", "atomic_weight": 114.82, "category": "post-transition metal", "group": 13, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰ 5s² 5p¹", "electronegativity": 1.78, "density": 7.31, "melting_point": 429.75, "boiling_point": 2345,
         "discovery_year": 1863, "discovered_by": "Ferdinand Reich, Hieronymous Theodor Richter", "description": "Indium is a chemical element with the symbol In and atomic number 49. It is a post-transition metal that makes up 0.21 parts per million of the Earth's crust."},
         
        {"atomic_number": 51, "symbol": "Sb", "name": "Antimony", "korean_name": "안티모니", "atomic_weight": 121.76, "category": "metalloid", "group": 15, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰ 5s² 5p³", "electronegativity": 2.05, "density": 6.697, "melting_point": 903.78, "boiling_point": 1860,
         "discovery_year": None, "discovered_by": "Ancient civilizations", "description": "Antimony is a chemical element with the symbol Sb and atomic number 51. A lustrous gray metalloid, it is found in nature mainly as the sulfide mineral stibnite (Sb₂S₃)."},
         
        {"atomic_number": 52, "symbol": "Te", "name": "Tellurium", "korean_name": "텔루륨", "atomic_weight": 127.60, "category": "metalloid", "group": 16, "period": 5,
         "electron_configuration": "[Kr] 4d¹⁰ 5s² 5p⁴", "electronegativity": 2.1, "density": 6.24, "melting_point": 722.66, "boiling_point": 1261,
         "discovery_year": 1782, "discovered_by": "Franz-Joseph Müller von Reichenstein", "description": "Tellurium is a chemical element with the symbol Te and atomic number 52. It is a brittle, mildly toxic, rare, silver-white metalloid which looks similar to tin."},
         
        {"atomic_number": 55, "symbol": "Cs", "name": "Cesium", "korean_name": "세슘", "atomic_weight": 132.91, "category": "alkali metal", "group": 1, "period": 6,
         "electron_configuration": "[Xe] 6s¹", "electronegativity": 0.79, "density": 1.873, "melting_point": 301.59, "boiling_point": 944,
         "discovery_year": 1860, "discovered_by": "Robert Bunsen, Gustav Kirchhoff", "description": "Cesium is a chemical element with the symbol Cs and atomic number 55. It is a soft, silvery-golden alkali metal with a melting point of 28.5 °C, which makes it one of only five elemental metals that are liquid at or near room temperature."},
         
        {"atomic_number": 56, "symbol": "Ba", "name": "Barium", "korean_name": "바륨", "atomic_weight": 137.33, "category": "alkaline earth metal", "group": 2, "period": 6,
         "electron_configuration": "[Xe] 6s²", "electronegativity": 0.89, "density": 3.51, "melting_point": 1000, "boiling_point": 2170,
         "discovery_year": 1808, "discovered_by": "Humphry Davy", "description": "Barium is a chemical element with the symbol Ba and atomic number 56. It is the fifth element in group 2 and is a soft, silvery alkaline earth metal."},
         
        {"atomic_number": 57, "symbol": "La", "name": "Lanthanum", "korean_name": "란타넘", "atomic_weight": 138.91, "category": "lanthanide", "group": 3, "period": 6,
         "electron_configuration": "[Xe] 5d¹ 6s²", "electronegativity": 1.1, "density": 6.162, "melting_point": 1193, "boiling_point": 3737,
         "discovery_year": 1839, "discovered_by": "Carl Gustaf Mosander", "description": "Lanthanum is a chemical element with the symbol La and atomic number 57. It is a soft, ductile, silvery-white metal that tarnishes rapidly when exposed to air and is soft enough to be cut with a knife."},
         
        {"atomic_number": 58, "symbol": "Ce", "name": "Cerium", "korean_name": "세륨", "atomic_weight": 140.12, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f¹ 5d¹ 6s²", "electronegativity": 1.12, "density": 6.770, "melting_point": 1068, "boiling_point": 3716,
         "discovery_year": 1803, "discovered_by": "Jöns Jakob Berzelius, Wilhelm Hisinger, Martin Heinrich Klaproth", "description": "Cerium is a chemical element with the symbol Ce and atomic number 58. It is a soft, silvery, ductile metal which easily oxidizes in air."},
         
        {"atomic_number": 59, "symbol": "Pr", "name": "Praseodymium", "korean_name": "프라세오디뮴", "atomic_weight": 140.91, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f³ 6s²", "electronegativity": 1.13, "density": 6.77, "melting_point": 1208, "boiling_point": 3793,
         "discovery_year": 1885, "discovered_by": "Carl Auer von Welsbach", "description": "Praseodymium is a chemical element with the symbol Pr and atomic number 59. It is the third member of the lanthanide series and is traditionally considered to be one of the rare-earth metals."},
         
        {"atomic_number": 60, "symbol": "Nd", "name": "Neodymium", "korean_name": "네오디뮴", "atomic_weight": 144.24, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f⁴ 6s²", "electronegativity": 1.14, "density": 7.01, "melting_point": 1297, "boiling_point": 3347,
         "discovery_year": 1885, "discovered_by": "Carl Auer von Welsbach", "description": "Neodymium is a chemical element with the symbol Nd and atomic number 60. It is the fourth member of the lanthanide series and is considered to be one of the rare-earth metals."},
         
        {"atomic_number": 61, "symbol": "Pm", "name": "Promethium", "korean_name": "프로메튬", "atomic_weight": 145, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f⁵ 6s²", "electronegativity": 1.13, "density": 7.26, "melting_point": 1315, "boiling_point": 3273,
         "discovery_year": 1945, "discovered_by": "Charles D. Coryell, Jacob A. Marinsky, Lawrence E. Glendenin", "description": "Promethium is a chemical element with the symbol Pm and atomic number 61. All of its isotopes are radioactive; it is extremely rare, as only tiny amounts are found in nature as a result of uranium fission."},
         
        {"atomic_number": 62, "symbol": "Sm", "name": "Samarium", "korean_name": "사마륨", "atomic_weight": 150.36, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f⁶ 6s²", "electronegativity": 1.17, "density": 7.52, "melting_point": 1345, "boiling_point": 2067,
         "discovery_year": 1879, "discovered_by": "Paul Émile Lecoq de Boisbaudran", "description": "Samarium is a chemical element with the symbol Sm and atomic number 62. It is a moderately hard silvery metal that slowly oxidizes in air."},
         
        {"atomic_number": 63, "symbol": "Eu", "name": "Europium", "korean_name": "유로퓸", "atomic_weight": 151.96, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f⁷ 6s²", "electronegativity": 1.2, "density": 5.264, "melting_point": 1099, "boiling_point": 1802,
         "discovery_year": 1901, "discovered_by": "Eugène-Anatole Demarçay", "description": "Europium is a chemical element with the symbol Eu and atomic number 63. It is the most reactive lanthanide by far, having to be stored under an inert fluid to protect it from atmospheric oxygen or moisture."},
         
        {"atomic_number": 64, "symbol": "Gd", "name": "Gadolinium", "korean_name": "가돌리늄", "atomic_weight": 157.25, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f⁷ 5d¹ 6s²", "electronegativity": 1.2, "density": 7.90, "melting_point": 1585, "boiling_point": 3546,
         "discovery_year": 1880, "discovered_by": "Jean Charles Galissard de Marignac", "description": "Gadolinium is a chemical element with the symbol Gd and atomic number 64. It is a silvery-white, malleable, and ductile rare-earth metal."},
         
        {"atomic_number": 65, "symbol": "Tb", "name": "Terbium", "korean_name": "터븀", "atomic_weight": 158.93, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f⁹ 6s²", "electronegativity": 1.2, "density": 8.23, "melting_point": 1629, "boiling_point": 3503,
         "discovery_year": 1843, "discovered_by": "Carl Gustaf Mosander", "description": "Terbium is a chemical element with the symbol Tb and atomic number 65. It is a silvery-white, rare earth metal that is malleable, ductile, and soft enough to be cut with a knife."},
         
        {"atomic_number": 66, "symbol": "Dy", "name": "Dysprosium", "korean_name": "디스프로슘", "atomic_weight": 162.50, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁰ 6s²", "electronegativity": 1.22, "density": 8.540, "melting_point": 1680, "boiling_point": 2840,
         "discovery_year": 1886, "discovered_by": "Paul Émile Lecoq de Boisbaudran", "description": "Dysprosium is a chemical element with the symbol Dy and atomic number 66. It is a rare-earth element with a metallic silver luster. Dysprosium is never found in nature as a free element, though it is found in various minerals."},
         
        {"atomic_number": 67, "symbol": "Ho", "name": "Holmium", "korean_name": "홀뮴", "atomic_weight": 164.93, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f¹¹ 6s²", "electronegativity": 1.23, "density": 8.79, "melting_point": 1734, "boiling_point": 2993,
         "discovery_year": 1878, "discovered_by": "Marc Delafontaine, Jacques-Louis Soret", "description": "Holmium is a chemical element with the symbol Ho and atomic number 67. Part of the lanthanide series, holmium is a rare-earth element."},
         
        {"atomic_number": 68, "symbol": "Er", "name": "Erbium", "korean_name": "어븀", "atomic_weight": 167.26, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f¹² 6s²", "electronegativity": 1.24, "density": 9.066, "melting_point": 1802, "boiling_point": 3141,
         "discovery_year": 1843, "discovered_by": "Carl Gustaf Mosander", "description": "Erbium is a chemical element with the symbol Er and atomic number 68. A silvery-white solid metal when artificially isolated, natural erbium is always found in chemical combination with other elements."},
         
        {"atomic_number": 69, "symbol": "Tm", "name": "Thulium", "korean_name": "툴륨", "atomic_weight": 168.93, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f¹³ 6s²", "electronegativity": 1.25, "density": 9.32, "melting_point": 1818, "boiling_point": 2223,
         "discovery_year": 1879, "discovered_by": "Per Teodor Cleve", "description": "Thulium is a chemical element with the symbol Tm and atomic number 69. It is the thirteenth and third-last element in the lanthanide series."},
         
        {"atomic_number": 70, "symbol": "Yb", "name": "Ytterbium", "korean_name": "이터븀", "atomic_weight": 173.05, "category": "lanthanide", "group": None, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 6s²", "electronegativity": 1.1, "density": 6.90, "melting_point": 1097, "boiling_point": 1469,
         "discovery_year": 1878, "discovered_by": "Jean Charles Galissard de Marignac", "description": "Ytterbium is a chemical element with the symbol Yb and atomic number 70. It is the fourteenth and penultimate element in the lanthanide series, which is the basis of the relative stability of its +2 oxidation state."},
         
        {"atomic_number": 71, "symbol": "Lu", "name": "Lutetium", "korean_name": "루테튬", "atomic_weight": 174.97, "category": "lanthanide", "group": 3, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹ 6s²", "electronegativity": 1.27, "density": 9.84, "melting_point": 1925, "boiling_point": 3675,
         "discovery_year": 1907, "discovered_by": "Georges Urbain", "description": "Lutetium is a chemical element with the symbol Lu and atomic number 71. It is a silvery white metal, which resists corrosion in dry air, but not in moist air. It is the last element in the lanthanide series."},
         
        {"atomic_number": 72, "symbol": "Hf", "name": "Hafnium", "korean_name": "하프늄", "atomic_weight": 178.49, "category": "transition metal", "group": 4, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d² 6s²", "electronegativity": 1.3, "density": 13.31, "melting_point": 2506, "boiling_point": 4876,
         "discovery_year": 1923, "discovered_by": "Dirk Coster, George de Hevesy", "description": "Hafnium is a chemical element with the symbol Hf and atomic number 72. A lustrous, silvery gray, tetravalent transition metal, hafnium chemically resembles zirconium and is found in many zirconium minerals."},
         
        {"atomic_number": 73, "symbol": "Ta", "name": "Tantalum", "korean_name": "탄탈럼", "atomic_weight": 180.95, "category": "transition metal", "group": 5, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d³ 6s²", "electronegativity": 1.5, "density": 16.69, "melting_point": 3290, "boiling_point": 5731,
         "discovery_year": 1802, "discovered_by": "Anders Gustaf Ekeberg", "description": "Tantalum is a chemical element with the symbol Ta and atomic number 73. It is a rare, hard, blue-gray, lustrous transition metal that is highly corrosion-resistant."},
         
        {"atomic_number": 74, "symbol": "W", "name": "Tungsten", "korean_name": "텅스텐", "atomic_weight": 183.84, "category": "transition metal", "group": 6, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d⁴ 6s²", "electronegativity": 2.36, "density": 19.25, "melting_point": 3695, "boiling_point": 5828,
         "discovery_year": 1783, "discovered_by": "Fausto and Juan José de Elhuyar", "description": "Tungsten, or wolfram, is a chemical element with the symbol W and atomic number 74. Tungsten is a rare metal found naturally on Earth almost exclusively as compounds. It has the highest melting point of all known elements."},
         
        {"atomic_number": 75, "symbol": "Re", "name": "Rhenium", "korean_name": "레늄", "atomic_weight": 186.21, "category": "transition metal", "group": 7, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d⁵ 6s²", "electronegativity": 1.9, "density": 21.02, "melting_point": 3459, "boiling_point": 5869,
         "discovery_year": 1925, "discovered_by": "Masataka Ogawa", "description": "Rhenium is a chemical element with the symbol Re and atomic number 75. It is a silvery-gray, heavy, third-row transition metal in group 7 of the periodic table. With an estimated average concentration of 1 part per billion (ppb), rhenium is one of the rarest elements in the Earth's crust."},
         
        {"atomic_number": 76, "symbol": "Os", "name": "Osmium", "korean_name": "오스뮴", "atomic_weight": 190.23, "category": "transition metal", "group": 8, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d⁶ 6s²", "electronegativity": 2.2, "density": 22.59, "melting_point": 3306, "boiling_point": 5285,
         "discovery_year": 1803, "discovered_by": "Smithson Tennant", "description": "Osmium is a chemical element with the symbol Os and atomic number 76. It is a hard, brittle, bluish-white transition metal in the platinum group that is found as a trace element in alloys, mostly in platinum ores. Osmium is the densest naturally occurring element."},
         
        {"atomic_number": 77, "symbol": "Ir", "name": "Iridium", "korean_name": "이리듐", "atomic_weight": 192.22, "category": "transition metal", "group": 9, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d⁷ 6s²", "electronegativity": 2.2, "density": 22.56, "melting_point": 2719, "boiling_point": 4701,
         "discovery_year": 1803, "discovered_by": "Smithson Tennant", "description": "Iridium is a chemical element with the symbol Ir and atomic number 77. A very hard, brittle, silvery-white transition metal of the platinum group, iridium is the second-densest metal with a density of 22.56 g/cm³ as defined by experimental X-ray crystallography."},
         
        {"atomic_number": 78, "symbol": "Pt", "name": "Platinum", "korean_name": "백금", "atomic_weight": 195.08, "category": "transition metal", "group": 10, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d⁹ 6s¹", "electronegativity": 2.28, "density": 21.45, "melting_point": 2041.4, "boiling_point": 4098,
         "discovery_year": 1735, "discovered_by": "Antonio de Ulloa", "description": "Platinum is a chemical element with the symbol Pt and atomic number 78. It is a dense, malleable, ductile, highly unreactive, precious, silverish-white transition metal. Its name is derived from the Spanish term platino, meaning 'little silver'."},
         
        {"atomic_number": 79, "symbol": "Au", "name": "Gold", "korean_name": "금", "atomic_weight": 196.97, "category": "transition metal", "group": 11, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s¹", "electronegativity": 2.54, "density": 19.3, "melting_point": 1337.33, "boiling_point": 3243,
         "discovery_year": None, "discovered_by": "Ancient civilizations", "description": "Gold is a chemical element with the symbol Au and atomic number 79. It is a bright, slightly orange-yellow, dense, soft, malleable, and ductile metal in a pure form. Chemically, gold is a transition metal and a group 11 element."},
         
        {"atomic_number": 80, "symbol": "Hg", "name": "Mercury", "korean_name": "수은", "atomic_weight": 200.59, "category": "transition metal", "group": 12, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s²", "electronegativity": 2.0, "density": 13.534, "melting_point": 234.32, "boiling_point": 629.88,
         "discovery_year": None, "discovered_by": "Ancient civilizations", "description": "Mercury is a chemical element with the symbol Hg and atomic number 80. It is commonly known as quicksilver and was formerly named hydrargyrum. A heavy, silvery d-block element, mercury is the only metallic element that is liquid at standard conditions for temperature and pressure."},
         
        {"atomic_number": 81, "symbol": "Tl", "name": "Thallium", "korean_name": "탈륨", "atomic_weight": 204.38, "category": "post-transition metal", "group": 13, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p¹", "electronegativity": 1.62, "density": 11.85, "melting_point": 577, "boiling_point": 1746,
         "discovery_year": 1861, "discovered_by": "William Crookes", "description": "Thallium is a chemical element with the symbol Tl and atomic number 81. It is a gray post-transition metal that is not found free in nature. When isolated, thallium resembles tin, but discolors when exposed to air."},
         
        {"atomic_number": 82, "symbol": "Pb", "name": "Lead", "korean_name": "납", "atomic_weight": 207.2, "category": "post-transition metal", "group": 14, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²", "electronegativity": 1.87, "density": 11.34, "melting_point": 600.61, "boiling_point": 2022,
         "discovery_year": None, "discovered_by": "Ancient civilizations", "description": "Lead is a chemical element with the symbol Pb and atomic number 82. It is a heavy metal that is denser than most common materials. Lead is soft and malleable, and also has a relatively low melting point."},
         
        {"atomic_number": 83, "symbol": "Bi", "name": "Bismuth", "korean_name": "비스무트", "atomic_weight": 208.98, "category": "post-transition metal", "group": 15, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p³", "electronegativity": 2.02, "density": 9.78, "melting_point": 544.7, "boiling_point": 1837,
         "discovery_year": 1753, "discovered_by": "Claude François Geoffroy", "description": "Bismuth is a chemical element with the symbol Bi and atomic number 83. It is a pentavalent post-transition metal and one of the pnictogens with chemical properties resembling its lighter homologs arsenic and antimony."},
         
        {"atomic_number": 84, "symbol": "Po", "name": "Polonium", "korean_name": "폴로늄", "atomic_weight": 209, "category": "post-transition metal", "group": 16, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁴", "electronegativity": 2.0, "density": 9.196, "melting_point": 527, "boiling_point": 1235,
         "discovery_year": 1898, "discovered_by": "Marie Curie, Pierre Curie", "description": "Polonium is a chemical element with the symbol Po and atomic number 84. A rare and highly radioactive metal with no stable isotopes, polonium is chemically similar to selenium and tellurium, though its metallic character resembles that of its horizontal neighbors in the periodic table."},
         
        {"atomic_number": 85, "symbol": "At", "name": "Astatine", "korean_name": "아스타틴", "atomic_weight": 210, "category": "halogen", "group": 17, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁵", "electronegativity": 2.2, "density": 7, "melting_point": 575, "boiling_point": 610,
         "discovery_year": 1940, "discovered_by": "Dale R. Corson, Kenneth Ross MacKenzie, Emilio Segrè", "description": "Astatine is a chemical element with the symbol At and atomic number 85. It is the rarest naturally occurring element in the Earth's crust, occurring only as the decay product of various heavier elements."},
         
        {"atomic_number": 86, "symbol": "Rn", "name": "Radon", "korean_name": "라돈", "atomic_weight": 222, "category": "noble gas", "group": 18, "period": 6,
         "electron_configuration": "[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁶", "electronegativity": None, "density": 0.00973, "melting_point": 202, "boiling_point": 211.3,
         "discovery_year": 1900, "discovered_by": "Friedrich Ernst Dorn", "description": "Radon is a chemical element with the symbol Rn and atomic number 86. It is a radioactive, colorless, odorless, tasteless noble gas. It occurs naturally in minute quantities as an intermediate step in the normal radioactive decay chains."},
         
        {"atomic_number": 87, "symbol": "Fr", "name": "Francium", "korean_name": "프랑슘", "atomic_weight": 223, "category": "alkali metal", "group": 1, "period": 7,
         "electron_configuration": "[Rn] 7s¹", "electronegativity": 0.7, "density": 1.87, "melting_point": 300, "boiling_point": 950,
         "discovery_year": 1939, "discovered_by": "Marguerite Perey", "description": "Francium is a chemical element with the symbol Fr and atomic number 87. It is extremely radioactive; its most stable isotope, francium-223, has a half-life of only 22 minutes. It is the second-most electropositive element, behind only cesium, and is the second rarest naturally occurring element."},
         
        {"atomic_number": 88, "symbol": "Ra", "name": "Radium", "korean_name": "라듐", "atomic_weight": 226, "category": "alkaline earth metal", "group": 2, "period": 7,
         "electron_configuration": "[Rn] 7s²", "electronegativity": 0.9, "density": 5.5, "melting_point": 973, "boiling_point": 2010,
         "discovery_year": 1898, "discovered_by": "Marie Curie, Pierre Curie", "description": "Radium is a chemical element with the symbol Ra and atomic number 88. It is the sixth element in group 2 of the periodic table, also known as the alkaline earth metals. Pure radium is silvery-white, but it readily reacts with nitrogen on exposure to air."},
         
        {"atomic_number": 89, "symbol": "Ac", "name": "Actinium", "korean_name": "악티늄", "atomic_weight": 227, "category": "actinide", "group": 3, "period": 7,
         "electron_configuration": "[Rn] 6d¹ 7s²", "electronegativity": 1.1, "density": 10.07, "melting_point": 1323, "boiling_point": 3471,
         "discovery_year": 1899, "discovered_by": "André-Louis Debierne", "description": "Actinium is a chemical element with the symbol Ac and atomic number 89. It was first isolated by Friedrich Oskar Giesel in 1902. Actinium gave the name to the actinide series, a group of 15 similar elements between actinium and lawrencium in the periodic table."},
         
        {"atomic_number": 90, "symbol": "Th", "name": "Thorium", "korean_name": "토륨", "atomic_weight": 232.04, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 6d² 7s²", "electronegativity": 1.3, "density": 11.72, "melting_point": 2023, "boiling_point": 5061,
         "discovery_year": 1829, "discovered_by": "Jöns Jakob Berzelius", "description": "Thorium is a weakly radioactive metallic chemical element with the symbol Th and atomic number 90. Thorium is silvery and tarnishes black when it is exposed to air, forming thorium dioxide."},
         
        {"atomic_number": 91, "symbol": "Pa", "name": "Protactinium", "korean_name": "프로트악티늄", "atomic_weight": 231.04, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f² 6d¹ 7s²", "electronegativity": 1.5, "density": 15.37, "melting_point": 1841, "boiling_point": 4300,
         "discovery_year": 1913, "discovered_by": "Kasimir Fajans, Oswald Helmuth Göhring", "description": "Protactinium is a chemical element with the symbol Pa and atomic number 91. It is a dense, silvery-gray actinide metal which readily reacts with oxygen, water vapor and inorganic acids."},
         
        {"atomic_number": 92, "symbol": "U", "name": "Uranium", "korean_name": "우라늄", "atomic_weight": 238.03, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f³ 6d¹ 7s²", "electronegativity": 1.38, "density": 19.05, "melting_point": 1405.3, "boiling_point": 4404,
         "discovery_year": 1789, "discovered_by": "Martin Heinrich Klaproth", "description": "Uranium is a chemical element with the symbol U and atomic number 92. It is a silvery-grey metal in the actinide series of the periodic table. A uranium atom has 92 protons and 92 electrons, of which 6 are valence electrons."},
         
        {"atomic_number": 93, "symbol": "Np", "name": "Neptunium", "korean_name": "넵투늄", "atomic_weight": 237, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f⁴ 6d¹ 7s²", "electronegativity": 1.36, "density": 20.45, "melting_point": 917, "boiling_point": 4273,
         "discovery_year": 1940, "discovered_by": "Edwin McMillan, Philip H. Abelson", "description": "Neptunium is a chemical element with the symbol Np and atomic number 93. A radioactive actinide metal, neptunium is the first transuranic element. Its position in the periodic table just after uranium, named after the planet Uranus, led to it being named after Neptune, the next planet beyond Uranus."},
         
        {"atomic_number": 94, "symbol": "Pu", "name": "Plutonium", "korean_name": "플루토늄", "atomic_weight": 244, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f⁶ 7s²", "electronegativity": 1.28, "density": 19.82, "melting_point": 912.5, "boiling_point": 3505,
         "discovery_year": 1940, "discovered_by": "Glenn T. Seaborg, Arthur C. Wahl, Joseph W. Kennedy, Edwin McMillan", "description": "Plutonium is a radioactive chemical element with the symbol Pu and atomic number 94. It is an actinide metal of silvery-gray appearance that tarnishes when exposed to air, and forms a dull coating when oxidized."},
         
        {"atomic_number": 95, "symbol": "Am", "name": "Americium", "korean_name": "아메리슘", "atomic_weight": 243, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f⁷ 7s²", "electronegativity": 1.3, "density": 13.67, "melting_point": 1449, "boiling_point": 2880,
         "discovery_year": 1944, "discovered_by": "Glenn T. Seaborg, Ralph A. James, Leon O. Morgan, Albert Ghiorso", "description": "Americium is a synthetic radioactive chemical element with the symbol Am and atomic number 95. It is a transuranic member of the actinide series, in the periodic table located under the lanthanide element europium, and thus by analogy was named after the Americas."},
         
        {"atomic_number": 96, "symbol": "Cm", "name": "Curium", "korean_name": "퀴륨", "atomic_weight": 247, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f⁷ 6d¹ 7s²", "electronegativity": 1.3, "density": 13.51, "melting_point": 1613, "boiling_point": 3383,
         "discovery_year": 1944, "discovered_by": "Glenn T. Seaborg, Ralph A. James, Albert Ghiorso", "description": "Curium is a transuranic, radioactive chemical element with the symbol Cm and atomic number 96. This element of the actinide series was named after eminent scientists Marie and Pierre Curie, both known for their research on radioactivity."},
         
        {"atomic_number": 97, "symbol": "Bk", "name": "Berkelium", "korean_name": "버클륨", "atomic_weight": 247, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f⁹ 7s²", "electronegativity": 1.3, "density": 14.78, "melting_point": 1259, "boiling_point": 2900,
         "discovery_year": 1949, "discovered_by": "Glenn T. Seaborg, Albert Ghiorso, Stanley G. Thompson", "description": "Berkelium is a transuranic radioactive chemical element with the symbol Bk and atomic number 97. It is a member of the actinide and transuranium element series. It is named after the city of Berkeley, California, the location of the Lawrence Berkeley National Laboratory."},
         
        {"atomic_number": 98, "symbol": "Cf", "name": "Californium", "korean_name": "캘리포늄", "atomic_weight": 251, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁰ 7s²", "electronegativity": 1.3, "density": 15.1, "melting_point": 1173, "boiling_point": 1743,
         "discovery_year": 1950, "discovered_by": "Glenn T. Seaborg, Stanley G. Thompson, Albert Ghiorso, Kenneth Street, Jr.", "description": "Californium is a radioactive chemical element with the symbol Cf and atomic number 98. The element was first synthesized in 1950 at the Lawrence Berkeley National Laboratory, by bombarding curium with alpha particles."},
         
        {"atomic_number": 99, "symbol": "Es", "name": "Einsteinium", "korean_name": "아인슈타이늄", "atomic_weight": 252, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f¹¹ 7s²", "electronegativity": 1.3, "density": 8.84, "melting_point": 1133, "boiling_point": 1269,
         "discovery_year": 1952, "discovered_by": "Albert Ghiorso, Glenn T. Seaborg", "description": "Einsteinium is a synthetic element with the symbol Es and atomic number 99. Einsteinium is a member of the actinide series and it is the seventh transuranic element. It was named in honor of Albert Einstein."},
         
        {"atomic_number": 100, "symbol": "Fm", "name": "Fermium", "korean_name": "페르뮴", "atomic_weight": 257, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f¹² 7s²", "electronegativity": 1.3, "density": None, "melting_point": 1800, "boiling_point": None,
         "discovery_year": 1952, "discovered_by": "Albert Ghiorso, Glenn T. Seaborg", "description": "Fermium is a synthetic element with the symbol Fm and atomic number 100. It is an actinide and the heaviest element that can be formed by neutron bombardment of lighter elements. Fermium was first discovered in the debris of the first hydrogen bomb explosion in 1952."},
         
        {"atomic_number": 101, "symbol": "Md", "name": "Mendelevium", "korean_name": "멘델레븀", "atomic_weight": 258, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f¹³ 7s²", "electronegativity": 1.3, "density": None, "melting_point": 1100, "boiling_point": None,
         "discovery_year": 1955, "discovered_by": "Glenn T. Seaborg, Albert Ghiorso, Gregory R. Choppin, Bernard G. Harvey, Stanley G. Thompson", "description": "Mendelevium is a synthetic element with the symbol Md and atomic number 101. A metallic radioactive transuranic element in the actinide series, it is the first element that currently cannot be produced in macroscopic quantities."},
         
        {"atomic_number": 102, "symbol": "No", "name": "Nobelium", "korean_name": "노벨륨", "atomic_weight": 259, "category": "actinide", "group": None, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 7s²", "electronegativity": 1.3, "density": None, "melting_point": 1100, "boiling_point": None,
         "discovery_year": 1958, "discovered_by": "Albert Ghiorso, Glenn T. Seaborg, Torbørn Sikkeland, John R. Walton", "description": "Nobelium is a synthetic chemical element with the symbol No and atomic number 102. It is named in honor of Alfred Nobel, the inventor of dynamite and benefactor of science. A radioactive metal, it is the tenth transuranic element and is the penultimate member of the actinide series."},
         
        {"atomic_number": 103, "symbol": "Lr", "name": "Lawrencium", "korean_name": "로렌슘", "atomic_weight": 266, "category": "actinide", "group": 3, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 7s² 7p¹", "electronegativity": 1.3, "density": None, "melting_point": 1900, "boiling_point": None,
         "discovery_year": 1961, "discovered_by": "Albert Ghiorso, Torbjørn Sikkeland, Almon Larsh, Robert M. Latimer", "description": "Lawrencium is a synthetic chemical element with the symbol Lr and atomic number 103. It is named in honor of Ernest Lawrence, inventor of the cyclotron, a device that was used to discover many artificial radioactive elements."},
         
        {"atomic_number": 104, "symbol": "Rf", "name": "Rutherfordium", "korean_name": "러더포듐", "atomic_weight": 267, "category": "transition metal", "group": 4, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d² 7s²", "electronegativity": None, "density": 23, "melting_point": 2400, "boiling_point": 5800,
         "discovery_year": 1964, "discovered_by": "Joint Institute for Nuclear Research, Lawrence Berkeley Laboratory", "description": "Rutherfordium is a synthetic chemical element with the symbol Rf and atomic number 104. It is named after New Zealand physicist Ernest Rutherford. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 105, "symbol": "Db", "name": "Dubnium", "korean_name": "두브늄", "atomic_weight": 268, "category": "transition metal", "group": 5, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d³ 7s²", "electronegativity": None, "density": 29, "melting_point": None, "boiling_point": None,
         "discovery_year": 1968, "discovered_by": "Joint Institute for Nuclear Research, Lawrence Berkeley Laboratory", "description": "Dubnium is a synthetic chemical element with the symbol Db and atomic number 105. It is highly radioactive, with the most stable known isotope dubnium-268 having a half-life of about 16 hours."},
         
        {"atomic_number": 106, "symbol": "Sg", "name": "Seaborgium", "korean_name": "시보그늄", "atomic_weight": 269, "category": "transition metal", "group": 6, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d⁴ 7s²", "electronegativity": None, "density": 35, "melting_point": None, "boiling_point": None,
         "discovery_year": 1974, "discovered_by": "Lawrence Berkeley Laboratory", "description": "Seaborgium is a synthetic chemical element with the symbol Sg and atomic number 106. It is named after the American nuclear chemist Glenn T. Seaborg. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 107, "symbol": "Bh", "name": "Bohrium", "korean_name": "보륨", "atomic_weight": 270, "category": "transition metal", "group": 7, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d⁵ 7s²", "electronegativity": None, "density": 37, "melting_point": None, "boiling_point": None,
         "discovery_year": 1981, "discovered_by": "Gesellschaft für Schwerionenforschung", "description": "Bohrium is a synthetic chemical element with the symbol Bh and atomic number 107. It is named after Danish physicist Niels Bohr. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 108, "symbol": "Hs", "name": "Hassium", "korean_name": "하슘", "atomic_weight": 269, "category": "transition metal", "group": 8, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d⁶ 7s²", "electronegativity": None, "density": 41, "melting_point": None, "boiling_point": None,
         "discovery_year": 1984, "discovered_by": "Gesellschaft für Schwerionenforschung", "description": "Hassium is a synthetic chemical element with the symbol Hs and atomic number 108. It is named after the German state of Hesse. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 109, "symbol": "Mt", "name": "Meitnerium", "korean_name": "마이트너륨", "atomic_weight": 278, "category": "transition metal", "group": 9, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d⁷ 7s²", "electronegativity": None, "density": 37.4, "melting_point": None, "boiling_point": None,
         "discovery_year": 1982, "discovered_by": "Gesellschaft für Schwerionenforschung", "description": "Meitnerium is a synthetic chemical element with the symbol Mt and atomic number 109. It is named after Austrian physicist Lise Meitner. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 110, "symbol": "Ds", "name": "Darmstadtium", "korean_name": "다름슈타튬", "atomic_weight": 281, "category": "transition metal", "group": 10, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d⁸ 7s²", "electronegativity": None, "density": 34.8, "melting_point": None, "boiling_point": None,
         "discovery_year": 1994, "discovered_by": "Gesellschaft für Schwerionenforschung", "description": "Darmstadtium is a synthetic chemical element with the symbol Ds and atomic number 110. It is named after the German city of Darmstadt. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 111, "symbol": "Rg", "name": "Roentgenium", "korean_name": "뢴트게늄", "atomic_weight": 282, "category": "transition metal", "group": 11, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d⁹ 7s²", "electronegativity": None, "density": 28.7, "melting_point": None, "boiling_point": None,
         "discovery_year": 1994, "discovered_by": "Gesellschaft für Schwerionenforschung", "description": "Roentgenium is a synthetic chemical element with the symbol Rg and atomic number 111. It is named after the German physicist Wilhelm Röntgen. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 112, "symbol": "Cn", "name": "Copernicium", "korean_name": "코페르니슘", "atomic_weight": 285, "category": "transition metal", "group": 12, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d¹⁰ 7s²", "electronegativity": None, "density": 14.0, "melting_point": None, "boiling_point": 357,
         "discovery_year": 1996, "discovered_by": "Gesellschaft für Schwerionenforschung", "description": "Copernicium is a synthetic chemical element with the symbol Cn and atomic number 112. It is named after the astronomer Nicolaus Copernicus. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 113, "symbol": "Nh", "name": "Nihonium", "korean_name": "니호늄", "atomic_weight": 286, "category": "post-transition metal", "group": 13, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p¹", "electronegativity": None, "density": 16, "melting_point": 700, "boiling_point": 1400,
         "discovery_year": 2004, "discovered_by": "RIKEN", "description": "Nihonium is a synthetic chemical element with the symbol Nh and atomic number 113. It is named after Japan (Nihon in Japanese). As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 114, "symbol": "Fl", "name": "Flerovium", "korean_name": "플레로븀", "atomic_weight": 289, "category": "post-transition metal", "group": 14, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p²", "electronegativity": None, "density": 14, "melting_point": 340, "boiling_point": 420,
         "discovery_year": 1999, "discovered_by": "Joint Institute for Nuclear Research", "description": "Flerovium is a superheavy synthetic chemical element with the symbol Fl and atomic number 114. It is named after the Flerov Laboratory of Nuclear Reactions of the Joint Institute for Nuclear Research in Dubna, Russia."},
         
        {"atomic_number": 115, "symbol": "Mc", "name": "Moscovium", "korean_name": "모스코븀", "atomic_weight": 290, "category": "post-transition metal", "group": 15, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p³", "electronegativity": None, "density": 13.5, "melting_point": 670, "boiling_point": 1400,
         "discovery_year": 2004, "discovered_by": "Joint Institute for Nuclear Research, Lawrence Livermore National Laboratory", "description": "Moscovium is a synthetic chemical element with the symbol Mc and atomic number 115. It is named after the Moscow Oblast of Russia. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 116, "symbol": "Lv", "name": "Livermorium", "korean_name": "리버모륨", "atomic_weight": 293, "category": "post-transition metal", "group": 16, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁴", "electronegativity": None, "density": 12.9, "melting_point": 709, "boiling_point": 1085,
         "discovery_year": 2000, "discovered_by": "Joint Institute for Nuclear Research, Lawrence Livermore National Laboratory", "description": "Livermorium is a synthetic chemical element with the symbol Lv and atomic number 116. It is named after the Lawrence Livermore National Laboratory in the United States. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 117, "symbol": "Ts", "name": "Tennessine", "korean_name": "테네신", "atomic_weight": 294, "category": "halogen", "group": 17, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁵", "electronegativity": None, "density": 7.2, "melting_point": 723, "boiling_point": 883,
         "discovery_year": 2010, "discovered_by": "Joint Institute for Nuclear Research, Oak Ridge National Laboratory", "description": "Tennessine is a synthetic chemical element with the symbol Ts and atomic number 117. It is named after the U.S. state of Tennessee. As a synthetic element, it is not found in nature and can only be created in a laboratory."},
         
        {"atomic_number": 118, "symbol": "Og", "name": "Oganesson", "korean_name": "오가네손", "atomic_weight": 294, "category": "noble gas", "group": 18, "period": 7,
         "electron_configuration": "[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁶", "electronegativity": None, "density": 5, "melting_point": 325, "boiling_point": 450,
         "discovery_year": 2006, "discovered_by": "Joint Institute for Nuclear Research, Lawrence Livermore National Laboratory", "description": "Oganesson is a synthetic chemical element with the symbol Og and atomic number 118. It was first synthesized in 2002 at the Joint Institute for Nuclear Research in Dubna, Russia. It is named after the Russian nuclear physicist Yuri Oganessian."}
    ]
    
    # For a complete implementation, you would include all 118 elements
    # This is a representative sample to demonstrate the structure
    
    # Make sure all elements have beginner and advanced descriptions in English
    for element in elements_data:
        # Add beginner description if missing
        if 'beginner_description' not in element or not element['beginner_description'] or str(element['beginner_description']).lower() == 'nan':
            element['beginner_description'] = f"{element['name']} (symbol {element['symbol']}) is element number {element['atomic_number']} on the periodic table. It is classified as a {element['category']}. "
            
            # Add category specific info
            if element['category'] == 'nonmetal':
                element['beginner_description'] += "Nonmetals are generally poor conductors of heat and electricity. They are often found in various states - solid, liquid, or gas."
            elif element['category'] == 'noble gas':
                element['beginner_description'] += "Noble gases are very stable and rarely react with other elements. They are colorless gases under normal conditions."
            elif element['category'] == 'alkali metal':
                element['beginner_description'] += "Alkali metals are highly reactive, especially with water. They are soft, silver-colored metals that must be stored carefully."
            elif element['category'] == 'alkaline earth metal':
                element['beginner_description'] += "Alkaline earth metals are reactive but less so than alkali metals. They are silvery, shiny metals found in the Earth's crust."
            elif element['category'] == 'transition metal':
                element['beginner_description'] += "Transition metals are typically hard, shiny, and good conductors of heat and electricity. They often form colorful compounds."
            elif element['category'] == 'halogen':
                element['beginner_description'] += "Halogens are highly reactive nonmetals that readily form compounds with most elements. They can be found in various states."
            elif element['category'] == 'metalloid':
                element['beginner_description'] += "Metalloids have properties of both metals and nonmetals. They are important in electronics and semiconductor technology."
            elif element['category'] == 'lanthanide':
                element['beginner_description'] += "Lanthanides are rare earth metals with similar properties. They are used in magnets, lasers, and other high-tech applications."
            elif element['category'] == 'actinide':
                element['beginner_description'] += "Actinides are radioactive metals, most of which are synthetic. Some are used in nuclear energy and weapons."
            elif element['category'] == 'post-transition metal':
                element['beginner_description'] += "Post-transition metals are soft with low melting points. They are generally found in the p-block of the periodic table and have some metalloid properties."
            else:
                element['beginner_description'] += f"This element is used in various scientific and industrial applications."
                
            # Add common uses
            if element['atomic_number'] in [3, 11, 19]:  # Li, Na, K
                element['beginner_description'] += " It is commonly used in batteries, glass manufacturing, and various industrial processes."
            elif element['atomic_number'] in [26, 29, 47, 78, 80]:  # Fe, Cu, Ag, Pt, Hg
                element['beginner_description'] += " It is widely used in metal tools, wires, jewelry, catalysts, or measuring equipment."
        
        # Add advanced description if missing
        if 'advanced_description' not in element or not element['advanced_description'] or str(element['advanced_description']).lower() == 'nan':
            element['advanced_description'] = f"{element['name']} (atomic number {element['atomic_number']}) is a {element['category']} with symbol {element['symbol']}. "
            
            # Add electron configuration
            if element['electron_configuration']:
                element['advanced_description'] += f"Its electron configuration is {element['electron_configuration']}. "
            
            # Add physical properties
            if element['density']:
                element['advanced_description'] += f"It has a density of {element['density']} g/cm³. "
            
            if element['melting_point'] and element['boiling_point']:
                element['advanced_description'] += f"Its melting point is {element['melting_point']} K and boiling point is {element['boiling_point']} K. "
            
            # Add electronegativity
            if element['electronegativity']:
                element['advanced_description'] += f"Its electronegativity is {element['electronegativity']} on the Pauling scale. "
            
            # Add category-specific info
            if element['category'] == 'nonmetal':
                element['advanced_description'] += "Nonmetals typically have high ionization energies and electronegativity values. They tend to gain or share electrons to form covalent bonds. They are generally poor conductors of heat and electricity, with low melting and boiling points compared to metals."
            elif element['category'] == 'noble gas':
                element['advanced_description'] += "Noble gases have completely filled outer electron shells, making them extremely stable and chemically inert under normal conditions. They have high ionization energies and zero electronegativity. They exist as monatomic gases with very low melting and boiling points."
            elif element['category'] == 'alkali metal':
                element['advanced_description'] += "Alkali metals have a single valence electron which they readily lose to form ionic compounds with +1 oxidation state. They have the lowest ionization energies among all elements, making them highly reactive, especially with water and oxygen."
            elif element['category'] == 'alkaline earth metal':
                element['advanced_description'] += "Alkaline earth metals have two valence electrons which they lose to form ionic compounds with +2 oxidation state. They are less reactive than alkali metals but still highly reactive with water and oxygen. They form strongly basic oxides."
            elif element['category'] == 'transition metal':
                element['advanced_description'] += "Transition metals have partially filled d-orbitals, allowing them to form multiple oxidation states. They often form colored compounds due to d-d electron transitions. They are good conductors of heat and electricity and typically form coordination compounds."
            elif element['category'] == 'halogen':
                element['advanced_description'] += "Halogens have seven electrons in their outermost shell, making them highly reactive as they seek to gain an electron to achieve a stable octet configuration. They form -1 ions and are strong oxidizing agents. Their reactivity decreases down the group as atomic size increases."
            elif element['category'] == 'metalloid':
                element['advanced_description'] += "Metalloids exhibit properties of both metals and nonmetals. They are semiconductors with electrical conductivity that increases with temperature. They typically form covalent bonds and have amphoteric oxides. Their electronic structures allow them to play crucial roles in semiconductor technology."
            elif element['category'] == 'post-transition metal':
                element['advanced_description'] += "Post-transition metals have completed d-orbitals but incompletely filled p-orbitals. They can form both cations and anions, and exhibit a range of oxidation states. They tend to have lower melting points and greater covalent character in their bonding compared to transition metals."
            elif element['category'] == 'lanthanide':
                element['advanced_description'] += "Lanthanides are characterized by the filling of the 4f electron shell. They exhibit similar chemical properties due to their electron configurations, with +3 being the most common oxidation state. They form colored compounds and many are paramagnetic due to unpaired f electrons."
            elif element['category'] == 'actinide':
                element['advanced_description'] += "Actinides involve the filling of the 5f electron shell. Unlike lanthanides, they show more variable oxidation states. All actinides are radioactive with complex electronic structures and their chemistry is often complicated by their radioactive nature."
            else:
                element['advanced_description'] += f"This element has distinct chemical and physical properties that contribute to its behavior and applications in various scientific and industrial contexts."
            
            # Add discovery info
            if element['discovery_year']:
                if element['discovered_by']:
                    element['advanced_description'] += f" It was discovered in {element['discovery_year']} by {element['discovered_by']}."
                else:
                    element['advanced_description'] += f" It was discovered in {element['discovery_year']}."
    
    # Add Korean descriptions for elements
    for element in elements_data:
        # Make sure all elements have korean_name field (default to empty string if missing)
        if 'korean_name' not in element:
            element['korean_name'] = ''
            
        if 'description' in element and element['description']:
            # Only create Korean descriptions for elements that have Korean names
            if element['korean_name']:
                # Basic Korean description template for all elements
                # Use the translated category name if available
                category_korean = CATEGORY_TRANSLATIONS.get(element['category'], element['category'])
                base_korean_desc = f"{element['korean_name']}는 원소주기율표에서 원자 번호 {element['atomic_number']}번 원소입니다. " + \
                               f"이 원소의 기호는 {element['symbol']}이며, {category_korean} 범주에 속합니다."
                
                # Create translated versions of all description types
                
                # 1. Standard description - make sure it matches the English description
                if element['description']:
                    # First get the English description for reference
                    english_description = element['description']
                    
                    # Create Korean description that matches the English structure and content
                    if element['atomic_number'] == 1:  # Hydrogen
                        element['korean_description'] = f"{element['korean_name']}는 가장 가벼운 원소입니다. 일반적인 조건에서는 H₂ 분자식을 가진 무색, 무취, 무미한 비금속 고연소성 기체입니다."
                    elif element['atomic_number'] == 2:  # Helium
                        element['korean_description'] = f"{element['korean_name']}은 두 번째로 가벼운 원소이며 가장 가벼운 비활성 기체입니다. 무색, 무취, 무미하고 독성이 없습니다. 그것은 우주에서 수소 다음으로 가장 흔한 원소입니다."
                    elif element['atomic_number'] == 6:  # Carbon
                        element['korean_description'] = f"{element['korean_name']}는 생명의 화학적 기초입니다. 지구상의 모든 알려진 생명체는 탄소 기반이며, 그것의 독특한 결합 능력은 생명체가 의존하는 복잡한 분자를 만들 수 있게 합니다."
                    elif element['atomic_number'] == 8:  # Oxygen
                        element['korean_description'] = f"{element['korean_name']}는 지구에서 화학적으로 가장 풍부한 원소이며, 지구 대기의 약 21%를 구성합니다. 그것은 산화와 연소 과정에 관여하는 반응성이 높은 원소입니다."
                    elif element['atomic_number'] == 79:  # Gold
                        element['korean_description'] = f"{element['korean_name']}은 밀도가 높고 연성이 뛰어난 노란색 귀금속입니다. 그것은 전기 전도성이 좋으며 산화에 매우 저항성이 있습니다. 수천 년 동안 장신구, 통화, 그리고 그 특성에 기인한 다양한 용도로 사용되어 왔습니다."
                    # For other elements, provide a structured description based on the element's properties
                    else:
                        # Start with the base description
                        element['korean_description'] = base_korean_desc
                        
                        # Find if there's a specific description pattern in the English description we should match
                        if "synthetic" in english_description.lower() and "chemical element" in english_description.lower():
                            element['korean_description'] = f"{element['korean_name']}은(는) 기호 {element['symbol']}, 원자 번호 {element['atomic_number']}를 가진 합성 화학 원소입니다. "
                            
                            # Match specific elements with special naming
                            if element['atomic_number'] == 115:  # Moscovium
                                element['korean_description'] = f"{element['korean_name']}은 기호 {element['symbol']}, 원자 번호 {element['atomic_number']}를 가진 합성 화학 원소입니다. 이 원소는 러시아의 모스크바 지역(Moscow Oblast)의 이름을 따서 명명되었습니다. 합성 원소로서 자연에서는 발견되지 않으며 오직 실험실에서만 생성될 수 있습니다."
                            elif element['atomic_number'] == 116:  # Livermorium
                                element['korean_description'] = f"{element['korean_name']}은 기호 {element['symbol']}, 원자 번호 {element['atomic_number']}를 가진 합성 화학 원소입니다. 이 원소는 미국의 로렌스 리버모어 국립 연구소(Lawrence Livermore National Laboratory)의 이름을 따서 명명되었습니다. 합성 원소로서 자연에서는 발견되지 않으며 오직 실험실에서만 생성될 수 있습니다."
                            elif element['atomic_number'] == 117:  # Tennessine
                                element['korean_description'] = f"{element['korean_name']}은 기호 {element['symbol']}, 원자 번호 {element['atomic_number']}를 가진 합성 화학 원소입니다. 이 원소는 미국의 테네시 주(Tennessee)의 이름을 따서 명명되었습니다. 합성 원소로서 자연에서는 발견되지 않으며 오직 실험실에서만 생성될 수 있습니다."
                            elif element['atomic_number'] == 118:  # Oganesson
                                element['korean_description'] = f"{element['korean_name']}은 기호 {element['symbol']}, 원자 번호 {element['atomic_number']}를 가진 합성 화학 원소입니다. 이 원소는 러시아 핵물리학자 유리 오가네시안(Yuri Oganessian)의 이름을 따서 명명되었습니다. 2002년 러시아 두브나의 공동 핵 연구소에서 처음 합성되었습니다. 합성 원소로서 자연에서는 발견되지 않으며 오직 실험실에서만 생성될 수 있습니다."
                            # For other elements, try to extract naming information
                            else:
                                # Add naming information if present in English
                                if "named after" in english_description.lower():
                                    if "city" in english_description.lower() or "state" in english_description.lower() or "region" in english_description.lower() or "country" in english_description.lower() or "oblast" in english_description.lower():
                                        place = english_description.split("named after")[1].split(".")[0].strip()
                                        element['korean_description'] += f"이 원소는 {place}의 이름을 따서 명명되었습니다. "
                                    elif "physicist" in english_description.lower() or "scientist" in english_description.lower() or "chemist" in english_description.lower() or "laboratory" in english_description.lower():
                                        person = english_description.split("named after")[1].split(".")[0].strip()
                                        element['korean_description'] += f"이 원소는 {person}의 이름을 따서 명명되었습니다. "
                                
                                # Add synthesized information to match English description
                                element['korean_description'] += "합성 원소로서 자연에서는 발견되지 않으며 오직 실험실에서만 생성될 수 있습니다."
                        else:
                            # Add category-specific information
                            category_korean = CATEGORY_TRANSLATIONS.get(element['category'], element['category'])
                            
                            if element['category'] == 'nonmetal':
                                element['korean_description'] += f" {element['korean_name']}는 {category_korean} 원소로, 일반적으로 열과 전기의 불량 도체입니다. "
                            elif element['category'] == 'noble gas':
                                element['korean_description'] += f" {element['korean_name']}는 {category_korean}로, 화학적으로 매우 안정적이며 반응성이 거의 없습니다. "
                            elif element['category'] == 'alkali metal':
                                element['korean_description'] += f" {element['korean_name']}는 {category_korean}으로, 매우 반응성이 높고 자연에서 순수한 형태로 발견되지 않습니다. "
                            elif element['category'] == 'halogen':
                                element['korean_description'] += f" {element['korean_name']}는 {category_korean}으로, 높은 반응성을 가지고 있으며 다른 원소와 쉽게 화합물을 형성합니다. "
                            elif 'metal' in element['category']:
                                element['korean_description'] += f" {element['korean_name']}는 {category_korean}으로, 광택이 있고 열과 전기를 잘 전도합니다. "
                            
                            # Add physical properties to match English description pattern
                            if "solid" in english_description.lower():
                                element['korean_description'] += "이 원소는 고체 상태입니다. "
                            elif "liquid" in english_description.lower():
                                element['korean_description'] += "이 원소는 액체 상태입니다. "
                            elif "gas" in english_description.lower():
                                element['korean_description'] += "이 원소는 기체 상태입니다. "
                        
                        # Add atomic weight information if mentioned in English
                        if element['atomic_weight'] and "weight" in english_description.lower():
                            element['korean_description'] += f"원자량은 {element['atomic_weight']}u입니다. "
                        
                        # Add physical properties if available and mentioned in English
                        if element['melting_point'] and element['boiling_point'] and ("melting" in english_description.lower() or "boiling" in english_description.lower()):
                            element['korean_description'] += f"녹는점은 {element['melting_point']} K이며, 끓는점은 {element['boiling_point']} K입니다. "
                        
                        # Add group and period information if mentioned
                        if element['group'] and element['period'] and ("group" in english_description.lower() or "period" in english_description.lower()):
                            element['korean_description'] += f"주기율표에서 {element['period']}주기 {element['group']}족에 위치합니다. "
                        
                        # Add discovery info if mentioned in English
                        if element['discovery_year'] and "discover" in english_description.lower():
                            if element['discovered_by']:
                                element['korean_description'] += f"{element['korean_name']}는 {element['discovery_year']}년에 {element['discovered_by']}에 의해 발견되었습니다."
                            else:
                                element['korean_description'] += f"{element['korean_name']}는 {element['discovery_year']}년에 발견되었습니다."
                
                # 2. Always create beginner and advanced descriptions in Korean
                
                # First get the English version to ensure consistency
                english_beginner = element['beginner_description']
                english_advanced = element['advanced_description']
                
                # Create a beginner description
                element['korean_beginner_description'] = f"{element['korean_name']}(기호 {element['symbol']})는 주기율표에서 원자 번호 {element['atomic_number']}번 원소입니다. {CATEGORY_TRANSLATIONS.get(element['category'], element['category'])}으로 분류됩니다. "
                
                # Choose specific descriptions for common elements
                if element['atomic_number'] == 1:  # Hydrogen
                    element['korean_beginner_description'] = f"{element['korean_name']}는 우주에서 가장 단순하고 흔한 원소입니다. 태양과 별들의 대부분을 구성하는 기체입니다. 지구에서는 연료와 중요한 화학물질을 만드는 데 사용됩니다."
                elif element['atomic_number'] == 2:  # Helium
                    element['korean_beginner_description'] = f"{element['korean_name']}은 풍선을 떠오르게 하는 기체입니다. 매우 가볍고 소량으로는 들이마셔도 안전하며, 이 때문에 목소리가 우스꽝스럽게 들리게 됩니다. 지하 깊은 곳에서 발견되며 생일 풍선과 비행선에 사용됩니다."
                elif element['atomic_number'] == 6:  # Carbon
                    element['korean_beginner_description'] = f"{element['korean_name']}는 모든 생물체에서 발견되는 원소입니다. 생명의 기본 구성 요소를 이룹니다. {element['korean_name']}는 흑연(연필심), 다이아몬드, 석탄과 같은 다양한 형태로 존재합니다. 식물과 동물이 성장하도록 하는 요소입니다."
                elif element['atomic_number'] == 8:  # Oxygen
                    element['korean_beginner_description'] = f"{element['korean_name']}는 우리가 살아있기 위해 필요한 공기 원소입니다. 식물은 {element['korean_name']}를 만들고, 우리는 이것을 들이마십니다. 주변 공기의 약 21%를 차지합니다. {element['korean_name']} 없이는 불이 탈 수 없습니다."
                elif element['atomic_number'] == 79:  # Gold
                    element['korean_beginner_description'] = f"{element['korean_name']}은 아름다운 노란색 금속으로, 수천 년 동안 귀중한 보석과 화폐로 사용되어 왔습니다. 녹이 슬지 않고 부드러워 쉽게 모양을 만들 수 있습니다. 보석, 전자제품, 치과 치료에 사용됩니다."
                else:
                    # Generate based on category for other elements
                    category_korean = CATEGORY_TRANSLATIONS.get(element['category'], element['category'])
                    
                    # Generate category-specific beginner descriptions
                    if element['category'] == 'nonmetal':
                        element['korean_beginner_description'] += f"{category_korean}은 일반적으로 열이나 전기를 잘 전도하지 않습니다. 고체, 액체 또는 기체 등 다양한 상태로 존재할 수 있습니다."
                    elif element['category'] == 'noble gas':
                        element['korean_beginner_description'] += f"{category_korean}는 매우 안정적이고 다른 원소와 거의 반응하지 않습니다. 일반 조건에서는 무색의 기체 상태로 존재합니다."
                    elif element['category'] == 'alkali metal':
                        element['korean_beginner_description'] += f"{category_korean}은 특히 물과 접촉 시 매우 반응성이 높습니다. 부드럽고 은색을 띠는 금속으로, 신중하게 보관해야 합니다."
                    elif element['category'] == 'alkaline earth metal':
                        element['korean_beginner_description'] += f"{category_korean}은 알칼리 금속보다는 반응성이 덜하지만 여전히 활성이 높습니다. 지구 지각에서 발견되는 은빛 광택의 금속입니다."
                    elif element['category'] == 'transition metal':
                        element['korean_beginner_description'] += f"{category_korean}은 일반적으로 단단하고 광택이 있으며, 열과 전기를 잘 전도합니다. 다양한 색상의 화합물을 형성하는 경우가 많습니다."
                    elif element['category'] == 'halogen':
                        element['korean_beginner_description'] += f"{category_korean}은 높은 반응성을 가진 비금속으로, 대부분의 원소와 쉽게 화합물을 형성합니다. 다양한 상태로 존재할 수 있습니다."
                    elif element['category'] == 'metalloid':
                        element['korean_beginner_description'] += f"{category_korean}은 금속과 비금속의 특성을 모두 가지고 있습니다. 전자 제품 및 반도체 기술에서 중요한 역할을 합니다."
                    elif element['category'] == 'post-transition metal':
                        element['korean_beginner_description'] += f"{category_korean}은 부드럽고 녹는점이 낮습니다. 주기율표의 p 블록에 위치하며 일부 준금속 특성을 가지고 있습니다."
                    elif element['category'] == 'lanthanide':
                        element['korean_beginner_description'] += f"{category_korean}은 유사한 특성을 가진 희토류 금속입니다. 자석, 레이저 및 기타 첨단 기술 응용 분야에 사용됩니다."
                    elif element['category'] == 'actinide':
                        element['korean_beginner_description'] += f"{category_korean}은 대부분 합성된 방사성 금속입니다. 일부는 원자력 에너지와 무기에 사용됩니다."
                    else:
                        element['korean_beginner_description'] += f"이 원소는 다양한 과학 및 산업 응용 분야에 사용됩니다."
                
                # Add common uses for specific element groups to match English description
                if element['atomic_number'] in [3, 11, 19]:  # Li, Na, K
                    element['korean_beginner_description'] += f" 일반적으로 배터리, 유리 제조 및 다양한 산업 공정에 사용됩니다."
                elif element['atomic_number'] in [26, 29, 47, 78, 80]:  # Fe, Cu, Ag, Pt, Hg
                    element['korean_beginner_description'] += f" 금속 도구, 전선, 장신구, 촉매 또는 측정 장비 등에 널리 사용됩니다."
                
                # Create an advanced description that matches the English version's level of detail
                # Choose specific detailed descriptions for important elements
                if element['atomic_number'] == 1:  # Hydrogen
                    element['korean_advanced_description'] = f"{element['korean_name']}(원자 번호 {element['atomic_number']})는 전 우주에서 가장 풍부한 화학물질로, 전체 중입자 질량의 약 75%를 차지합니다. 표준 조건에서 이원자 기체(H₂)로 존재하며 산소와 혼합되면 매우 가연성이 높습니다. 수소의 전자 배치(1s¹)는 독특한 특성을 부여하여 전자를 잃고 H+(양성자)를 형성하거나, 전자를 얻어 H-(수소화 이온)를 형성하거나, 전자를 공유하여 공유 결합을 형성할 수 있습니다. 수소는 양성자(¹H), 중수소(²H), 삼중수소(³H)의 세 가지 동위원소를 가지며, 후자는 방사성입니다. 수소는 별들의 핵융합 과정에서 중요한 역할을 하며 청정 에너지 운반체로 연구되고 있습니다."
                elif element['atomic_number'] == 6:  # Carbon
                    element['korean_advanced_description'] = f"{element['korean_name']}(원자 번호 {element['atomic_number']})는 유기화학과 생화학의 기초입니다. 자신이나 다른 원소와 강한 공유 결합을 형성하여 긴 사슬, 고리 및 복잡한 3D 구조를 만드는 독특한 능력이 있습니다. 탄소는 다이아몬드(sp³ 혼성화), 흑연(sp² 혼성화), 풀러렌을 포함한 여러 동소체로 존재합니다. 전자 배치 [He]2s²2p²는 네 개의 결합을 형성할 수 있게 하여 수백만 가지 유기 화합물을 형성하는 데 매우 다양하게 활용됩니다. 탄소 순환은 지구의 생지화학적 과정에 기본적이며, 탄소-14는 방사성 탄소 연대 측정에 중요합니다."
                elif element['atomic_number'] == 8:  # Oxygen
                    element['korean_advanced_description'] = f"{element['korean_name']}(원자 번호 {element['atomic_number']})는 지구 지각에서 질량으로 가장 풍부한 세 번째 요소이며, 모든 생명체에 필수적인 요소입니다. 대기의 약 21%를 구성하며, 대부분의 산화-환원 반응에 참여합니다. 두 개의 비공유 전자쌍을 가진 높은 전기 음성도(3.44)로 인해 매우 반응성이 높습니다. 산소는 일반적으로 이원자 분자(O₂)로 존재하지만, 성층권에서는 자외선에 의해 오존(O₃)으로 변환됩니다. 주요 동위원소로는 ¹⁶O(99.76%), ¹⁷O, ¹⁸O이 있습니다. 산소의 다양한 산화 상태(-2에서 +2까지)는 산화물, 과산화물, 초산화물 등 다양한 화합물을 형성할 수 있게 합니다. 산소는 의료 용도로 중요하며 생명체의 세포 호흡과 연소 과정에 필수적입니다."
                elif element['atomic_number'] == 79:  # Gold
                    element['korean_advanced_description'] = f"{element['korean_name']}(원자 번호 {element['atomic_number']})는 자연 상태에서 발견되는 귀금속으로, 주기율표에서 전이 금속에 속합니다. 전자 배치 [Xe]4f¹⁴5d¹⁰6s¹이 특징인 금은 화학적으로 비활성이며 대부분의 산과 염기에 저항성이 있습니다. 밀도 19.3 g/cm³의 무른 금속으로, 뛰어난 연성과 전성을 가지고 있어 1g으로 1제곱미터의 박을 만들 수 있습니다. 금은 산화나 부식에 저항성이 있어 장신구나 통화로 오랫동안 가치를 보존할 수 있습니다. 주요 동위원소는 ¹⁹⁷Au뿐이며, 금의 화학적 안정성과 전기 전도성 덕분에 전자 장치, 의학 진단, 촉매 및 방사선 차폐 물질로 널리 사용됩니다."
                else:
                    # Generate comprehensive advanced description to match English content
                    element['korean_advanced_description'] = f"{element['korean_name']}(원자 번호 {element['atomic_number']})는 {CATEGORY_TRANSLATIONS.get(element['category'], element['category'])}으로 기호는 {element['symbol']}입니다. "
                    
                    # Add electron configuration info
                    if element['electron_configuration']:
                        element['korean_advanced_description'] += f"전자 배치는 {element['electron_configuration']}입니다. "
                    
                    # Add physical properties
                    if element['density']:
                        element['korean_advanced_description'] += f"밀도는 {element['density']} g/cm³입니다. "
                    
                    if element['melting_point'] and element['boiling_point']:
                        element['korean_advanced_description'] += f"녹는점은 {element['melting_point']} K이고 끓는점은 {element['boiling_point']} K입니다. "
                    
                    # Add electronegativity to match English description
                    if element['electronegativity']:
                        element['korean_advanced_description'] += f"폴링 척도에서 전기 음성도는 {element['electronegativity']}입니다. "
                
                    # Add category-specific detailed information to match English description
                    category_korean = CATEGORY_TRANSLATIONS.get(element['category'], element['category'])
                    
                    if element['category'] == 'nonmetal':
                        element['korean_advanced_description'] += f"{category_korean}은 일반적으로 높은 이온화 에너지와 전기 음성도를 가집니다. 전자를 얻거나 공유하여 공유 결합을 형성하는 경향이 있습니다. 일반적으로 열과 전기의 불량 도체이며, 금속에 비해 녹는점과 끓는점이 낮습니다."
                    elif element['category'] == 'noble gas':
                        element['korean_advanced_description'] += f"{category_korean}는 완전히 채워진 외부 전자 껍질을 가지고 있어 일반 조건에서 매우 안정적이고 화학적으로 불활성입니다. 높은 이온화 에너지와 거의 0에 가까운 전기 음성도를 가집니다. 매우 낮은 녹는점과 끓는점을 가진 단원자 기체로 존재합니다."
                    elif element['category'] == 'alkali metal':
                        element['korean_advanced_description'] += f"{category_korean}은 쉽게 전자를 잃어 +1 산화 상태의 이온성 화합물을 형성하는 단일 원자가 전자를 가지고 있습니다. 모든 원소 중 가장 낮은 이온화 에너지를 가지고 있어 물과 산소에 대해 특히 반응성이 높습니다."
                    elif element['category'] == 'alkaline earth metal':
                        element['korean_advanced_description'] += f"{category_korean}은 두 개의 원자가 전자를 잃어 +2 산화 상태의 이온성 화합물을 형성합니다. 알칼리 금속보다는 반응성이 낮지만 여전히 물과 산소에 대해 높은 반응성을 보입니다. 강한 염기성 산화물을 형성합니다."
                    elif element['category'] == 'transition metal':
                        element['korean_advanced_description'] += f"{category_korean}은 부분적으로 채워진 d-오비탈을 가지고 있어 여러 산화 상태를 형성할 수 있습니다. d-d 전자 전이로 인해 종종 색상이 있는 화합물을 형성합니다. 열과 전기의 좋은 도체이며 일반적으로 배위 화합물을 형성합니다."
                    elif element['category'] == 'halogen':
                        element['korean_advanced_description'] += f"{category_korean}은 가장 바깥쪽 껍질에 7개의 전자를 가지고 있어, 안정적인 옥텟 구조를 이루기 위해 전자를 얻으려는 경향이 강해 매우 반응성이 높습니다. -1 이온을 형성하며 강한 산화제입니다. 원자 크기가 증가함에 따라 반응성은 감소합니다."
                    elif element['category'] == 'metalloid':
                        element['korean_advanced_description'] += f"{category_korean}은 금속과 비금속의 특성을 모두 보입니다. 온도가 올라갈수록 전기 전도도가 증가하는 반도체입니다. 일반적으로 공유 결합을 형성하고 양쪽성 산화물을 가집니다. 전자 구조 덕분에 반도체 기술에서 중요한 역할을 합니다."
                    elif element['category'] == 'post-transition metal':
                        element['korean_advanced_description'] += f"{category_korean}은 완전히 채워진 d-오비탈을 가지지만 불완전하게 채워진 p-오비탈을 가집니다. 양이온과 음이온을 모두 형성할 수 있으며, 다양한 산화 상태를 보입니다. 전이 금속에 비해 녹는점이 낮고 결합에서 공유 특성이 더 강합니다."
                    elif element['category'] == 'lanthanide':
                        element['korean_advanced_description'] += f"{category_korean}은 4f 전자 껍질이 채워지는 것이 특징입니다. 전자 배치로 인해 유사한 화학적 특성을 보이며, +3이 가장 일반적인 산화 상태입니다. 색상이 있는 화합물을 형성하며, 쌍을 이루지 않은 f 전자로 인해 많은 원소가 상자성을 띱니다."
                    elif element['category'] == 'actinide':
                        element['korean_advanced_description'] += f"{category_korean}은 5f 전자 껍질이 채워지는 것이 특징입니다. 란타넘족과 달리 더 다양한 산화 상태를 보입니다. 모든 악티늄족 원소는 방사성을 띠며 복잡한 전자 구조를 가지고 있으며, 그 화학적 특성은 종종 방사능 특성에 의해 복잡해집니다."
                    else:
                        element['korean_advanced_description'] += f"이 원소는 다양한 과학 및 산업 분야에서의 행동과 응용에 기여하는 독특한 화학적, 물리적 특성을 가지고 있습니다."
                    
                    # Add discovery info to match English description
                    if element['discovery_year']:
                        if element['discovered_by']:
                            element['korean_advanced_description'] += f" {element['discovery_year']}년에 {element['discovered_by']}에 의해 발견되었습니다."
                        else:
                            element['korean_advanced_description'] += f" {element['discovery_year']}년에 발견되었습니다."
            else:
                # If no Korean name is available, use empty strings
                element['korean_description'] = ""
                if 'beginner_description' in element:
                    element['korean_beginner_description'] = ""
                if 'advanced_description' in element:
                    element['korean_advanced_description'] = ""
    
    return pd.DataFrame(elements_data)

# Load the elements data
elements_df = create_elements_data()

def get_element_by_atomic_number(atomic_number):
    """Get element data by atomic number"""
    element = elements_df[elements_df.atomic_number == atomic_number]
    if len(element) == 0:
        return None
    return element.iloc[0].to_dict()

def get_element_by_symbol(symbol):
    """Get element data by symbol"""
    element = elements_df[elements_df.symbol == symbol]
    if len(element) == 0:
        return None
    return element.iloc[0].to_dict()

def get_element_by_name(name):
    """Get element data by name"""
    element = elements_df[elements_df.name.str.lower() == name.lower()]
    if len(element) == 0:
        return None
    return element.iloc[0].to_dict()

def get_element_by_korean_name(korean_name):
    """Get element data by Korean name"""
    element = elements_df[elements_df.korean_name == korean_name]
    if len(element) == 0:
        return None
    return element.iloc[0].to_dict()

def search_elements(query):
    """Search elements by name, symbol, atomic number, or Korean name"""
    query = str(query).lower()
    
    # Try to convert to atomic number if the query is a number
    try:
        atomic_number = int(query)
        element = elements_df[elements_df.atomic_number == atomic_number]
        if len(element) > 0:
            return [element.iloc[0].to_dict()]
    except ValueError:
        pass
    
    # Search by symbol (exact match)
    element_by_symbol = elements_df[elements_df.symbol.str.lower() == query]
    if len(element_by_symbol) > 0:
        return [element_by_symbol.iloc[0].to_dict()]
    
    # Search by name (contains)
    elements_by_name = elements_df[elements_df.name.str.lower().str.contains(query)]
    if len(elements_by_name) > 0:
        return [row.to_dict() for _, row in elements_by_name.iterrows()]
    
    # Search by Korean name (contains)
    elements_by_korean = elements_df[elements_df.korean_name.str.contains(query, regex=False)]
    if len(elements_by_korean) > 0:
        return [row.to_dict() for _, row in elements_by_korean.iterrows()]
    
    # If no exact matches, try to find elements that start with the query
    if len(query) >= 1:
        elements_starting_with = elements_df[
            elements_df.name.str.lower().str.startswith(query) | 
            elements_df.symbol.str.lower().str.startswith(query) | 
            elements_df.korean_name.str.startswith(query, na=False)
        ]
        if len(elements_starting_with) > 0:
            return [row.to_dict() for _, row in elements_starting_with.iterrows()]
    
    return []

def get_element_suggestions(query, max_suggestions=5):
    """Get element suggestions based on a partial search query
    
    Args:
        query (str): The partial search query
        max_suggestions (int): Maximum number of suggestions to return
        
    Returns:
        list: List of suggested element dictionaries
    """
    if not query or len(query) < 1:
        return []
    
    query = str(query).lower()
    suggestions = []
    
    # Match by symbol starting with query
    symbol_matches = elements_df[elements_df.symbol.str.lower().str.startswith(query)]
    if len(symbol_matches) > 0:
        suggestions.extend([row.to_dict() for _, row in symbol_matches.iterrows()])
    
    # Match by name starting with query
    name_matches = elements_df[elements_df.name.str.lower().str.startswith(query)]
    if len(name_matches) > 0:
        for _, row in name_matches.iterrows():
            if row['symbol'] not in [s['symbol'] for s in suggestions]:  # Avoid duplicates
                suggestions.append(row.to_dict())
    
    # Match by Korean name starting with query
    korean_matches = elements_df[elements_df.korean_name.str.startswith(query, na=False)]
    if len(korean_matches) > 0:
        for _, row in korean_matches.iterrows():
            if row['symbol'] not in [s['symbol'] for s in suggestions]:  # Avoid duplicates
                suggestions.append(row.to_dict())
    
    # If we still need more suggestions, try contains
    if len(suggestions) < max_suggestions:
        # Try English name contains
        name_contains = elements_df[elements_df.name.str.lower().str.contains(query) & 
                                   ~elements_df.name.str.lower().str.startswith(query)]
        
        if len(name_contains) > 0:
            for _, row in name_contains.iterrows():
                if row['symbol'] not in [s['symbol'] for s in suggestions] and len(suggestions) < max_suggestions:
                    suggestions.append(row.to_dict())
        
        # Try Korean name contains
        if len(suggestions) < max_suggestions:
            korean_contains = elements_df[elements_df.korean_name.str.contains(query, regex=False, na=False) & 
                                         ~elements_df.korean_name.str.startswith(query, na=False)]
            
            if len(korean_contains) > 0:
                for _, row in korean_contains.iterrows():
                    if row['symbol'] not in [s['symbol'] for s in suggestions] and len(suggestions) < max_suggestions:
                        suggestions.append(row.to_dict())
    
    return suggestions[:max_suggestions]

def get_all_elements():
    """Get all elements as a list of dictionaries"""
    return [row.to_dict() for _, row in elements_df.iterrows()]

def get_element_color(category):
    """Get the color for an element category"""
    return CATEGORIES.get(category, CATEGORIES["unknown"])
