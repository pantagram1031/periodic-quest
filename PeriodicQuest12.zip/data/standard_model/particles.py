"""
Module containing the Standard Model particles data and helper functions.
"""

def create_particles_data():
    """Create a comprehensive dataset of Standard Model particles"""
    
    particles = []
    
    # Quarks (6 types, 3 generations)
    quarks = [
        {
            "name": "Up Quark",
            "korean_name": "업 쿼크",
            "symbol": "u",
            "category": "quark",
            "charge": "+2/3",
            "mass": "2.16 MeV/c²",
            "spin": "1/2",
            "generation": 1,
            "description": "The up quark is the lightest of all quarks and, together with the down quark, forms protons and neutrons.",
            "korean_description": "업 쿼크는 모든 쿼크 중 가장 가벼우며, 다운 쿼크와 함께 양성자와 중성자를 형성합니다."
        },
        {
            "name": "Down Quark",
            "korean_name": "다운 쿼크",
            "symbol": "d",
            "category": "quark",
            "charge": "-1/3",
            "mass": "4.67 MeV/c²",
            "spin": "1/2",
            "generation": 1,
            "description": "The down quark is the second lightest quark. Protons contain one down quark and two up quarks, while neutrons contain two down quarks and one up quark.",
            "korean_description": "다운 쿼크는 두 번째로 가벼운 쿼크입니다. 양성자는 하나의 다운 쿼크와, 두 개의 업 쿼크를 포함하고, 중성자는 두 개의 다운 쿼크와 하나의 업 쿼크를 포함합니다."
        },
        {
            "name": "Charm Quark",
            "korean_name": "참 쿼크",
            "symbol": "c",
            "category": "quark",
            "charge": "+2/3",
            "mass": "1.27 GeV/c²",
            "spin": "1/2",
            "generation": 2,
            "description": "The charm quark is much heavier than the up and down quarks. It was predicted in 1970 and discovered in 1974 in both the J/ψ meson and the charmed baryons.",
            "korean_description": "참 쿼크는 업 쿼크와 다운 쿼크보다 훨씬 무겁습니다. 1970년에 예측되었고 1974년에 J/ψ 중간자와 매력적인 중입자에서 발견되었습니다."
        },
        {
            "name": "Strange Quark",
            "korean_name": "스트레인지 쿼크",
            "symbol": "s",
            "category": "quark",
            "charge": "-1/3",
            "mass": "93 MeV/c²",
            "spin": "1/2",
            "generation": 2,
            "description": "The strange quark was discovered in cosmic ray interactions in the 1950s, before the quark model was proposed. Particles containing strange quarks are called 'strange particles'.",
            "korean_description": "스트레인지 쿼크는 쿼크 모델이 제안되기 전인 1950년대에 우주선 상호작용에서 발견되었습니다. 스트레인지 쿼크를 포함하는 입자는 '이상 입자'라고 불립니다."
        },
        {
            "name": "Top Quark",
            "korean_name": "탑 쿼크",
            "symbol": "t",
            "category": "quark",
            "charge": "+2/3",
            "mass": "172.76 GeV/c²",
            "spin": "1/2",
            "generation": 3,
            "description": "The top quark is the most massive of all observed elementary particles. It was discovered in 1995 at Fermilab and is so heavy that it decays before it can form hadrons.",
            "korean_description": "탑 쿼크는 관찰된 모든 기본 입자 중 가장 무거운 입자입니다. 1995년 페르미랩에서 발견되었으며, 너무 무거워서 하드론을 형성하기 전에 붕괴합니다."
        },
        {
            "name": "Bottom Quark",
            "korean_name": "바텀 쿼크",
            "symbol": "b",
            "category": "quark",
            "charge": "-1/3",
            "mass": "4.18 GeV/c²",
            "spin": "1/2",
            "generation": 3,
            "description": "The bottom quark, also called the beauty quark, was discovered in 1977. It is found in B mesons and bottomonium states.",
            "korean_description": "바텀 쿼크는 뷰티 쿼크라고도 불리며 1977년에 발견되었습니다. B 중간자와 바텀오니움 상태에서 발견됩니다."
        }
    ]
    particles.extend(quarks)
    
    # Leptons (6 types, 3 generations)
    leptons = [
        {
            "name": "Electron",
            "korean_name": "전자",
            "symbol": "e⁻",
            "category": "lepton",
            "charge": "-1",
            "mass": "0.511 MeV/c²",
            "spin": "1/2",
            "generation": 1,
            "description": "The electron is a fundamental constituent of matter. It carries a negative elementary electric charge and forms the shells around atoms.",
            "korean_description": "전자는 물질의 기본 구성 요소입니다. 기본 음전하를 가지고 있으며 원자 주위의 껍질을 형성합니다."
        },
        {
            "name": "Electron Neutrino",
            "korean_name": "전자 중성미자",
            "symbol": "νₑ",
            "category": "lepton",
            "charge": "0",
            "mass": "<1.1 eV/c²",
            "spin": "1/2",
            "generation": 1,
            "description": "The electron neutrino is a nearly massless particle that rarely interacts with matter. It is produced in beta decay and nuclear fusion reactions.",
            "korean_description": "전자 중성미자는 물질과 거의 상호작용하지 않는 거의 질량이 없는 입자입니다. 베타 붕괴와 핵융합 반응에서 생성됩니다."
        },
        {
            "name": "Muon",
            "korean_name": "뮤온",
            "symbol": "μ⁻",
            "category": "lepton",
            "charge": "-1",
            "mass": "105.66 MeV/c²",
            "spin": "1/2",
            "generation": 2,
            "description": "The muon is similar to the electron but about 200 times heavier. It is unstable and decays with a mean lifetime of 2.2 microseconds.",
            "korean_description": "뮤온은 전자와 유사하지만 약 200배 더 무겁습니다. 불안정하며 평균 수명이 2.2 마이크로초로 붕괴합니다."
        },
        {
            "name": "Muon Neutrino",
            "korean_name": "뮤온 중성미자",
            "symbol": "νᵤ",
            "category": "lepton",
            "charge": "0",
            "mass": "<0.19 MeV/c²",
            "spin": "1/2",
            "generation": 2,
            "description": "The muon neutrino is a neutrino associated with the muon. It was first detected in 1962, proving it was distinct from the electron neutrino.",
            "korean_description": "뮤온 중성미자는 뮤온과 관련된 중성미자입니다. 1962년에 처음 감지되었으며, 전자 중성미자와 다르다는 것이 증명되었습니다."
        },
        {
            "name": "Tau",
            "korean_name": "타우",
            "symbol": "τ⁻",
            "category": "lepton",
            "charge": "-1",
            "mass": "1776.86 MeV/c²",
            "spin": "1/2",
            "generation": 3,
            "description": "The tau is the heaviest of the charged leptons with a mass almost twice that of a proton. It decays rapidly into hadrons or lighter leptons.",
            "korean_description": "타우는 하전 렙톤 중 가장 무거우며 질량이 양성자의 거의 두 배입니다. 하드론이나 더 가벼운 렙톤으로 빠르게 붕괴합니다."
        },
        {
            "name": "Tau Neutrino",
            "korean_name": "타우 중성미자",
            "symbol": "νᵼ",
            "category": "lepton",
            "charge": "0",
            "mass": "<18.2 MeV/c²",
            "spin": "1/2",
            "generation": 3,
            "description": "The tau neutrino is the third and heaviest neutrino. It was directly observed in 2000 by the DONUT experiment at Fermilab.",
            "korean_description": "타우 중성미자는 세 번째이자 가장 무거운 중성미자입니다. 2000년 페르미랩의 DONUT 실험에서 직접 관찰되었습니다."
        }
    ]
    particles.extend(leptons)
    
    # Gauge Bosons (force carriers)
    gauge_bosons = [
        {
            "name": "Photon",
            "korean_name": "광자",
            "symbol": "γ",
            "category": "gauge boson",
            "charge": "0",
            "mass": "0",
            "spin": "1",
            "force": "Electromagnetic",
            "description": "The photon is the carrier particle for the electromagnetic force. It is massless, has no electric charge, and is stable.",
            "korean_description": "광자는 전자기력의 매개 입자입니다. 질량이 없고, 전하도 없으며, 안정적입니다."
        },
        {
            "name": "W Boson",
            "korean_name": "W 보손",
            "symbol": "W±",
            "category": "gauge boson",
            "charge": "±1",
            "mass": "80.4 GeV/c²",
            "spin": "1",
            "force": "Weak",
            "description": "The W bosons mediate the weak force's charged-current interactions, responsible for nuclear beta decay. They are the only known carriers of electric charge among the gauge bosons.",
            "korean_description": "W 보손은 핵 베타 붕괴를 담당하는 약한 힘의 하전-전류 상호작용을 매개합니다. 게이지 보손 중 유일하게 전하를 가진 입자입니다."
        },
        {
            "name": "Z Boson",
            "korean_name": "Z 보손",
            "symbol": "Z⁰",
            "category": "gauge boson",
            "charge": "0",
            "mass": "91.2 GeV/c²",
            "spin": "1",
            "force": "Weak",
            "description": "The Z boson mediates the weak force's neutral-current interactions. Unlike the W bosons, it does not change the flavor of the particles it interacts with.",
            "korean_description": "Z 보손은 약한 힘의 중성-전류 상호작용을 매개합니다. W 보손과 달리 상호작용하는 입자의 맛을 변화시키지 않습니다."
        },
        {
            "name": "Gluon",
            "korean_name": "글루온",
            "symbol": "g",
            "category": "gauge boson",
            "charge": "0",
            "mass": "0",
            "spin": "1",
            "force": "Strong",
            "description": "Gluons are the carriers of the strong force that binds quarks together to form hadrons. They carry a color charge and are themselves subject to the strong force.",
            "korean_description": "글루온은 쿼크를 결합시켜 하드론을 형성하는 강한 힘의 매개 입자입니다. 색 전하를 가지고 있으며 스스로도 강한 힘의 영향을 받습니다."
        }
    ]
    particles.extend(gauge_bosons)
    
    # Scalar Bosons
    scalar_bosons = [
        {
            "name": "Higgs Boson",
            "korean_name": "힉스 보손",
            "symbol": "H",
            "category": "scalar boson",
            "charge": "0",
            "mass": "125.35 GeV/c²",
            "spin": "0",
            "force": None,
            "description": "The Higgs boson is associated with the Higgs field, which gives mass to other elementary particles. It was the last particle predicted by the Standard Model to be discovered, confirmed in 2012 at CERN.",
            "korean_description": "힉스 보손은 다른 기본 입자에 질량을 부여하는 힉스 장과 관련되어 있습니다. 표준 모형이 예측한 마지막 입자로 2012년 CERN에서 발견이 확인되었습니다."
        }
    ]
    particles.extend(scalar_bosons)
    
    return particles

# Create the global particles data
PARTICLES_DATA = create_particles_data()

def get_particle_by_name(name):
    """Get particle data by name (English or Korean)"""
    for particle in PARTICLES_DATA:
        if (particle["name"].lower() == name.lower() or 
            ("korean_name" in particle and particle["korean_name"] == name)):
            return particle
    return None

def get_particle_by_symbol(symbol):
    """Get particle data by symbol"""
    for particle in PARTICLES_DATA:
        if particle["symbol"].lower() == symbol.lower():
            return particle
    return None

def search_particles(query):
    """Search particles by name, symbol, category, or Korean attributes"""
    query = query.lower()
    results = []
    
    for particle in PARTICLES_DATA:
        # Check English attributes
        if (query in particle["name"].lower() or 
            query in particle["symbol"].lower() or 
            query in particle["category"].lower()):
            results.append(particle)
            continue
        
        # Check Korean attributes if available
        if "korean_name" in particle and query in particle["korean_name"].lower():
            results.append(particle)
            continue
            
        if "korean_description" in particle and query in particle["korean_description"].lower():
            results.append(particle)
            continue
    
    return results

def get_particle_color(category):
    """Get the color for a particle category"""
    colors = {
        "quark": "#FF6B6B",  # Red
        "lepton": "#48BEFF",  # Blue
        "gauge boson": "#4CAF50",  # Green
        "scalar boson": "#FFC107"  # Yellow
    }
    
    return colors.get(category.lower(), "#9C27B0")  # Default purple

def get_all_particles():
    """Get all particles as a list"""
    return PARTICLES_DATA

def get_particles_by_category(category):
    """Get particles filtered by category"""
    return [p for p in PARTICLES_DATA if p["category"].lower() == category.lower()]

def get_particles_by_generation(generation):
    """Get particles filtered by generation (for quarks and leptons)"""
    return [p for p in PARTICLES_DATA if "generation" in p and p["generation"] == generation]