import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path
import sys

# Add the current directory to sys.path to ensure relative imports work
current_dir = Path.cwd()
sys.path.append(str(current_dir))

# Set page configuration
st.set_page_config(
    page_title="Chemical Elements Explorer - Test",
    page_icon="⚗️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Create a simple test page
st.title("Chemical Elements Explorer")
st.subheader("System Test")

# Try importing some modules
try:
    from data.elements import get_all_elements
    elements = get_all_elements()
    st.success(f"Successfully imported elements data! Found {len(elements)} elements.")
    
    # Display a sample of elements
    st.subheader("Sample Elements")
    df = pd.DataFrame(elements[:10])
    st.dataframe(df[['atomic_number', 'symbol', 'name', 'korean_name', 'category']])
    
except Exception as e:
    st.error(f"Error importing elements data: {e}")

# Try importing translations
try:
    from utils.translations import get_translation, TRANSLATIONS
    st.success(f"Successfully imported translations module! Available languages: {', '.join(TRANSLATIONS.keys())}")
    
    # Display some translations
    st.subheader("Translation Examples")
    for key in ['home', 'periodic_table', 'quiz']:
        st.write(f"{key}: English='{get_translation(key, 'English')}', Korean='{get_translation(key, 'Korean')}'")
        
except Exception as e:
    st.error(f"Error importing translations module: {e}")

# Test direct import
st.subheader("Module Import Test")
try:
    import importlib.util
    
    def import_module_from_path(module_name, file_path):
        try:
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            if spec is None:
                return None, f"Could not find module {module_name} at {file_path}"
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module, None
        except Exception as e:
            return None, str(e)
    
    # Test importing home.py
    home_path = Path.cwd() / "pages" / "home.py"
    st.write(f"Testing import from: {home_path}")
    module, error = import_module_from_path("home_test", home_path)
    
    if module:
        st.success("Successfully imported home module!")
        st.write("Module has the following attributes:", ", ".join(dir(module)[:10]) + "...")
    else:
        st.error(f"Failed to import home module: {error}")
        
except Exception as e:
    st.error(f"Error in module import test: {e}")

# Display file system paths
st.subheader("System Paths")
st.write("Current working directory:", Path.cwd())
st.write("sys.path:", sys.path)

# Check if important files exist
st.subheader("File System Check")
files_to_check = [
    "app.py",
    "app_simple.py",
    "pages/home.py",
    "pages/element_details.py",
    "pages/quiz_new.py",
    "pages/periodic_table.py",
    "pages/quiz_history.py",
    "utils/translations.py",
    "utils/periodic_table.py",
    "utils/quiz.py"
]

for file_path in files_to_check:
    full_path = Path.cwd() / file_path
    if full_path.exists():
        st.success(f"✅ File exists: {file_path}")
    else:
        st.error(f"❌ File missing: {file_path}")