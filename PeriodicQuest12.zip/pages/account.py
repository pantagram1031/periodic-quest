"""
Account management module for the Science Learning Platform.
This module handles user login, registration, and account management.
"""
import streamlit as st
import datetime
from utils.translations import get_translation
from utils.user_auth import (
    register_user, 
    authenticate_user, 
    is_logged_in, 
    get_current_user,
    get_current_user_display_name,
    get_user_data,
    update_user_data,
    get_quiz_history,
    get_quiz_stats,
    logout,
    update_user_profile,
    update_user_settings
)

def render():
    """Render the account page"""
    st.title(get_translation("account_management"))
    
    # Check if user is logged in
    if is_logged_in():
        _render_account_page()
    else:
        _render_login_page()

def _render_login_page():
    """Render the login and registration forms"""
    tab1, tab2 = st.tabs([get_translation("login"), get_translation("register")])
    
    # Login form
    with tab1:
        st.subheader(get_translation("login_to_your_account"))
        
        with st.form("login_form"):
            username = st.text_input(get_translation("username"))
            password = st.text_input(get_translation("password"), type="password")
            submit_button = st.form_submit_button(get_translation("login"))
            
            if submit_button:
                if not username or not password:
                    st.error(get_translation("please_fill_all_fields"))
                else:
                    success, message = authenticate_user(username, password)
                    if success:
                        st.session_state.username = username
                        user_data = get_user_data(username)
                        st.session_state.user_id = user_data.get("user_id")
                        
                        # Set language preference if available
                        if "settings" in user_data and "language" in user_data["settings"]:
                            st.session_state.language = user_data["settings"]["language"]
                        
                        st.success(message)
                        # Rerun to refresh page and show account info
                        st.rerun()
                    else:
                        st.error(message)
    
    # Registration form
    with tab2:
        st.subheader(get_translation("create_account"))
        
        with st.form("register_form"):
            new_username = st.text_input(get_translation("username"))
            display_name = st.text_input(get_translation("display_name"), help=get_translation("display_name_help"))
            new_password = st.text_input(get_translation("password"), type="password")
            confirm_password = st.text_input(get_translation("confirm_password"), type="password")
            
            submit_button = st.form_submit_button(get_translation("register"))
            
            if submit_button:
                if not new_username or not new_password or not confirm_password:
                    st.error(get_translation("please_fill_required_fields"))
                elif new_password != confirm_password:
                    st.error(get_translation("passwords_dont_match"))
                else:
                    success, message = register_user(new_username, new_password, display_name)
                    if success:
                        st.success(message)
                        st.info(get_translation("please_login"))
                    else:
                        st.error(message)

def _render_account_page():
    """Render the account management page for logged in users"""
    username = get_current_user()
    display_name = get_current_user_display_name()
    user_data = get_user_data(username)
    
    st.header(f"{get_translation('welcome')}, {display_name}!")
    
    # Account tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        get_translation("profile"), 
        get_translation("quiz_history"),
        get_translation("custom_quizzes", "Custom Quizzes"),
        get_translation("settings")
    ])
    
    # Profile tab
    with tab1:
        st.subheader(get_translation("account_info"))
        
        # Basic info
        col1, col2 = st.columns([2, 1])
        with col1:
            created_at = datetime.datetime.fromisoformat(user_data["created_at"])
            st.write(f"**{get_translation('username')}:** {username}")
            st.write(f"**{get_translation('display_name')}:** {display_name}")
            st.write(f"**{get_translation('account_created')}:** {created_at.strftime('%Y-%m-%d')}")
            
            if user_data["last_login"]:
                last_login = datetime.datetime.fromisoformat(user_data["last_login"])
                st.write(f"**{get_translation('last_login')}:** {last_login.strftime('%Y-%m-%d %H:%M')}")
        
        with col2:
            # Profile picture placeholder
            st.image("https://via.placeholder.com/150", width=150)
            if st.button("Change Profile Picture"):
                st.info("Profile picture upload coming soon!")
        
        # Profile editing
        st.subheader("Edit Profile")
        with st.form("profile_edit_form"):
            new_display_name = st.text_input(
                "Display Name",
                value=user_data.get("display_name", ""),
                help="Your preferred name to display in the app"
            )
            
            bio = st.text_area(
                "Bio",
                value=user_data.get("profile", {}).get("bio", ""),
                help="Tell us about yourself"
            )
            
            education_level = st.selectbox(
                "Education Level",
                options=["", "High School", "Undergraduate", "Graduate", "Professional"],
                index=["", "High School", "Undergraduate", "Graduate", "Professional"].index(
                    user_data.get("profile", {}).get("education_level", "")
                )
            )
            
            interests = st.multiselect(
                "Interests",
                options=["Chemistry", "Physics", "Biology", "Astronomy", "Mathematics", "Computer Science"],
                default=user_data.get("profile", {}).get("interests", [])
            )
            
            if st.form_submit_button("Update Profile"):
                profile_data = {
                    "display_name": new_display_name,
                    "profile": {
                        "bio": bio,
                        "education_level": education_level,
                        "interests": interests
                    }
                }
                
                if update_user_profile(username, profile_data):
                    st.success("Profile updated successfully!")
                    st.rerun()
                else:
                    st.error("Failed to update profile")
        
        # Quiz statistics summary
        st.subheader(get_translation("quiz_statistics"))
        stats = get_quiz_stats(username)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric(get_translation("total_quizzes"), stats["total_quizzes"])
        with col2:
            st.metric(get_translation("total_questions"), stats["total_questions"])
        with col3:
            st.metric(get_translation("accuracy"), f"{stats['accuracy']:.1f}%")
    
    # Quiz History tab
    with tab2:
        st.subheader(get_translation("quiz_history"))
        
        quiz_history = get_quiz_history(username)
        if not quiz_history:
            st.info(get_translation("no_quiz_history"))
        else:
            for quiz in quiz_history:
                with st.expander(f"{quiz['topic']} - {quiz['date']}"):
                    st.write(f"**Score:** {quiz['score']}%")
                    st.write(f"**Questions:** {quiz['total_questions']}")
                    st.write(f"**Time:** {quiz['time_taken']} seconds")
    
    # Custom Quizzes tab
    with tab3:
        st.subheader(get_translation("custom_quizzes"))
        st.info("Custom quiz creation coming soon!")
    
    # Settings tab
    with tab4:
        st.subheader(get_translation("user_settings"))
        
        with st.form("settings_form"):
            # Language setting
            language_options = ["English", "한국어"]
            current_language = user_data.get("settings", {}).get("language", "English")
            
            language = st.selectbox(
                get_translation("language_setting"),
                options=language_options,
                index=language_options.index(current_language)
            )
            
            # Theme setting
            theme_options = ["light", "dark"]
            current_theme = user_data.get("settings", {}).get("theme", "light")
            
            theme = st.selectbox(
                "Theme",
                options=theme_options,
                index=theme_options.index(current_theme)
            )
            
            # Notification settings
            st.subheader("Notifications")
            notifications = st.checkbox(
                "Enable Notifications",
                value=user_data.get("settings", {}).get("notifications", True)
            )
            
            email_notifications = st.checkbox(
                "Email Notifications",
                value=user_data.get("settings", {}).get("email_notifications", False)
            )
            
            if st.form_submit_button("Save Settings"):
                settings_data = {
                    "language": language,
                    "theme": theme,
                    "notifications": notifications,
                    "email_notifications": email_notifications
                }
                
                if update_user_settings(username, settings_data):
                    st.success("Settings updated successfully!")
                    st.rerun()
                else:
                    st.error("Failed to update settings")
        
        # Logout button
        st.subheader(get_translation("logout"))
        if st.button(get_translation("logout_button")):
            logout()
            st.success(get_translation("logout_success"))
            st.rerun()