"""
Custom Learning Home module for the Science Learning Platform.
This module serves as the main entry point for the Custom Learning section,
providing a Universal Topic Selector and access to custom topics.
"""
import streamlit as st
import os
import json
from typing import Dict, List, Any, Optional

from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.topic_builder import (
    get_all_topics, get_user_topics, load_topic, CUSTOM_TOPICS_DIR
)

def render():
    """Render the Custom Learning home page with introduction to custom learning"""
    st.title("📚 Welcome to Custom Learning!")
    
    # Introduction section with enhanced explanations
    st.markdown("""
    ### What is Custom Learning?
    
    Custom Learning is our powerful feature that transforms how you interact with educational content. Unlike traditional learning platforms, Custom Learning gives you complete control to create, explore, and share your own educational topics on any subject you're passionate about.
    
    ### How Custom Learning Works:
    
    1. **Create Topics**: Start by creating a new topic - like "Ancient Civilizations," "Programming Languages," or anything else that interests you.
    
    2. **Define Your Data Structure**: Just like the Periodic Table organizes elements with properties (atomic number, symbol, etc.), you decide what properties your topic's entities should have.
    
    3. **Add Your Content**: Fill your topic with entities and their details. For example, if your topic is "World Cuisines," each entity might be a different cuisine with properties like region, key ingredients, and famous dishes.
    
    4. **Explore & Learn**: Navigate your content through the same intuitive interface used for our science topics, with specialized views for your custom data.
    
    5. **Test Your Knowledge**: Generate custom quizzes based on the properties you've defined to reinforce learning.
    
    6. **Share Your Knowledge**: Export your topics to share with friends, classmates, or the community.
    
    ### Key Benefits:
    
    - **Flexibility**: Create topics on absolutely any subject
    - **Personalization**: Customize how information is structured and presented
    - **Interactive Learning**: Dynamic exploration and quiz systems adapted to your content
    - **Knowledge Sharing**: Build a community around topics you care about
    
    ### Getting Started:
    
    * Use the **Topic Viewer** tab in the sidebar to browse existing topics
    * Click **Create Custom Topic** and choose between:
      * **Preset Template** - Use a predefined template with standard aspects
      * **Custom Template** - Create a topic from scratch with your own structure
    * Once you've created a topic, use the **Custom Entity/Quiz Editor** to:
      * Add aspects (properties) for your topic
      * Create entities using the grid interface
      * Configure quiz settings with custom bait options
    * Try the **Universal Quiz** to test knowledge on your custom topics
    """)
    
    # Add a separator
    st.divider()
    
    # Quick Start section
    st.header("Quick Start Guide")
    
    # Create three columns for the main actions
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("### 🔎 View Topics")
        st.markdown("Explore existing custom topics from the community.")
        if st.button("Go to Topic Viewer", use_container_width=True, key="goto_topic_viewer"):
            st.session_state.active_sidebar_tab = "Custom Topic Viewing"
            st.rerun()
    
    with col2:
        st.markdown("### ✏️ Create Topic")
        st.markdown("Choose a template or start from scratch.")
        if st.button("Create New Topic", use_container_width=True, key="create_new_topic", type="primary"):
            st.session_state.page = "custom_topic_selector"
            st.rerun()
    
    with col3:
        st.markdown("### 🧩 Edit & Build")
        st.markdown("Use the grid editor to manage entities and quizzes.")
        if st.button("Go to Entity/Quiz Editor", use_container_width=True, key="goto_entity_editor"):
            st.session_state.page = "topic_grid_editor"
            st.rerun()
            
    # Add some space
    st.write("")
    st.write("")
    
    # Featured Topics - Show a sample of topics
    st.header("Featured Topics")
    
    # Get all topics from the system
    all_topics = get_all_topics()
    
    if not all_topics:
        # No topics available yet
        st.info("No custom topics available yet. Be the first to create a topic!")
    else:
        # Sort topics by creation date or number of entities
        all_topics.sort(key=lambda x: x.get("entity_count", 0), reverse=True)
        featured_topics = all_topics[:min(3, len(all_topics))]
        
        # Display featured topics in a row
        cols = st.columns(min(3, len(featured_topics)))
        
        for i, topic in enumerate(featured_topics):
            with cols[i]:
                st.markdown(f"### {topic.get('icon', '📚')} {topic.get('title', 'Untitled Topic')}")
                st.markdown(f"{topic.get('description', 'No description')[:100]}...")
                st.markdown(f"**Entities:** {topic.get('entity_count', 0)}")
                
                # Add button to view the topic
                if st.button("View Topic", key=f"view_featured_{topic.get('id')}", use_container_width=True):
                    # Navigate to the topic viewer
                    st.session_state.selected_topic_id = topic.get("id")
                    st.session_state.active_sidebar_tab = "Custom Topic Viewing"
                    st.session_state.page = "custom_topic_explorer"
                    st.rerun()

# Keep these functions commented out but preserved in code for future reference
"""
def render_universal_topic_selector():
    # This function has been replaced with a more simplified home screen
    pass

def render_my_topics():
    # This function has been replaced with a more simplified home screen
    pass

def render_featured_topics():
    # This function has been replaced with a more simplified home screen
    pass
"""