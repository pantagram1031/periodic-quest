"""
Custom topic viewer module for the Science Learning Platform.
This module renders a custom topic created by users.
"""
import streamlit as st
import json
import os
import datetime
import uuid
import pandas as pd
import plotly.express as px
from typing import Dict, List, Any, Optional

from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.topic_builder import (
    load_topic, get_all_topics, get_user_topics, search_entities,
    generate_quiz_questions, CUSTOM_TOPICS_DIR
)

def render():
    """Render the custom topic viewer page"""
    # Check if we have a topic ID in the session state
    topic_id = st.session_state.get("custom_topic_id")
    if not topic_id:
        st.warning(get_translation("no_topic_selected", "No topic selected. Please select a topic to view."))
        
        # Add a button to go back to the topic builder
        if st.button(get_translation("back_to_builder", "Back to Topic Builder"), use_container_width=True):
            st.session_state.page = "topic_builder"
            st.rerun()
        return
    
    # Load the topic
    topic = load_topic(topic_id)
    if not topic:
        st.error(get_translation("topic_not_found", "Topic not found."))
        
        # Add a button to go back to the topic builder
        if st.button(get_translation("back_to_builder", "Back to Topic Builder"), use_container_width=True):
            st.session_state.page = "topic_builder"
            st.rerun()
        return
    
    # Display the topic title and description
    st.title(f"{topic.get('icon', '📚')} {topic.get('title', 'Unnamed Topic')}")
    st.markdown(topic.get("description", ""))
    
    # Add metadata about the topic
    col1, col2 = st.columns(2)
    
    with col1:
        # Format dates if available
        created_at = topic.get("created_at", "")
        if created_at:
            try:
                created_date = datetime.fromisoformat(created_at).strftime("%Y-%m-%d")
                st.caption(f"{get_translation('created', 'Created')}: {created_date}")
            except:
                st.caption(f"{get_translation('created', 'Created')}: {created_at}")
    
    with col2:
        # Show the creator's username
        creator = topic.get("created_by", "")
        if creator:
            st.caption(f"{get_translation('created_by', 'Created by')}: {creator}")
    
    # Add a back button
    if st.button(get_translation("back_to_builder", "Back to Topic Builder"), use_container_width=True):
        st.session_state.page = "topic_builder"
        st.rerun()
    
    # Tab for entities and quiz
    tab1, tab2 = st.tabs([
        f"📋 {topic.get('entity_name_plural', 'Items')}",
        "❓ " + get_translation("quiz", "Quiz")
    ])
    
    with tab1:
        render_entities_view(topic)
    
    with tab2:
        render_quiz_view(topic)

def render_entities_view(topic):
    """Render the entities view section"""
    entity_name_plural = topic.get("entity_name_plural", "Items")
    
    st.header(entity_name_plural)
    
    # Add a search box
    search_query = st.text_input(
        get_translation("search", "Search"),
        placeholder=f"{get_translation('search', 'Search')} {entity_name_plural.lower()}..."
    )
    
    entities = topic.get("entities", [])
    
    # If search query is provided, filter entities
    if search_query:
        filtered_entities = search_entities(topic["id"], search_query)
        if filtered_entities:
            st.write(f"🔍 {get_translation('found', 'Found')} {len(filtered_entities)} {entity_name_plural.lower()}")
            entities = filtered_entities
        else:
            st.info(f"{get_translation('no_matches', 'No matches found for')} '{search_query}'")
    
    # Show total count
    st.caption(f"{get_translation('total', 'Total')}: {len(entities)} {entity_name_plural.lower()}")
    
    # Display options
    display_mode = st.radio(
        get_translation("view_mode", "View Mode"),
        options=["card", "table"],
        format_func=lambda x: {
            "card": get_translation("card_view", "Card View"),
            "table": get_translation("table_view", "Table View")
        }[x],
        horizontal=True
    )
    
    if display_mode == "card":
        render_card_view(topic, entities)
    else:
        render_table_view(topic, entities)

def render_card_view(topic, entities):
    """Render entities in a card view"""
    if not entities:
        st.info(get_translation("no_entities", "No entities found."))
        return
    
    # Determine how many cards per row based on screen size
    # Use 3 columns on larger screens, 2 on smaller ones
    use_wide_layout = st.checkbox(get_translation("wide_layout", "Wide Layout"), value=True)
    cards_per_row = 3 if use_wide_layout else 2
    
    # Get properties to display in cards
    properties = topic.get("properties", [])
    name_prop = next((p for p in properties if p["id"] == "name"), None)
    symbol_prop = next((p for p in properties if p["id"] == "symbol"), None)
    description_prop = next((p for p in properties if p["id"] == "description"), None)
    
    # Create rows of cards
    for i in range(0, len(entities), cards_per_row):
        cols = st.columns(cards_per_row)
        
        for j in range(cards_per_row):
            idx = i + j
            if idx < len(entities):
                entity = entities[idx]
                
                with cols[j]:
                    with st.container(border=True):
                        # Display entity name and symbol
                        if name_prop and symbol_prop:
                            name = entity.get(name_prop["id"], "")
                            symbol = entity.get(symbol_prop["id"], "")
                            st.markdown(f"### {name} ({symbol})")
                        elif name_prop:
                            name = entity.get(name_prop["id"], "")
                            st.markdown(f"### {name}")
                        elif symbol_prop:
                            symbol = entity.get(symbol_prop["id"], "")
                            st.markdown(f"### {symbol}")
                        else:
                            st.markdown(f"### {get_translation('unnamed_entity', 'Unnamed Entity')}")
                        
                        # Display a short description
                        if description_prop:
                            desc = entity.get(description_prop["id"], "")
                            if len(desc) > 150:
                                st.markdown(f"{desc[:150]}...")
                            else:
                                st.markdown(desc)
                        
                        # Add a button to view details
                        if st.button(get_translation("view_details", "View Details"), key=f"view_{entity.get('id')}", use_container_width=True):
                            st.session_state.selected_entity_id = entity.get("id")
                            st.rerun()
    
    # If an entity is selected, show its details
    if "selected_entity_id" in st.session_state and st.session_state.selected_entity_id:
        selected_id = st.session_state.selected_entity_id
        selected_entity = next((e for e in entities if e.get("id") == selected_id), None)
        
        if selected_entity:
            with st.expander(get_translation("entity_details", "Entity Details"), expanded=True):
                # Close button
                if st.button(get_translation("close", "Close"), use_container_width=True):
                    st.session_state.selected_entity_id = None
                    st.rerun()
                
                # Display entity properties
                for prop in properties:
                    prop_id = prop["id"]
                    prop_name = prop["name"]
                    prop_type = prop["type"]
                    
                    if prop_id in selected_entity:
                        value = selected_entity[prop_id]
                        
                        # Display differently based on property type
                        if prop_type == "text":
                            st.write(f"**{prop_name}:** {value}")
                        elif prop_type == "text_long":
                            st.write(f"**{prop_name}:**")
                            st.markdown(value)
                        elif prop_type == "number":
                            st.write(f"**{prop_name}:** {value}")
                        elif prop_type == "boolean":
                            st.write(f"**{prop_name}:** {'Yes' if value else 'No'}")
                        elif prop_type == "image_url":
                            st.write(f"**{prop_name}:**")
                            try:
                                st.image(value, use_column_width=True)
                            except:
                                st.error(f"{get_translation('image_not_available', 'Image not available')}: {value}")

def render_table_view(topic, entities):
    """Render entities in a table view"""
    if not entities:
        st.info(get_translation("no_entities", "No entities found."))
        return
    
    # Create a dataframe from the entities
    df_data = []
    
    # Get the properties to display
    properties = topic.get("properties", [])
    display_props = [p for p in properties if p["type"] not in ["text_long", "image_url"]]
    
    for entity in entities:
        row = {}
        for prop in display_props:
            prop_id = prop["id"]
            prop_name = prop["name"]
            
            if prop_id in entity:
                row[prop_name] = entity[prop_id]
            else:
                row[prop_name] = ""
        
        df_data.append(row)
    
    # Create the dataframe
    df = pd.DataFrame(df_data)
    
    # Add interactive elements to the table
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True
    )
    
    # Add an option to select a row for details
    if not df.empty:
        # Get the "name" column if it exists, otherwise use the first column
        if "Name" in df.columns:
            options = df["Name"].tolist()
            option_col = "Name"
        else:
            options = df.iloc[:, 0].tolist()
            option_col = df.columns[0]
        
        selected_item = st.selectbox(
            get_translation("select_for_details", "Select an item to view details"),
            options=options
        )
        
        if selected_item:
            # Find the selected entity
            selected_entity = None
            for entity in entities:
                # Match based on the displayed column
                for prop in properties:
                    if prop["name"] == option_col and prop["id"] in entity:
                        if entity[prop["id"]] == selected_item:
                            selected_entity = entity
                            break
                
                if selected_entity:
                    break
            
            if selected_entity:
                with st.expander(get_translation("entity_details", "Entity Details"), expanded=True):
                    # Display entity properties
                    for prop in properties:
                        prop_id = prop["id"]
                        prop_name = prop["name"]
                        prop_type = prop["type"]
                        
                        if prop_id in selected_entity:
                            value = selected_entity[prop_id]
                            
                            # Display differently based on property type
                            if prop_type == "text":
                                st.write(f"**{prop_name}:** {value}")
                            elif prop_type == "text_long":
                                st.write(f"**{prop_name}:**")
                                st.markdown(value)
                            elif prop_type == "number":
                                st.write(f"**{prop_name}:** {value}")
                            elif prop_type == "boolean":
                                st.write(f"**{prop_name}:** {'Yes' if value else 'No'}")
                            elif prop_type == "image_url":
                                st.write(f"**{prop_name}:**")
                                try:
                                    st.image(value, use_column_width=True)
                                except:
                                    st.error(f"{get_translation('image_not_available', 'Image not available')}: {value}")

def render_quiz_view(topic):
    """Render the quiz view section"""
    st.header(get_translation("quiz", "Quiz"))
    
    entity_name_plural = topic.get("entity_name_plural", "Items")
    
    # Initialize quiz state if needed
    if "custom_quiz_questions" not in st.session_state:
        st.session_state.custom_quiz_questions = []
    if "custom_quiz_current" not in st.session_state:
        st.session_state.custom_quiz_current = 0
    if "custom_quiz_answers" not in st.session_state:
        st.session_state.custom_quiz_answers = {}
    if "custom_quiz_mode" not in st.session_state:
        st.session_state.custom_quiz_mode = "start"  # 'start', 'quiz', 'results'
    
    # Quiz start screen
    if st.session_state.custom_quiz_mode == "start":
        st.markdown(get_translation("quiz_intro", 
                                  f"Test your knowledge of {topic.get('title')} with a quiz!"))
        
        # Quiz settings
        col1, col2 = st.columns(2)
        
        with col1:
            num_questions = st.slider(
                get_translation("number_of_questions", "Number of Questions"),
                min_value=1,
                max_value=20,
                value=5
            )
        
        with col2:
            difficulty = st.selectbox(
                get_translation("difficulty", "Difficulty"),
                options=["easy", "medium", "hard"],
                index=1,
                format_func=lambda x: x.capitalize()
            )
        
        # Quiz type
        quiz_type = st.radio(
            get_translation("quiz_type", "Quiz Type"),
            options=["multiple_choice", "text_input"],
            horizontal=True,
            format_func=lambda x: {
                "multiple_choice": get_translation("multiple_choice", "Multiple Choice"),
                "text_input": get_translation("text_input", "Text Input")
            }[x]
        )
        
        # Start quiz button
        if st.button(get_translation("start_quiz", "Start Quiz"), use_container_width=True):
            # Generate questions
            questions = generate_quiz_questions(topic["id"], num_questions, difficulty)
            
            # Filter questions by type if needed
            if quiz_type == "multiple_choice":
                questions = [q for q in questions if q.get("question_type") == "multiple_choice"]
            elif quiz_type == "text_input":
                questions = [q for q in questions if q.get("question_type") == "text_input"]
            
            # Make sure we have questions
            if not questions:
                st.error(get_translation("no_questions_generated", 
                                       f"No {quiz_type.replace('_', ' ')} questions could be generated. Try changing the quiz type or adding more entities."))
                return
            
            # Store questions and reset state
            st.session_state.custom_quiz_questions = questions
            st.session_state.custom_quiz_current = 0
            st.session_state.custom_quiz_answers = {}
            st.session_state.custom_quiz_mode = "quiz"
            st.rerun()
    
    # Quiz taking screen
    elif st.session_state.custom_quiz_mode == "quiz":
        questions = st.session_state.custom_quiz_questions
        current = st.session_state.custom_quiz_current
        
        if not questions:
            st.error(get_translation("no_questions", "No questions available."))
            st.session_state.custom_quiz_mode = "start"
            st.rerun()
            return
        
        # Show progress
        progress = (current + 1) / len(questions)
        st.progress(progress, text=f"{get_translation('question', 'Question')} {current + 1}/{len(questions)}")
        
        # Display current question
        question = questions[current]
        question_text = question.get("question_text", "")
        question_type = question.get("question_type", "multiple_choice")
        
        st.markdown(f"### {question_text}")
        
        # Get user answer
        user_answer = None
        if question_type == "multiple_choice":
            options = question.get("options", [])
            user_answer = st.radio(
                get_translation("select_answer", "Select your answer"),
                options=options,
                key=f"quiz_{current}"
            )
        else:  # text_input
            user_answer = st.text_input(
                get_translation("your_answer", "Your answer"),
                key=f"quiz_{current}"
            )
        
        # Navigation buttons
        col1, col2, col3 = st.columns([1, 1, 2])
        
        with col1:
            # Previous button
            prev_disabled = current == 0
            if st.button(get_translation("previous", "Previous"), disabled=prev_disabled, use_container_width=True):
                # Save the current answer
                st.session_state.custom_quiz_answers[current] = user_answer
                # Go to previous question
                st.session_state.custom_quiz_current = current - 1
                st.rerun()
        
        with col2:
            # Next button
            next_disabled = current == len(questions) - 1
            next_label = get_translation("next", "Next") if next_disabled else get_translation("next", "Next")
            if st.button(next_label, disabled=next_disabled, use_container_width=True):
                # Save the current answer
                st.session_state.custom_quiz_answers[current] = user_answer
                # Go to next question
                st.session_state.custom_quiz_current = current + 1
                st.rerun()
        
        with col3:
            # Submit button
            if st.button(get_translation("submit_quiz", "Submit Quiz"), use_container_width=True):
                # Save the current answer
                st.session_state.custom_quiz_answers[current] = user_answer
                # Show results
                st.session_state.custom_quiz_mode = "results"
                st.rerun()
    
    # Quiz results screen
    elif st.session_state.custom_quiz_mode == "results":
        questions = st.session_state.custom_quiz_questions
        answers = st.session_state.custom_quiz_answers
        
        if not questions:
            st.error(get_translation("no_questions", "No questions available."))
            st.session_state.custom_quiz_mode = "start"
            st.rerun()
            return
        
        # Calculate score
        score = 0
        for i, question in enumerate(questions):
            user_answer = answers.get(i, "")
            correct_answer = question.get("correct_answer", "")
            
            # For text input, normalize answers for comparison
            if question.get("question_type") == "text_input":
                user_answer = str(user_answer).strip().lower()
                correct_answer = str(correct_answer).strip().lower()
            
            if user_answer == correct_answer:
                score += 1
        
        # Display score
        percentage = (score / len(questions)) * 100
        st.subheader(get_translation("quiz_results", "Quiz Results"))
        
        # Create metrics for the score
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric(get_translation("score", "Score"), f"{score}/{len(questions)}")
        
        with col2:
            st.metric(get_translation("percentage", "Percentage"), f"{percentage:.1f}%")
        
        with col3:
            # Give a grade based on percentage
            grade = "A+" if percentage >= 95 else "A" if percentage >= 90 else "B+" if percentage >= 85 else "B" if percentage >= 80 else "C+" if percentage >= 75 else "C" if percentage >= 70 else "D+" if percentage >= 65 else "D" if percentage >= 60 else "F"
            st.metric(get_translation("grade", "Grade"), grade)
        
        # Display all questions and answers
        st.subheader(get_translation("answers", "Answers"))
        
        for i, question in enumerate(questions):
            user_answer = answers.get(i, "")
            correct_answer = question.get("correct_answer", "")
            
            # For text input, normalize answers for comparison
            if question.get("question_type") == "text_input":
                user_answer_normalized = str(user_answer).strip().lower()
                correct_answer_normalized = str(correct_answer).strip().lower()
                is_correct = user_answer_normalized == correct_answer_normalized
            else:
                is_correct = user_answer == correct_answer
            
            # Create an expandable section for each question
            with st.expander(f"{get_translation('question', 'Question')} {i+1}: {'✅' if is_correct else '❌'}", expanded=(i == 0)):
                st.markdown(f"**{question.get('question_text', '')}**")
                
                if question.get("question_type") == "multiple_choice":
                    st.write(f"{get_translation('options', 'Options')}:")
                    for option in question.get("options", []):
                        prefix = "✅" if option == correct_answer else "❌" if option == user_answer and not is_correct else ""
                        st.write(f"{prefix} {option}")
                
                st.write(f"{get_translation('your_answer', 'Your answer')}: {user_answer} {'✅' if is_correct else '❌'}")
                st.write(f"{get_translation('correct_answer', 'Correct answer')}: {correct_answer}")
                
                if "explanation" in question and question["explanation"]:
                    st.write(f"{get_translation('explanation', 'Explanation')}: {question['explanation']}")
        
        # Buttons to take another quiz or go back
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button(get_translation("take_another_quiz", "Take Another Quiz"), use_container_width=True):
                st.session_state.custom_quiz_mode = "start"
                st.rerun()
        
        with col2:
            if st.button(get_translation("back_to_topic", "Back to Topic"), use_container_width=True):
                # Just stay on the current page, but reset quiz state
                st.session_state.custom_quiz_mode = "start"
                st.rerun()