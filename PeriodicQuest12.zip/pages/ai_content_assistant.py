"""
AI Content Assistant module for the Science Learning Platform.
This module provides an interface to generate custom learning content and quizzes 
using OpenAI's GPT models.
"""
import streamlit as st
import json
import datetime
import uuid
import os
from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.custom_content import (
    create_custom_topic, create_custom_quiz, add_content_section, 
    add_quiz_question, get_custom_topics, get_custom_quizzes
)
from utils.ai_helper import (
    has_api_key, generate_topic_ideas, generate_content_section,
    generate_quiz_questions, improve_quiz_question, chat_with_ai_helper
)

def render():
    """Render the AI Content Assistant page"""
    st.title("🤖 " + get_translation("ai_content_assistant"))
    
    # Check if user is logged in - only logged-in users can create custom content
    if not is_logged_in():
        st.warning(get_translation("login_required_ai_content"))
        
        # Add a button to go to the login page
        if st.button(get_translation("go_to_login"), use_container_width=True):
            st.session_state.page = "login"
            st.rerun()
        return
    
    # Check if OpenAI API key is available
    if not has_api_key():
        st.error(get_translation("openai_api_key_required"))
        
        # Add API key input
        with st.form("openai_api_key_form"):
            api_key = st.text_input("OpenAI API Key", type="password", 
                                    help="Your key will be stored as an environment variable and not saved permanently.")
            submit_button = st.form_submit_button("Save API Key")
            
            if submit_button and api_key:
                os.environ["OPENAI_API_KEY"] = api_key
                st.success(get_translation("ai_api_key_saved"))
                st.rerun()
        
        st.info(get_translation("ai_api_key_help") + " [OpenAI](https://platform.openai.com/signup)")
        return
    
    # Initialize session state for this page
    if "ai_chat_messages" not in st.session_state:
        st.session_state.ai_chat_messages = []
    if "current_generated_content" not in st.session_state:
        st.session_state.current_generated_content = None
    if "current_generated_questions" not in st.session_state:
        st.session_state.current_generated_questions = None
    
    # Create tabs for different content generation features
    tab1, tab2, tab3, tab4 = st.tabs([
        "💡 Topic Generator",
        "📝 Content Creator",
        "❓ Quiz Builder",
        "💬 AI Chat Helper"
    ])
    
    with tab1:
        _render_topic_generator()
    
    with tab2:
        _render_content_creator()
    
    with tab3:
        _render_quiz_builder()
    
    with tab4:
        _render_ai_chat()

def _render_topic_generator():
    """Render the topic generator interface"""
    st.header("💡 Topic Generator")
    st.markdown("Generate custom topic ideas based on a subject of your interest.")
    
    with st.form("topic_generator_form"):
        subject = st.text_input("Subject", placeholder="e.g., Quantum Physics, Climate Science, Organic Chemistry")
        num_ideas = st.slider("Number of Ideas", min_value=1, max_value=10, value=5)
        generate_button = st.form_submit_button("Generate Topic Ideas")
        
        if generate_button and subject:
            with st.spinner("Generating topic ideas..."):
                topic_ideas = generate_topic_ideas(subject, num_ideas)
                
                if "error" in topic_ideas[0]:
                    st.error(topic_ideas[0]["error"])
                else:
                    st.session_state.generated_topic_ideas = topic_ideas
                    st.success(f"Generated {len(topic_ideas)} topic ideas!")
    
    # Display generated ideas
    if "generated_topic_ideas" in st.session_state and st.session_state.generated_topic_ideas:
        st.subheader("Generated Topic Ideas")
        
        for i, idea in enumerate(st.session_state.generated_topic_ideas):
            with st.expander(f"{idea.get('icon', '📚')} {idea.get('title', 'Topic Idea')}"):
                st.write(idea.get("description", ""))
                
                # Create topic button
                if st.button("Create This Topic", key=f"create_topic_{i}"):
                    username = get_current_user()
                    
                    # Create the topic
                    created_topic = create_custom_topic(
                        title=idea.get("title", "New Topic"),
                        description=idea.get("description", ""),
                        icon=idea.get("icon", "📚"),
                        created_by=username
                    )
                    
                    if created_topic:
                        st.success("Topic created successfully! Now you can add content to it.")
                        st.session_state.current_topic_id = created_topic["id"]
                        # Switch to content creator tab
                        st.session_state.ai_assistant_tab = 1  # Index of content creator tab
                        st.rerun()
                    else:
                        st.error("Failed to create topic.")

def _render_content_creator():
    """Render the content creator interface"""
    st.header("📝 Content Creator")
    st.markdown("Generate educational content for your custom topics.")
    
    # Get user's custom topics
    topics = get_custom_topics()
    
    if not topics:
        st.info("You haven't created any custom topics yet. Use the Topic Generator tab to create one!")
        return
    
    # Select a topic
    topic_options = [f"{topic['icon']} {topic['title']}" for topic in topics]
    selected_topic_display = st.selectbox(
        "Select a Topic",
        options=topic_options
    )
    
    # Extract selected topic
    selected_topic_index = topic_options.index(selected_topic_display)
    selected_topic = topics[selected_topic_index]
    
    st.write(f"**Description:** {selected_topic['description']}")
    
    # Section type selection
    st.subheader("Add Content Section")
    section_type = st.selectbox(
        "Content Type",
        options=["Text", "Chart Data"],
        format_func=lambda x: {"Text": "Text Section", "Chart Data": "Chart/Visualization Data"}[x]
    )
    
    # Generate content button
    if st.button("Generate Content", key="generate_content_btn"):
        with st.spinner("Generating content..."):
            if section_type == "Text":
                content = generate_content_section(selected_topic['title'], "text")
            else:
                content = generate_content_section(selected_topic['title'], "chart_data")
            
            if "error" in content:
                st.error(content["error"])
            else:
                st.session_state.current_generated_content = content
                st.success("Content generated!")
    
    # Display and edit generated content
    if "current_generated_content" in st.session_state and st.session_state.current_generated_content:
        content = st.session_state.current_generated_content
        
        with st.form("content_editor_form"):
            st.subheader("Edit Generated Content")
            
            if section_type == "Text":
                section_title = st.text_input("Section Title", value=content.get("title", ""))
                section_content = st.text_area("Content", value=content.get("content", ""), height=300)
                
                save_button = st.form_submit_button("Add to Topic")
                
                if save_button:
                    # Add content section to topic
                    updated_topic = add_content_section(
                        topic_id=selected_topic['id'],
                        title=section_title,
                        content_type="text",
                        content_data={"text": section_content}
                    )
                    
                    if updated_topic:
                        st.success("Content section added to topic!")
                        st.session_state.current_generated_content = None
                        st.rerun()
                    else:
                        st.error("Failed to add content section.")
            
            elif section_type == "Chart Data":
                section_title = st.text_input("Section Title", value=content.get("title", ""))
                chart_type = st.selectbox(
                    "Chart Type",
                    options=["bar", "line", "scatter", "pie"],
                    index=["bar", "line", "scatter", "pie"].index(content.get("chart_type", "bar"))
                )
                
                x_label = st.text_input("X-Axis Label", value=content.get("x_label", ""))
                y_label = st.text_input("Y-Axis Label", value=content.get("y_label", ""))
                
                # Convert x_data and y_data to strings for editing
                x_data_str = st.text_area(
                    "X-Axis Data (comma separated)",
                    value=", ".join([str(x) for x in content.get("x_data", [])])
                )
                y_data_str = st.text_area(
                    "Y-Axis Data (comma separated)",
                    value=", ".join([str(y) for y in content.get("y_data", [])])
                )
                
                save_button = st.form_submit_button("Add to Topic")
                
                if save_button:
                    try:
                        # Parse data
                        x_data = [x.strip() for x in x_data_str.split(",")]
                        y_data = [float(y.strip()) for y in y_data_str.split(",")]
                        
                        # Add content section to topic
                        updated_topic = add_content_section(
                            topic_id=selected_topic['id'],
                            title=section_title,
                            content_type="chart",
                            content_data={
                                "chart_type": chart_type,
                                "title": section_title,
                                "x_label": x_label,
                                "y_label": y_label,
                                "x_data": x_data,
                                "y_data": y_data
                            }
                        )
                        
                        if updated_topic:
                            st.success("Chart data added to topic!")
                            st.session_state.current_generated_content = None
                            st.rerun()
                        else:
                            st.error("Failed to add chart data.")
                    except Exception as e:
                        st.error(f"Error parsing data: {str(e)}")

def _render_quiz_builder():
    """Render the quiz builder interface"""
    st.header("❓ Quiz Builder")
    st.markdown("Generate quiz questions for your custom topics.")
    
    # Get user's custom topics
    topics = get_custom_topics()
    
    if not topics:
        st.info("You haven't created any custom topics yet. Use the Topic Generator tab to create one!")
        return
    
    # Select a topic
    topic_options = [f"{topic['icon']} {topic['title']}" for topic in topics]
    selected_topic_display = st.selectbox(
        "Select a Topic",
        options=topic_options,
        key="quiz_topic_selector"
    )
    
    # Extract selected topic
    selected_topic_index = topic_options.index(selected_topic_display)
    selected_topic = topics[selected_topic_index]
    
    # Quiz settings
    col1, col2 = st.columns(2)
    
    with col1:
        difficulty = st.selectbox(
            "Difficulty",
            options=["easy", "medium", "hard"],
            format_func=lambda x: x.capitalize()
        )
    
    with col2:
        num_questions = st.slider(
            "Number of Questions",
            min_value=1,
            max_value=10,
            value=5
        )
    
    # Generate questions button
    if st.button("Generate Quiz Questions", key="generate_questions_btn"):
        with st.spinner("Generating questions..."):
            questions = generate_quiz_questions(
                selected_topic['title'],
                difficulty,
                num_questions
            )
            
            if "error" in questions[0]:
                st.error(questions[0]["error"])
            else:
                st.session_state.current_generated_questions = questions
                st.success(f"Generated {len(questions)} questions!")
    
    # Display and edit generated questions
    if "current_generated_questions" in st.session_state and st.session_state.current_generated_questions:
        questions = st.session_state.current_generated_questions
        
        with st.form("create_quiz_form"):
            st.subheader("Create New Quiz")
            
            quiz_title = st.text_input("Quiz Title", value=f"{selected_topic['title']} Quiz")
            quiz_description = st.text_area(
                "Quiz Description",
                value=f"A {difficulty} difficulty quiz about {selected_topic['title']}."
            )
            
            st.subheader("Review Questions")
            
            for i, question in enumerate(questions):
                with st.expander(f"Question {i+1}: {question.get('question_text', '')[:50]}..."):
                    st.write(f"**Question Text:** {question.get('question_text', '')}")
                    st.write(f"**Type:** {question.get('question_type', 'multiple_choice')}")
                    
                    if question.get('question_type') == "multiple_choice" and "options" in question:
                        st.write("**Options:**")
                        for option in question.get('options', []):
                            st.write(f"- {option}")
                    
                    st.write(f"**Correct Answer:** {question.get('correct_answer', '')}")
                    st.write(f"**Explanation:** {question.get('explanation', '')}")
            
            save_button = st.form_submit_button("Create Quiz")
            
            if save_button:
                username = get_current_user()
                
                # Create the quiz
                created_quiz = create_custom_quiz(
                    title=quiz_title,
                    description=quiz_description,
                    topic_id=selected_topic['id'],
                    created_by=username,
                    difficulty=difficulty
                )
                
                if created_quiz:
                    # Add questions to the quiz
                    success = True
                    for question in questions:
                        # Format question for storage
                        question_type = question.get('question_type', 'multiple_choice')
                        options = question.get('options', []) if question_type == "multiple_choice" else None
                        
                        result = add_quiz_question(
                            quiz_id=created_quiz['id'],
                            question_text=question.get('question_text', ''),
                            question_type=question_type,
                            correct_answer=question.get('correct_answer', ''),
                            options=options,
                            explanation=question.get('explanation', '')
                        )
                        
                        if not result:
                            success = False
                    
                    if success:
                        st.success("Quiz created successfully!")
                        st.session_state.current_generated_questions = None
                        
                        # Offer to take the quiz
                        st.info("You can now take the quiz from the Quiz page.")
                        if st.button("Take Quiz Now"):
                            st.session_state.active_custom_quiz_id = created_quiz['id']
                            st.session_state.page = "quiz"
                            st.session_state.quiz_tab = "start"  # Reset to start tab
                            st.rerun()
                    else:
                        st.warning("Quiz created but some questions could not be added.")
                else:
                    st.error("Failed to create quiz.")

def _render_ai_chat():
    """Render the AI chat helper interface"""
    st.header("💬 AI Chat Helper")
    st.markdown("Chat with an AI assistant to get help with your custom learning content.")
    
    # System prompt selection
    system_prompt_options = {
        "educational_content": "You are a helpful educational content creator assistant. You provide concise, accurate information suitable for students. You focus on making complex topics accessible without oversimplification.",
        "quiz_creator": "You are a quiz creation expert. You help create engaging, educational quiz questions with clear answers and helpful explanations. You ensure questions are factually accurate and appropriate for the specified difficulty level.",
        "science_explainer": "You are a science communication expert. You explain scientific concepts in clear, engaging ways for different educational levels. You use analogies and examples to make complex ideas accessible."
    }
    
    selected_prompt_key = st.selectbox(
        "Assistant Type",
        options=list(system_prompt_options.keys()),
        format_func=lambda x: {
            "educational_content": "Educational Content Creator",
            "quiz_creator": "Quiz Creation Expert",
            "science_explainer": "Science Explainer"
        }[x]
    )
    
    system_prompt = system_prompt_options[selected_prompt_key]
    
    # Display chat messages
    st.subheader("Chat")
    
    for message in st.session_state.ai_chat_messages:
        with st.chat_message(message["role"]):
            st.write(message["content"])
    
    # Chat input
    user_input = st.chat_input("Ask a question or request help...")
    
    if user_input:
        # Add user message to chat history
        st.session_state.ai_chat_messages.append({"role": "user", "content": user_input})
        
        # Display user message
        with st.chat_message("user"):
            st.write(user_input)
        
        # Get AI response
        with st.spinner("Thinking..."):
            ai_response = chat_with_ai_helper(
                st.session_state.ai_chat_messages,
                system_prompt
            )
            
            # Add AI response to chat history
            st.session_state.ai_chat_messages.append({"role": "assistant", "content": ai_response})
            
            # Display AI response
            with st.chat_message("assistant"):
                st.write(ai_response)
    
    # Clear chat button
    if st.button("Clear Chat"):
        st.session_state.ai_chat_messages = []
        st.rerun()