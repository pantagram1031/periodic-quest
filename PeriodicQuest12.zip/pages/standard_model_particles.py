"""
Particles visualization page module for the Standard Model Explorer.
"""

import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from utils.translations import get_translation, get_particle_display_name, get_particle_description
from data.standard_model.particles import get_all_particles, get_particle_by_name, search_particles, get_particle_color

def render():
    """Render the Standard Model particles visualization page"""
    
    st.header(get_translation("standard_model_title"))
    
    # Get the particles data
    all_particles = get_all_particles()
    
    # Create tabs for different views
    tab1, tab2, tab3, tab4 = st.tabs([
        get_translation("card_view"), 
        get_translation("forces_view"), 
        get_translation("table_view"), 
        get_translation("particle_search")
    ])
    
    # Tab 1: Card View
    with tab1:
        st.subheader(get_translation("explore_particles_by_category"))
        
        # Create an expandable section for each particle category
        categories = ["quark", "lepton", "gauge boson", "scalar boson"]
        
        for category in categories:
            with st.expander(f"{category.capitalize()}s", expanded=True):
                # Filter particles by category
                cat_particles = [p for p in all_particles if p["category"] == category]
                
                # Define custom sorting order for each category
                if category == "quark":
                    # Order: up-charm-top-down-strange-bottom
                    quark_order = {"Up Quark": 1, "Charm Quark": 2, "Top Quark": 3, 
                                 "Down Quark": 4, "Strange Quark": 5, "Bottom Quark": 6}
                    cat_particles.sort(key=lambda p: quark_order.get(p["name"], 99))
                    
                elif category == "lepton":
                    # Order: electron-muon-tau-electron neutrino-muon newtrino-tau newtrino
                    lepton_order = {"Electron": 1, "Muon": 2, "Tau": 3, 
                                  "Electron Neutrino": 4, "Muon Neutrino": 5, "Tau Neutrino": 6}
                    cat_particles.sort(key=lambda p: lepton_order.get(p["name"], 99))
                    
                elif category == "gauge boson":
                    # Order: gluon-photon-z-w
                    boson_order = {"Gluon": 1, "Photon": 2, "Z Boson": 3, "W Boson": 4}
                    cat_particles.sort(key=lambda p: boson_order.get(p["name"], 99))
                
                # Create a multi-column layout for the cards
                cols = st.columns(min(3, len(cat_particles)))
                
                # Display each particle as a card
                for i, particle in enumerate(cat_particles):
                    col_index = i % len(cols)
                    
                    with cols[col_index]:
                        # Get color for this category
                        color = get_particle_color(category)
                        
                        # Create a styled card
                        # Create a more polished, Wikipedia-like layout
                        
                        # Create the main card container
                        with st.container():
                            # Title with background color based on category
                            st.markdown(
                                f"""<div style="background-color: {color}; padding: 0.5rem; border-radius: 5px 5px 0 0;">
                                <h3 style="margin: 0; color: white; text-align: center;">{get_particle_display_name(particle)} ({particle['symbol']})</h3>
                                </div>""",
                                unsafe_allow_html=True
                            )
                            
                            # Main content with light background
                            with st.container():
                                st.markdown(
                                    f"""<div style="border: 1px solid {color}; border-top: none; padding: 1rem; 
                                    border-radius: 0 0 5px 5px; background-color: rgba({int(color[1:3], 16)}, 
                                    {int(color[3:5], 16)}, {int(color[5:7], 16)}, 0.05);">""",
                                    unsafe_allow_html=True
                                )
                                
                                # Two-column layout for properties
                                col1, col2 = st.columns(2)
                                
                                with col1:
                                    st.markdown(f"**Category:** {particle['category'].capitalize()}")
                                    st.markdown(f"**Charge:** {particle['charge']}")
                                    
                                    # Add generation if it exists
                                    if 'generation' in particle:
                                        st.markdown(f"**Generation:** {particle['generation']}")
                                
                                with col2:
                                    st.markdown(f"**Mass:** {particle['mass']}")
                                    st.markdown(f"**Spin:** {particle['spin']}")
                                    
                                    # Add force if it exists and is not None
                                    if 'force' in particle and particle['force'] is not None:
                                        st.markdown(f"**Force:** {particle['force']}")
                                
                                # Description section
                                st.markdown("<hr style='margin: 0.5rem 0;'>", unsafe_allow_html=True)
                                st.markdown(f"**{get_translation('description')}:**")
                                st.markdown(get_particle_description(particle))
                                
                                # Close the div for styling
                                st.markdown("</div>", unsafe_allow_html=True)
    
    # Tab 2: Forces View
    with tab2:
        st.subheader(get_translation("explore_particles_by_forces"))
        
        # Add a brief explanation of the fundamental forces
        st.markdown("""
        The Standard Model describes four fundamental forces (interactions) in the universe:
        
        - **Electromagnetic Force**: Acts between charged particles. Responsible for electricity, magnetism, and chemical reactions.
        - **Strong Force**: Binds quarks together to form protons and neutrons, and holds the atomic nucleus together.
        - **Weak Force**: Responsible for radioactive decay and nuclear fusion in stars.
        - **Higgs Mechanism**: Not a force but a field that gives particles their mass.
        
        Below, you can explore which particles interact with each of these forces.
        """)
        
        # Define which particles are affected by each force
        force_categories = {
            "Electromagnetic Force": [
                "Up Quark", "Down Quark", "Charm Quark", "Strange Quark", "Top Quark", "Bottom Quark",
                "Electron", "Muon", "Tau", 
                "W Boson", "Photon"
            ],
            "Strong Force": [
                "Up Quark", "Down Quark", "Charm Quark", "Strange Quark", "Top Quark", "Bottom Quark",
                "Gluon"
            ],
            "Weak Force": [
                "Up Quark", "Down Quark", "Charm Quark", "Strange Quark", "Top Quark", "Bottom Quark",
                "Electron", "Muon", "Tau", 
                "Electron Neutrino", "Muon Neutrino", "Tau Neutrino",
                "W Boson", "Z Boson"
            ],
            "Higgs Mechanism": [
                "Up Quark", "Down Quark", "Charm Quark", "Strange Quark", "Top Quark", "Bottom Quark",
                "Electron", "Muon", "Tau", 
                "W Boson", "Z Boson", 
                "Higgs Boson"
            ]
        }
        
        # Create an expandable section for each force category
        for force, particle_names in force_categories.items():
            with st.expander(force, expanded=True):
                # Filter particles for this force
                force_particles = [p for p in all_particles if p["name"] in particle_names]
                
                # Group particles by category for better organization
                categories = {}
                for p in force_particles:
                    category = p["category"]
                    if category not in categories:
                        categories[category] = []
                    categories[category].append(p)
                
                # Sort particles within each category according to the custom ordering
                for category, particles in categories.items():
                    if category == "quark":
                        # Order: up-charm-top-down-strange-bottom
                        quark_order = {"Up Quark": 1, "Charm Quark": 2, "Top Quark": 3, 
                                     "Down Quark": 4, "Strange Quark": 5, "Bottom Quark": 6}
                        particles.sort(key=lambda p: quark_order.get(p["name"], 99))
                    elif category == "lepton":
                        # Order: electron-muon-tau-electron neutrino-muon newtrino-tau newtrino
                        lepton_order = {"Electron": 1, "Muon": 2, "Tau": 3, 
                                      "Electron Neutrino": 4, "Muon Neutrino": 5, "Tau Neutrino": 6}
                        particles.sort(key=lambda p: lepton_order.get(p["name"], 99))
                    elif category == "gauge boson":
                        # Order: gluon-photon-z-w
                        boson_order = {"Gluon": 1, "Photon": 2, "Z Boson": 3, "W Boson": 4}
                        particles.sort(key=lambda p: boson_order.get(p["name"], 99))
                
                # Display a heading for each category
                category_order = ["quark", "lepton", "gauge boson", "scalar boson"]
                
                for cat in category_order:
                    if cat in categories and categories[cat]:
                        st.markdown(f"**{cat.capitalize()}s:**")
                        
                        # Create a multi-column layout for the cards
                        cols = st.columns(min(3, len(categories[cat])))
                        
                        # Display each particle as a card
                        for i, particle in enumerate(categories[cat]):
                            col_index = i % len(cols)
                            
                            with cols[col_index]:
                                # Get color for this category
                                color = get_particle_color(particle["category"])
                                
                                # Create the main card container
                                with st.container():
                                    # Title with background color based on category
                                    st.markdown(
                                        f"""<div style="background-color: {color}; padding: 0.5rem; border-radius: 5px 5px 0 0;">
                                        <h3 style="margin: 0; color: white; text-align: center;">{get_particle_display_name(particle)} ({particle['symbol']})</h3>
                                        </div>""",
                                        unsafe_allow_html=True
                                    )
                                    
                                    # Main content with light background
                                    with st.container():
                                        st.markdown(
                                            f"""<div style="border: 1px solid {color}; border-top: none; padding: 1rem; 
                                            border-radius: 0 0 5px 5px; background-color: rgba({int(color[1:3], 16)}, 
                                            {int(color[3:5], 16)}, {int(color[5:7], 16)}, 0.05);">""",
                                            unsafe_allow_html=True
                                        )
                                        
                                        # Two-column layout for properties
                                        col1, col2 = st.columns(2)
                                        
                                        with col1:
                                            st.markdown(f"**Category:** {particle['category'].capitalize()}")
                                            st.markdown(f"**Charge:** {particle['charge']}")
                                            
                                            # Add generation if it exists
                                            if 'generation' in particle:
                                                st.markdown(f"**Generation:** {particle['generation']}")
                                        
                                        with col2:
                                            st.markdown(f"**Mass:** {particle['mass']}")
                                            st.markdown(f"**Spin:** {particle['spin']}")
                                        
                                        # Description section (shorter for this view)
                                        st.markdown("<hr style='margin: 0.5rem 0;'>", unsafe_allow_html=True)
                                        
                                        # Close the div for styling
                                        st.markdown("</div>", unsafe_allow_html=True)
                
                # Add a separator between force categories
                st.markdown("---")
    
    # Tab 3: Table View
    with tab3:
        st.subheader(get_translation("particles_table"))
        
        # Filter options
        category_filter = st.selectbox(
            "Filter by category",
            ["All"] + sorted(set(p["category"] for p in all_particles)),
            index=0
        )
        
        # Filter particles based on selection
        filtered_particles = all_particles
        if category_filter != "All":
            filtered_particles = [p for p in all_particles if p["category"] == category_filter.lower()]
        
        # Sort particles using the custom ordering
        if category_filter != "All":
            if category_filter.lower() == "quark":
                # Order: up-charm-top-down-strange-bottom
                quark_order = {"Up Quark": 1, "Charm Quark": 2, "Top Quark": 3, 
                             "Down Quark": 4, "Strange Quark": 5, "Bottom Quark": 6}
                filtered_particles.sort(key=lambda p: quark_order.get(p["name"], 99))
                
            elif category_filter.lower() == "lepton":
                # Order: electron-muon-tau-electron neutrino-muon newtrino-tau newtrino
                lepton_order = {"Electron": 1, "Muon": 2, "Tau": 3, 
                              "Electron Neutrino": 4, "Muon Neutrino": 5, "Tau Neutrino": 6}
                filtered_particles.sort(key=lambda p: lepton_order.get(p["name"], 99))
                
            elif category_filter.lower() == "gauge boson":
                # Order: gluon-photon-z-w
                boson_order = {"Gluon": 1, "Photon": 2, "Z Boson": 3, "W Boson": 4}
                filtered_particles.sort(key=lambda p: boson_order.get(p["name"], 99))
        
        # Prepare data for table
        table_data = []
        for p in filtered_particles:
            row = {
                "Name": get_particle_display_name(p),
                "Symbol": p["symbol"],
                "Category": p["category"].capitalize(),
                "Charge": p["charge"],
                "Mass": p["mass"],
                "Spin": p["spin"]
            }
            
            # Add optional fields if they exist
            if "generation" in p:
                row["Generation"] = p["generation"]
            if "force" in p:
                row["Force"] = p["force"]
            
            table_data.append(row)
        
        # Create DataFrame
        df = pd.DataFrame(table_data)
        
        # Display table
        st.dataframe(df, use_container_width=True)
    
    # Tab 4: Particle Search
    with tab4:
        st.subheader(get_translation("search_for_particles"))
        
        # Search box
        search_query = st.text_input(get_translation("search_by_particle_name_symbol_or_category"), "")
        
        if search_query:
            search_results = search_particles(search_query)
            
            if search_results:
                st.success(get_translation("found_particles").format(len(search_results)))
                
                # Sort search results by category and custom order
                # First, group by category
                categorized_results = {}
                for particle in search_results:
                    category = particle["category"]
                    if category not in categorized_results:
                        categorized_results[category] = []
                    categorized_results[category].append(particle)
                
                # Sort each category using the custom ordering
                for category, particles in categorized_results.items():
                    if category == "quark":
                        # Order: up-charm-top-down-strange-bottom
                        quark_order = {"Up Quark": 1, "Charm Quark": 2, "Top Quark": 3, 
                                     "Down Quark": 4, "Strange Quark": 5, "Bottom Quark": 6}
                        particles.sort(key=lambda p: quark_order.get(p["name"], 99))
                    elif category == "lepton":
                        # Order: electron-muon-tau-electron neutrino-muon newtrino-tau newtrino
                        lepton_order = {"Electron": 1, "Muon": 2, "Tau": 3, 
                                      "Electron Neutrino": 4, "Muon Neutrino": 5, "Tau Neutrino": 6}
                        particles.sort(key=lambda p: lepton_order.get(p["name"], 99))
                    elif category == "gauge boson":
                        # Order: gluon-photon-z-w
                        boson_order = {"Gluon": 1, "Photon": 2, "Z Boson": 3, "W Boson": 4}
                        particles.sort(key=lambda p: boson_order.get(p["name"], 99))
                
                # Create a flat list of sorted particles by category order
                category_order = ["quark", "lepton", "gauge boson", "scalar boson"]
                sorted_results = []
                for category in category_order:
                    if category in categorized_results:
                        sorted_results.extend(categorized_results[category])
                
                # Display search results
                for particle in sorted_results:
                    color = get_particle_color(particle["category"])
                    
                    # Use the same Wikipedia-like layout for search results
                    with st.container():
                        # Title with background color based on category
                        st.markdown(
                            f"""<div style="background-color: {color}; padding: 0.5rem; border-radius: 5px 5px 0 0;">
                            <h3 style="margin: 0; color: white; text-align: center;">{get_particle_display_name(particle)} ({particle['symbol']})</h3>
                            </div>""",
                            unsafe_allow_html=True
                        )
                        
                        # Main content with light background
                        with st.container():
                            st.markdown(
                                f"""<div style="border: 1px solid {color}; border-top: none; padding: 1rem; 
                                border-radius: 0 0 5px 5px; margin-bottom: 1.5rem; background-color: rgba({int(color[1:3], 16)}, 
                                {int(color[3:5], 16)}, {int(color[5:7], 16)}, 0.05);">""",
                                unsafe_allow_html=True
                            )
                            
                            # Two-column layout for properties
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.markdown(f"**{get_translation('category')}:** {particle['category'].capitalize()}")
                                st.markdown(f"**{get_translation('charge')}:** {particle['charge']}")
                                
                                # Add generation if it exists
                                if 'generation' in particle:
                                    st.markdown(f"**{get_translation('generation')}:** {particle['generation']}")
                            
                            with col2:
                                st.markdown(f"**{get_translation('mass')}:** {particle['mass']}")
                                st.markdown(f"**{get_translation('spin')}:** {particle['spin']}")
                                
                                # Add force if it exists and is not None
                                if 'force' in particle and particle['force'] is not None:
                                    st.markdown(f"**{get_translation('force')}:** {particle['force']}")
                            
                            # Description section
                            st.markdown("<hr style='margin: 0.5rem 0;'>", unsafe_allow_html=True)
                            st.markdown(f"**{get_translation('description')}:**")
                            st.markdown(get_particle_description(particle))
                            
                            # Close the div for styling
                            st.markdown("</div>", unsafe_allow_html=True)
            else:
                st.warning(get_translation("no_particles_found").format(search_query))
        else:
            st.info(get_translation("enter_search_term"))
    
    # Additional information section at the bottom
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader(get_translation("comparing_particles"))
        st.markdown(get_translation("fermions_bosons_description"))
    
    with col2:
        st.subheader(get_translation("antimatter_counterparts"))
        st.markdown(get_translation("antimatter_description"))