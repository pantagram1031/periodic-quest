"""
Custom content management module for the Science Learning Platform.
This module allows users to create, edit, and manage their own learning topics
and quiz content.
"""
import streamlit as st
import time
import json
import uuid
import datetime
from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.custom_content import (
    get_custom_topics, get_custom_topic, create_custom_topic, update_custom_topic, delete_custom_topic,
    add_content_section, update_content_section, delete_content_section,
    get_custom_quizzes, get_custom_quiz, create_custom_quiz, update_custom_quiz, delete_custom_quiz,
    add_quiz_question, update_quiz_question, delete_quiz_question
)

def render():
    """Render the custom content management page"""
    st.title(get_translation("custom_content_title", "Custom Content Management"))
    
    # Initialize state for the content editor
    if "content_tab" not in st.session_state:
        st.session_state.content_tab = "topics"  # topics, quizzes, editor
    if "editing_topic_id" not in st.session_state:
        st.session_state.editing_topic_id = None
    if "editing_quiz_id" not in st.session_state:
        st.session_state.editing_quiz_id = None
        
    # Initialize more state variables
    if "editing_section_id" not in st.session_state:
        st.session_state.editing_section_id = None
    
    # Check if user is logged in - only logged-in users can create custom content
    if not is_logged_in():
        st.warning(get_translation("login_required_custom_content", "You need to log in to create or manage custom content."))
        
        # Get the public topics to display
        topics = get_custom_topics()
        
        if topics:
            st.subheader(get_translation("browse_public_topics", "Browse Public Topics"))
            
            for topic in topics:
                # Create a card for each topic
                with st.expander(f"{topic['icon']} {topic['title']}", expanded=False):
                    st.write(topic['description'])
                    st.write(f"**{get_translation('created_by', 'Created by')}:** {topic['created_by']}")
                    
                    # Button to view topic
                    if st.button(get_translation("view_topic", "View Topic"), key=f"view_topic_{topic['id']}", use_container_width=True):
                        st.session_state.viewing_topic_id = topic['id']
                        st.session_state.page = "custom_topic_view"
                        st.rerun()
        
        # Add a prominent button to go to the account page
        st.markdown("---")
        st.info(get_translation("login_to_create", "Log in to create your own custom topics and quizzes."))
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button(get_translation("go_to_login", "Go to Login Page"), use_container_width=True, key="login_button1"):
                st.session_state.page = "account"
                st.rerun()
                
        with col2:
            if st.button(get_translation("go_to_home", "Go to Home"), use_container_width=True, key="home_button"):
                st.session_state.page = "home"
                st.rerun()
        return
    
    # Initialize additional editor state variables
    if "editing_question_id" not in st.session_state:
        st.session_state.editing_question_id = None
    
    # Initialize quiz taking session variables
    if "active_custom_quiz_id" not in st.session_state:
        st.session_state.active_custom_quiz_id = None
    if "custom_quiz_history" not in st.session_state:
        st.session_state.custom_quiz_history = []
    
    # Navigation tabs
    tab1, tab2 = st.tabs([
        get_translation("custom_topics", "Custom Topics"), 
        get_translation("custom_quizzes", "Custom Quiz / Quiz History")
    ])
    
    with tab1:
        _render_topics_tab()
    
    with tab2:
        _render_quizzes_tab()

def _render_topics_tab():
    """Render the custom topics management tab"""
    st.header(get_translation("custom_topics", "Custom Topics"))
    
    # Get current user
    username = get_current_user()
    
    # Display existing topics
    topics = get_custom_topics()
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.write(get_translation("your_custom_topics", "Your custom learning topics:"))
    
    with col2:
        # Create new topic button
        if st.button(get_translation("create_new_topic", "Create New Topic"), key="create_topic_btn", use_container_width=True):
            st.session_state.editing_topic_id = "new"
            st.session_state.content_tab = "topic_editor"
            st.rerun()
    
    if not topics:
        st.info(get_translation("no_custom_topics", "You haven't created any custom topics yet. Click 'Create New Topic' to get started."))
    else:
        # Display topics in a table or list
        for i, topic in enumerate(topics):
            with st.expander(f"{topic['icon']} {topic['title']}", expanded=False):
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.write(f"**{get_translation('description', 'Description')}:** {topic['description']}")
                    st.write(f"**{get_translation('created_by', 'Created by')}:** {topic['created_by']}")
                    
                    # Show creation date in a readable format
                    created_date = datetime.datetime.fromisoformat(topic['created_at']).strftime("%Y-%m-%d")
                    st.write(f"**{get_translation('created_at', 'Created')}:** {created_date}")
                    
                    # Show content sections count
                    sections_count = len(topic.get('content_sections', []))
                    st.write(f"**{get_translation('content_sections', 'Content sections')}:** {sections_count}")
                
                with col2:
                    # Edit button (only for topics created by current user)
                    if topic['created_by'] == username:
                        if st.button(get_translation("edit", "Edit"), key=f"edit_topic_{i}", use_container_width=True):
                            st.session_state.editing_topic_id = topic['id']
                            st.session_state.content_tab = "topic_editor"
                            st.rerun()
                
                with col3:
                    # View button
                    if st.button(get_translation("view", "View"), key=f"view_topic_{i}", use_container_width=True):
                        # Set the topic as active in session state
                        st.session_state.viewing_topic_id = topic['id']
                        st.session_state.page = "custom_topic_view"
                        st.rerun()
    
    # If in topic editor mode, show the editor
    if st.session_state.content_tab == "topic_editor":
        st.markdown("---")
        _render_topic_editor()

def _render_topic_editor():
    """Render the topic editor interface"""
    # Check if creating new or editing existing
    is_new = st.session_state.editing_topic_id == "new"
    
    if is_new:
        st.subheader(get_translation("create_new_topic", "Create New Topic"))
        topic = {
            "title": "",
            "description": "",
            "icon": "📚",
            "content_sections": []
        }
    else:
        st.subheader(get_translation("edit_topic", "Edit Topic"))
        topic = get_custom_topic(st.session_state.editing_topic_id)
        
        if not topic:
            st.error(get_translation("topic_not_found", "Topic not found."))
            return
    
    # Topic form
    with st.form("topic_editor_form"):
        topic_title = st.text_input(
            get_translation("topic_title", "Topic Title"),
            value=topic.get("title", "")
        )
        
        topic_description = st.text_area(
            get_translation("topic_description", "Description"),
            value=topic.get("description", ""),
            height=100
        )
        
        # Icon selection - offer a few options
        icon_options = ["📚", "🧪", "⚗️", "🔬", "🧬", "🪐", "⚛️", "🧮", "📊", "🧠"]
        selected_icon = st.selectbox(
            get_translation("select_icon", "Select Icon"),
            options=icon_options,
            index=icon_options.index(topic.get("icon", "📚")) if topic.get("icon", "📚") in icon_options else 0
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            submit_button = st.form_submit_button(
                get_translation("save_topic", "Save Topic"),
                use_container_width=True
            )
        
        with col2:
            cancel_button = st.form_submit_button(
                get_translation("cancel", "Cancel"),
                use_container_width=True
            )
        
        if submit_button:
            # Validate inputs
            if not topic_title:
                st.error(get_translation("title_required", "Topic title is required."))
            else:
                # Save the topic
                username = get_current_user()
                
                if is_new:
                    # Create new topic
                    created_topic = create_custom_topic(
                        title=topic_title,
                        description=topic_description,
                        icon=selected_icon,
                        created_by=username
                    )
                    if created_topic:
                        st.success(get_translation("topic_created", "Topic created successfully!"))
                        # Set to edit the newly created topic
                        st.session_state.editing_topic_id = created_topic["id"]
                        st.rerun()
                else:
                    # Update existing topic
                    updated_topic = update_custom_topic(
                        topic_id=st.session_state.editing_topic_id,
                        title=topic_title,
                        description=topic_description,
                        icon=selected_icon
                    )
                    if updated_topic:
                        st.success(get_translation("topic_updated", "Topic updated successfully!"))
                        st.rerun()
        
        if cancel_button:
            # Exit edit mode
            st.session_state.editing_topic_id = None
            st.session_state.content_tab = "topics"
            st.rerun()
    
    # If editing an existing topic, show content sections editor
    if not is_new:
        st.markdown("---")
        _render_content_sections_editor(topic)

def _render_content_sections_editor(topic):
    """Render the editor for topic content sections"""
    st.subheader(get_translation("content_sections", "Content Sections"))
    
    # Get existing content sections
    content_sections = topic.get("content_sections", [])
    
    # Display existing sections
    if not content_sections:
        st.info(get_translation("no_content_sections", "This topic doesn't have any content sections yet."))
    else:
        for i, section in enumerate(content_sections):
            with st.expander(f"{i+1}. {section['title']}", expanded=False):
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.write(f"**{get_translation('section_type', 'Type')}:** {section['content_type']}")
                    
                    # Display preview based on content type
                    if section['content_type'] == 'text':
                        st.write(section['content_data'].get('text', ''))
                    elif section['content_type'] == 'image_url':
                        st.image(section['content_data'].get('url', ''), use_column_width=True)
                    elif section['content_type'] == 'chart':
                        st.info(get_translation("chart_preview", "Chart preview available when viewing the topic."))
                
                with col2:
                    # Edit button
                    if st.button(get_translation("edit", "Edit"), key=f"edit_section_{i}", use_container_width=True):
                        st.session_state.editing_section_id = section['id']
                        st.rerun()
                
                with col3:
                    # Delete button
                    if st.button(get_translation("delete", "Delete"), key=f"delete_section_{i}", use_container_width=True):
                        if delete_content_section(topic['id'], section['id']):
                            st.success(get_translation("section_deleted", "Section deleted successfully!"))
                            st.rerun()
                        else:
                            st.error(get_translation("section_delete_error", "Error deleting section."))
    
    # Add new section button
    if st.button(get_translation("add_section", "Add Content Section"), key="add_section_btn"):
        st.session_state.editing_section_id = "new"
        st.rerun()
    
    # If editing a section, show the section editor
    if st.session_state.editing_section_id:
        st.markdown("---")
        _render_section_editor(topic)

def _render_section_editor(topic):
    """Render the editor for a single content section"""
    # Check if creating new or editing existing
    is_new = st.session_state.editing_section_id == "new"
    
    if is_new:
        st.subheader(get_translation("add_content_section", "Add Content Section"))
        section = {
            "title": "",
            "content_type": "text",
            "content_data": {}
        }
    else:
        st.subheader(get_translation("edit_content_section", "Edit Content Section"))
        
        # Find the section in the topic's content sections
        section = None
        for s in topic.get("content_sections", []):
            if s['id'] == st.session_state.editing_section_id:
                section = s
                break
        
        if not section:
            st.error(get_translation("section_not_found", "Section not found."))
            return
    
    # Section form
    with st.form("section_editor_form"):
        section_title = st.text_input(
            get_translation("section_title", "Section Title"),
            value=section.get("title", "")
        )
        
        # Content type selection
        content_type_options = [
            ("text", get_translation("content_type_text", "Text Content")),
            ("image_url", get_translation("content_type_image", "Image URL")),
            ("chart", get_translation("content_type_chart", "Chart/Graph")),
        ]
        
        content_type_values = [ct[0] for ct in content_type_options]
        content_type_display = [ct[1] for ct in content_type_options]
        
        selected_type_index = content_type_values.index(section.get("content_type", "text")) if section.get("content_type", "text") in content_type_values else 0
        
        content_type = st.selectbox(
            get_translation("content_type", "Content Type"),
            options=content_type_display,
            index=selected_type_index
        )
        
        # Convert display name back to value
        selected_content_type = content_type_values[content_type_display.index(content_type)]
        
        # Content data based on type
        content_data = section.get("content_data", {})
        
        if selected_content_type == "text":
            text_content = st.text_area(
                get_translation("text_content", "Text Content"),
                value=content_data.get("text", ""),
                height=200
            )
            content_data = {"text": text_content}
            
        elif selected_content_type == "image_url":
            image_url = st.text_input(
                get_translation("image_url", "Image URL"),
                value=content_data.get("url", "")
            )
            if image_url:
                st.image(image_url, use_column_width=True)
            content_data = {"url": image_url}
            
        elif selected_content_type == "chart":
            chart_type_options = ["bar", "line", "scatter", "pie"]
            chart_type = st.selectbox(
                get_translation("chart_type", "Chart Type"),
                options=chart_type_options,
                index=chart_type_options.index(content_data.get("chart_type", "bar")) if content_data.get("chart_type", "bar") in chart_type_options else 0
            )
            
            chart_title = st.text_input(
                get_translation("chart_title", "Chart Title"),
                value=content_data.get("title", "")
            )
            
            # For data, we'll use a simplified approach - comma separated values
            x_data = st.text_input(
                get_translation("x_axis_data", "X-axis Data (comma separated)"),
                value=",".join(content_data.get("x_data", []))
            )
            
            y_data = st.text_input(
                get_translation("y_axis_data", "Y-axis Data (comma separated)"),
                value=",".join(map(str, content_data.get("y_data", [])))
            )
            
            x_label = st.text_input(
                get_translation("x_axis_label", "X-axis Label"),
                value=content_data.get("x_label", "")
            )
            
            y_label = st.text_input(
                get_translation("y_axis_label", "Y-axis Label"),
                value=content_data.get("y_label", "")
            )
            
            # Process the data
            x_data_list = [x.strip() for x in x_data.split(",") if x.strip()]
            
            try:
                y_data_list = [float(y.strip()) for y in y_data.split(",") if y.strip()]
            except ValueError:
                st.error(get_translation("y_data_numeric", "Y-axis data must be numeric."))
                y_data_list = []
            
            content_data = {
                "chart_type": chart_type,
                "title": chart_title,
                "x_data": x_data_list,
                "y_data": y_data_list,
                "x_label": x_label,
                "y_label": y_label
            }
        
        col1, col2 = st.columns(2)
        
        with col1:
            submit_button = st.form_submit_button(
                get_translation("save_section", "Save Section"),
                use_container_width=True
            )
        
        with col2:
            cancel_button = st.form_submit_button(
                get_translation("cancel", "Cancel"),
                use_container_width=True
            )
        
        if submit_button:
            # Validate inputs
            if not section_title:
                st.error(get_translation("title_required", "Section title is required."))
            elif selected_content_type == "text" and not content_data.get("text"):
                st.error(get_translation("text_required", "Text content is required."))
            elif selected_content_type == "image_url" and not content_data.get("url"):
                st.error(get_translation("url_required", "Image URL is required."))
            elif selected_content_type == "chart" and (not content_data.get("x_data") or not content_data.get("y_data")):
                st.error(get_translation("chart_data_required", "Chart data is required."))
            else:
                # Save the section
                if is_new:
                    # Add new section
                    added_section = add_content_section(
                        topic_id=topic['id'],
                        title=section_title,
                        content_type=selected_content_type,
                        content_data=content_data
                    )
                    if added_section:
                        st.success(get_translation("section_added", "Section added successfully!"))
                        st.session_state.editing_section_id = None
                        st.rerun()
                    else:
                        st.error(get_translation("section_add_error", "Error adding section."))
                else:
                    # Update existing section
                    updated_section = update_content_section(
                        topic_id=topic['id'],
                        section_id=st.session_state.editing_section_id,
                        title=section_title,
                        content_type=selected_content_type,
                        content_data=content_data
                    )
                    if updated_section:
                        st.success(get_translation("section_updated", "Section updated successfully!"))
                        st.session_state.editing_section_id = None
                        st.rerun()
                    else:
                        st.error(get_translation("section_update_error", "Error updating section."))
        
        if cancel_button:
            # Exit edit mode
            st.session_state.editing_section_id = None
            st.rerun()

def _render_quizzes_tab():
    """Render the custom quizzes management tab"""
    st.header(get_translation("custom_quizzes", "Custom Quiz / Quiz History"))
    
    # Get current user
    username = get_current_user()
    
    # Create tabs for managing and taking quizzes
    quiz_tabs = st.tabs(["Manage Quizzes", "Take Quiz", "Quiz History"])
    
    with quiz_tabs[0]:  # Manage Quizzes tab
        _render_quiz_management()
    
    with quiz_tabs[1]:  # Take Quiz tab
        _render_quiz_selection()
    
    with quiz_tabs[2]:  # Quiz History tab
        _render_quiz_history()

def _render_quiz_management():
    """Render the quiz management interface"""
    st.subheader("Manage Custom Quizzes")
    
    # Get current user
    username = get_current_user()
    
    # Display existing quizzes
    quizzes = get_custom_quizzes()
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.write(get_translation("your_custom_quizzes", "Your custom quizzes:"))
    
    with col2:
        # Create new quiz button
        if st.button(get_translation("create_new_quiz", "Create New Quiz"), key="create_quiz_btn", use_container_width=True):
            st.session_state.editing_quiz_id = "new"
            st.session_state.content_tab = "quiz_editor"
            st.rerun()
    
    if not quizzes:
        st.info(get_translation("no_custom_quizzes", "You haven't created any custom quizzes yet. Click 'Create New Quiz' to get started."))
    else:
        # Display quizzes in a table or list
        for i, quiz in enumerate(quizzes):
            with st.expander(f"📝 {quiz['title']}", expanded=False):
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.write(f"**{get_translation('description', 'Description')}:** {quiz['description']}")
                    st.write(f"**{get_translation('created_by', 'Created by')}:** {quiz['created_by']}")
                    
                    # Show creation date in a readable format
                    created_date = datetime.datetime.fromisoformat(quiz['created_at']).strftime("%Y-%m-%d")
                    st.write(f"**{get_translation('created_at', 'Created')}:** {created_date}")
                    
                    # Show questions count
                    questions_count = len(quiz.get('questions', []))
                    st.write(f"**{get_translation('questions', 'Questions')}:** {questions_count}")
                    
                    # Show difficulty
                    difficulty = quiz.get('difficulty', 'medium')
                    st.write(f"**{get_translation('difficulty', 'Difficulty')}:** {get_translation(f'difficulty_{difficulty}', difficulty)}")
                
                with col2:
                    # Edit button (only for quizzes created by current user)
                    if quiz['created_by'] == username:
                        if st.button(get_translation("edit", "Edit"), key=f"edit_quiz_{i}", use_container_width=True):
                            st.session_state.editing_quiz_id = quiz['id']
                            st.session_state.content_tab = "quiz_editor"
                            st.rerun()
                
                with col3:
                    # Take quiz button
                    if st.button(get_translation("take_quiz", "Take Quiz"), key=f"take_quiz_{i}", use_container_width=True):
                        # Set the quiz as active in session state
                        st.session_state.active_custom_quiz_id = quiz['id']
                        st.session_state.page = "quiz"
                        st.session_state.quiz_tab = "start"  # Reset to start tab
                        st.rerun()
    
    # If in quiz editor mode, show the editor
    if st.session_state.content_tab == "quiz_editor":
        st.markdown("---")
        _render_quiz_editor()

def _render_quiz_editor():
    """Render the quiz editor interface"""
    # Check if creating new or editing existing
    is_new = st.session_state.editing_quiz_id == "new"
    
    if is_new:
        st.subheader(get_translation("create_new_quiz", "Create New Quiz"))
        quiz = {
            "title": "",
            "description": "",
            "difficulty": "medium",
            "questions": []
        }
    else:
        st.subheader(get_translation("edit_quiz", "Edit Quiz"))
        quiz = get_custom_quiz(st.session_state.editing_quiz_id)
        
        if not quiz:
            st.error(get_translation("quiz_not_found", "Quiz not found."))
            return
    
    # Quiz form
    with st.form("quiz_editor_form"):
        quiz_title = st.text_input(
            get_translation("quiz_title", "Quiz Title"),
            value=quiz.get("title", "")
        )
        
        quiz_description = st.text_area(
            get_translation("quiz_description", "Description"),
            value=quiz.get("description", ""),
            height=100
        )
        
        # Topic selection - allow selecting from custom topics and built-in topics
        # For now, we'll just use a text field for the associated topic
        topic_id = st.text_input(
            get_translation("associated_topic", "Associated Topic ID (optional)"),
            value=quiz.get("topic_id", "")
        )
        
        # Difficulty selection
        difficulty_options = [
            ("easy", get_translation("difficulty_easy", "Easy")),
            ("medium", get_translation("difficulty_medium", "Medium")),
            ("hard", get_translation("difficulty_hard", "Hard"))
        ]
        
        difficulty_values = [d[0] for d in difficulty_options]
        difficulty_display = [d[1] for d in difficulty_options]
        
        selected_difficulty_index = difficulty_values.index(quiz.get("difficulty", "medium")) if quiz.get("difficulty", "medium") in difficulty_values else 1
        
        difficulty = st.selectbox(
            get_translation("quiz_difficulty", "Quiz Difficulty"),
            options=difficulty_display,
            index=selected_difficulty_index
        )
        
        # Convert display name back to value
        selected_difficulty = difficulty_values[difficulty_display.index(difficulty)]
        
        col1, col2 = st.columns(2)
        
        with col1:
            submit_button = st.form_submit_button(
                get_translation("save_quiz", "Save Quiz"),
                use_container_width=True
            )
        
        with col2:
            cancel_button = st.form_submit_button(
                get_translation("cancel", "Cancel"),
                use_container_width=True
            )
        
        if submit_button:
            # Validate inputs
            if not quiz_title:
                st.error(get_translation("title_required", "Quiz title is required."))
            else:
                # Save the quiz
                username = get_current_user()
                
                if is_new:
                    # Create new quiz
                    created_quiz = create_custom_quiz(
                        title=quiz_title,
                        description=quiz_description,
                        topic_id=topic_id,
                        created_by=username,
                        difficulty=selected_difficulty
                    )
                    if created_quiz:
                        st.success(get_translation("quiz_created", "Quiz created successfully!"))
                        # Set to edit the newly created quiz
                        st.session_state.editing_quiz_id = created_quiz["id"]
                        st.rerun()
                else:
                    # Update existing quiz
                    updated_quiz = update_custom_quiz(
                        quiz_id=st.session_state.editing_quiz_id,
                        title=quiz_title,
                        description=quiz_description,
                        difficulty=selected_difficulty
                    )
                    if updated_quiz:
                        st.success(get_translation("quiz_updated", "Quiz updated successfully!"))
                        st.rerun()
        
        if cancel_button:
            # Exit edit mode
            st.session_state.editing_quiz_id = None
            st.session_state.content_tab = "quizzes"
            st.rerun()
    
    # If editing an existing quiz, show questions editor
    if not is_new:
        st.markdown("---")
        _render_questions_editor(quiz)

def _render_questions_editor(quiz):
    """Render the editor for quiz questions"""
    st.subheader(get_translation("quiz_questions", "Quiz Questions"))
    
    # Get existing questions
    questions = quiz.get("questions", [])
    
    # Display existing questions
    if not questions:
        st.info(get_translation("no_questions", "This quiz doesn't have any questions yet."))
    else:
        for i, question in enumerate(questions):
            with st.expander(f"Q{i+1}: {question['question_text']}", expanded=False):
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.write(f"**{get_translation('question_type', 'Type')}:** {question['question_type']}")
                    st.write(f"**{get_translation('correct_answer', 'Correct answer')}:** {question['correct_answer']}")
                    
                    # Show options for multiple choice questions
                    if question['question_type'] == 'multiple_choice' and 'options' in question:
                        st.write(f"**{get_translation('options', 'Options')}:**")
                        for j, option in enumerate(question['options']):
                            is_correct = option == question['correct_answer']
                            st.write(f"{j+1}. {option} {'✓' if is_correct else ''}")
                    
                    # Show explanation if available
                    if 'explanation' in question and question['explanation']:
                        st.write(f"**{get_translation('explanation', 'Explanation')}:** {question['explanation']}")
                
                with col2:
                    # Edit button
                    if st.button(get_translation("edit", "Edit"), key=f"edit_question_{i}", use_container_width=True):
                        st.session_state.editing_question_id = question['id']
                        st.rerun()
                
                with col3:
                    # Delete button
                    if st.button(get_translation("delete", "Delete"), key=f"delete_question_{i}", use_container_width=True):
                        if delete_quiz_question(quiz['id'], question['id']):
                            st.success(get_translation("question_deleted", "Question deleted successfully!"))
                            st.rerun()
                        else:
                            st.error(get_translation("question_delete_error", "Error deleting question."))
    
    # Add new question button
    if st.button(get_translation("add_question", "Add Question"), key="add_question_btn"):
        st.session_state.editing_question_id = "new"
        st.rerun()
    
    # If editing a question, show the question editor
    if st.session_state.editing_question_id:
        st.markdown("---")
        _render_question_editor(quiz)

def _render_question_editor(quiz):
    """Render the editor for a single quiz question"""
    # Check if creating new or editing existing
    is_new = st.session_state.editing_question_id == "new"
    
    if is_new:
        st.subheader(get_translation("add_question", "Add Question"))
        question = {
            "question_text": "",
            "question_type": "multiple_choice",
            "correct_answer": "",
            "options": ["", "", "", ""],
            "explanation": ""
        }
    else:
        st.subheader(get_translation("edit_question", "Edit Question"))
        
        # Find the question in the quiz's questions
        question = None
        for q in quiz.get("questions", []):
            if q['id'] == st.session_state.editing_question_id:
                question = q
                break
        
        if not question:
            st.error(get_translation("question_not_found", "Question not found."))
            return
    
    # Question form
    with st.form("question_editor_form"):
        question_text = st.text_area(
            get_translation("question_text", "Question Text"),
            value=question.get("question_text", ""),
            height=100
        )
        
        # Question type selection
        question_type_options = [
            ("multiple_choice", get_translation("multiple_choice", "Multiple Choice")),
            ("text_input", get_translation("text_input", "Text Input"))
        ]
        
        question_type_values = [qt[0] for qt in question_type_options]
        question_type_display = [qt[1] for qt in question_type_options]
        
        selected_type_index = question_type_values.index(question.get("question_type", "multiple_choice")) if question.get("question_type", "multiple_choice") in question_type_values else 0
        
        question_type = st.selectbox(
            get_translation("question_type", "Question Type"),
            options=question_type_display,
            index=selected_type_index
        )
        
        # Convert display name back to value
        selected_question_type = question_type_values[question_type_display.index(question_type)]
        
        # For multiple choice questions, show options
        if selected_question_type == "multiple_choice":
            st.subheader(get_translation("answer_options", "Answer Options"))
            
            options = question.get("options", ["", "", "", ""])
            
            # Ensure at least 2 options
            while len(options) < 2:
                options.append("")
            
            # Option inputs
            new_options = []
            for i in range(4):  # Fixed 4 options for simplicity
                if i < len(options):
                    option_text = st.text_input(
                        f"{get_translation('option', 'Option')} {i + 1}",
                        value=options[i],
                        key=f"option_{i}"
                    )
                else:
                    option_text = st.text_input(
                        f"{get_translation('option', 'Option')} {i + 1}",
                        value="",
                        key=f"option_{i}"
                    )
                
                if option_text:
                    new_options.append(option_text)
            
            # Select correct answer from options
            if not new_options:
                new_options = [""]
                
            # Find the index of the correct answer if it exists
            correct_answer_index = 0
            if question.get("correct_answer", "") in new_options:
                correct_answer_index = new_options.index(question.get("correct_answer", ""))
                
            correct_answer = st.selectbox(
                get_translation("correct_answer", "Correct Answer"),
                options=new_options,
                index=correct_answer_index
            )
        else:
            # For text input questions, directly input the correct answer
            correct_answer = st.text_input(
                get_translation("correct_answer", "Correct Answer"),
                value=question.get("correct_answer", "")
            )
            new_options = None
        
        # Explanation (optional)
        explanation = st.text_area(
            get_translation("explanation", "Explanation (optional)"),
            value=question.get("explanation", ""),
            height=100
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            submit_button = st.form_submit_button(
                get_translation("save_question", "Save Question"),
                use_container_width=True
            )
        
        with col2:
            cancel_button = st.form_submit_button(
                get_translation("cancel", "Cancel"),
                use_container_width=True
            )
        
        if submit_button:
            # Validate inputs
            if not question_text:
                st.error(get_translation("question_required", "Question text is required."))
            elif not correct_answer:
                st.error(get_translation("answer_required", "Correct answer is required."))
            elif selected_question_type == "multiple_choice" and (new_options is None or len(new_options) < 2):
                st.error(get_translation("options_required", "At least 2 options are required for multiple choice questions."))
            else:
                # Save the question
                if is_new:
                    # Add new question
                    added_question = add_quiz_question(
                        quiz_id=quiz['id'],
                        question_text=question_text,
                        question_type=selected_question_type,
                        correct_answer=correct_answer,
                        options=new_options if selected_question_type == "multiple_choice" else None,
                        explanation=explanation if explanation else None
                    )
                    if added_question:
                        st.success(get_translation("question_added", "Question added successfully!"))
                        st.session_state.editing_question_id = None
                        st.rerun()
                    else:
                        st.error(get_translation("question_add_error", "Error adding question."))
                else:
                    # Update existing question
                    updated_question = update_quiz_question(
                        quiz_id=quiz['id'],
                        question_id=st.session_state.editing_question_id,
                        question_text=question_text,
                        correct_answer=correct_answer,
                        options=new_options if selected_question_type == "multiple_choice" else None,
                        explanation=explanation if explanation else None
                    )
                    if updated_question:
                        st.success(get_translation("question_updated", "Question updated successfully!"))
                        st.session_state.editing_question_id = None
                        st.rerun()
                    else:
                        st.error(get_translation("question_update_error", "Error updating question."))
        
        if cancel_button:
            # Exit edit mode
            st.session_state.editing_question_id = None
            st.rerun()

def _render_quiz_selection():
    """Render the quiz selection interface for taking quizzes"""
    st.subheader("Take a Custom Quiz")
    
    # Get all topics for selection
    topics = get_custom_topics()
    
    if not topics:
        st.info("You don't have any custom topics yet. Create a topic first to generate quizzes.")
        return
    
    # Group quizzes by topic
    all_quizzes = get_custom_quizzes()
    quizzes_by_topic = {}
    
    for quiz in all_quizzes:
        topic_id = quiz.get("topic_id")
        if topic_id:
            if topic_id not in quizzes_by_topic:
                quizzes_by_topic[topic_id] = []
            quizzes_by_topic[topic_id].append(quiz)
    
    # Create a dictionary for topic lookup by ID
    topic_dict = {topic["id"]: topic for topic in topics}
    
    # Display available topics with quizzes
    st.write("Select a topic to find quizzes:")
    
    # Create a selection for topics
    topic_options = ["All Topics"] + [f"{topic['icon']} {topic['title']}" for topic in topics]
    selected_topic_display = st.selectbox(
        "Select Topic",
        options=topic_options,
        key="take_quiz_topic_selector"
    )
    
    # Filter quizzes based on selected topic
    if selected_topic_display == "All Topics":
        # Show all quizzes
        filtered_quizzes = all_quizzes
    else:
        # Extract topic ID from display name
        selected_topic_index = topic_options.index(selected_topic_display) - 1  # Adjust for "All Topics"
        if 0 <= selected_topic_index < len(topics):
            selected_topic = topics[selected_topic_index]
            topic_id = selected_topic["id"]
            
            # Filter quizzes for this topic
            filtered_quizzes = quizzes_by_topic.get(topic_id, [])
        else:
            filtered_quizzes = []
    
    # Display available quizzes for selection
    if not filtered_quizzes:
        st.info("No quizzes found for the selected topic. Create a quiz first.")
    else:
        st.write(f"Found {len(filtered_quizzes)} quiz(es) for the selected topic/filter")
        
        # Create a card for each quiz
        for i, quiz in enumerate(filtered_quizzes):
            with st.expander(f"📝 {quiz['title']}", expanded=True):
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    # Show quiz details
                    st.write(f"**Description:** {quiz['description']}")
                    
                    # Show topic if available
                    topic_id = quiz.get("topic_id")
                    if topic_id and topic_id in topic_dict:
                        topic = topic_dict[topic_id]
                        st.write(f"**Topic:** {topic['icon']} {topic['title']}")
                    
                    # Show difficulty
                    difficulty = quiz.get("difficulty", "medium")
                    st.write(f"**Difficulty:** {difficulty.capitalize()}")
                    
                    # Show question count
                    question_count = len(quiz.get("questions", []))
                    st.write(f"**Questions:** {question_count}")
                
                with col2:
                    # Take quiz button
                    if st.button("Take Quiz", key=f"take_selected_quiz_{i}", use_container_width=True):
                        # Set up session state for the quiz
                        st.session_state.active_custom_quiz_id = quiz["id"]
                        st.session_state.page = "quiz"  # Redirect to the quiz page
                        st.rerun()

def _render_quiz_history():
    """Render the quiz history interface"""
    st.subheader("Quiz History")
    
    # Check if there's any history
    if not st.session_state.custom_quiz_history:
        st.info("You haven't taken any quizzes yet. Try taking a quiz from the 'Take Quiz' tab.")
        return
    
    # Create a list of past quizzes with results
    for i, result in enumerate(st.session_state.custom_quiz_history):
        with st.expander(f"Quiz #{i+1} - {result.get('title', 'Untitled Quiz')}", expanded=False):
            # Show quiz summary
            st.write(f"**Date:** {result.get('date', 'Unknown')}")
            st.write(f"**Score:** {result.get('score', 0)}/{result.get('total', 0)} ({result.get('percentage', 0)}%)")
            
            # Show questions and answers
            st.write("**Questions:**")
            for j, question in enumerate(result.get("questions", [])):
                if question.get("correct", False):
                    st.success(f"✓ Q{j+1}: {question.get('question', '')}")
                else:
                    st.error(f"✗ Q{j+1}: {question.get('question', '')}")
                    st.write(f"Your answer: {question.get('selected_answer', '')}")
                    st.write(f"Correct answer: {question.get('correct_answer', '')}")
                st.write("---")