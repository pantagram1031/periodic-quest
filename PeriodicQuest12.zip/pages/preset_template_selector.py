"""
Preset Template Selector module for the Science Learning Platform.
This module provides a selection interface for preset topic templates.
"""
import streamlit as st
from utils.translations import get_translation

def render():
    """Render the preset template selector page"""
    st.title("Select a Preset Template")
    
    # Define available templates
    templates = [
        {
            "id": "periodic_table",
            "name": "Periodic Table",
            "icon": "⚛️",
            "description": "Create a topic based on the periodic table structure, with elements and their properties.",
            "aspects": [
                {"name": "Atomic Number", "type": "number", "required": True},
                {"name": "Symbol", "type": "text", "required": True},
                {"name": "Name", "type": "text", "required": True},
                {"name": "Category", "type": "text", "required": True},
                {"name": "Atomic Mass", "type": "number", "required": True},
                {"name": "Electron Configuration", "type": "text", "required": True},
                {"name": "Electronegativity", "type": "number", "required": False},
                {"name": "Atomic Radius", "type": "number", "required": False},
                {"name": "Ionization Energy", "type": "number", "required": False},
                {"name": "Density", "type": "number", "required": False},
                {"name": "Melting Point", "type": "number", "required": False},
                {"name": "Boiling Point", "type": "number", "required": False},
                {"name": "Year Discovered", "type": "number", "required": False},
                {"name": "Discovered By", "type": "text", "required": False}
            ],
            "entities": [
                {
                    "Atomic Number": 1,
                    "Symbol": "H",
                    "Name": "Hydrogen",
                    "Category": "Nonmetal",
                    "Atomic Mass": 1.008,
                    "Electron Configuration": "1s¹",
                    "Electronegativity": 2.20,
                    "Atomic Radius": 120,
                    "Ionization Energy": 13.598,
                    "Density": 0.00008988,
                    "Melting Point": -259.16,
                    "Boiling Point": -252.879,
                    "Year Discovered": 1766,
                    "Discovered By": "Henry Cavendish"
                },
                {
                    "Atomic Number": 2,
                    "Symbol": "He",
                    "Name": "Helium",
                    "Category": "Noble Gas",
                    "Atomic Mass": 4.002602,
                    "Electron Configuration": "1s²",
                    "Electronegativity": None,
                    "Atomic Radius": 140,
                    "Ionization Energy": 24.587,
                    "Density": 0.0001785,
                    "Melting Point": -272.2,
                    "Boiling Point": -268.93,
                    "Year Discovered": 1895,
                    "Discovered By": "Pierre Janssen"
                }
            ]
        },
        {
            "id": "standard_model",
            "name": "Standard Model",
            "icon": "🔬",
            "description": "Create a topic based on the standard model of particle physics, with particles and their properties.",
            "aspects": [
                {"name": "Name", "type": "text", "required": True},
                {"name": "Symbol", "type": "text", "required": True},
                {"name": "Type", "type": "text", "required": True},
                {"name": "Mass", "type": "number", "required": True},
                {"name": "Charge", "type": "number", "required": True},
                {"name": "Spin", "type": "number", "required": True},
                {"name": "Lifetime", "type": "text", "required": False},
                {"name": "Decay Modes", "type": "text", "required": False},
                {"name": "Discovered", "type": "number", "required": False},
                {"name": "Discovered By", "type": "text", "required": False}
            ],
            "entities": [
                {
                    "Name": "Electron",
                    "Symbol": "e⁻",
                    "Type": "Lepton",
                    "Mass": 0.511,
                    "Charge": -1,
                    "Spin": 0.5,
                    "Lifetime": "Stable",
                    "Decay Modes": "None",
                    "Discovered": 1897,
                    "Discovered By": "J.J. Thomson"
                },
                {
                    "Name": "Proton",
                    "Symbol": "p",
                    "Type": "Baryon",
                    "Mass": 938.272,
                    "Charge": 1,
                    "Spin": 0.5,
                    "Lifetime": "Stable",
                    "Decay Modes": "None",
                    "Discovered": 1917,
                    "Discovered By": "Ernest Rutherford"
                }
            ]
        },
        {
            "id": "historical_events",
            "name": "Historical Events",
            "icon": "📅",
            "description": "Create a topic based on historical events, with dates, locations, and significance.",
            "aspects": [
                {"name": "Event Name", "type": "text", "required": True},
                {"name": "Date", "type": "date", "required": True},
                {"name": "Location", "type": "text", "required": True},
                {"name": "Description", "type": "text", "required": True},
                {"name": "Significance", "type": "text", "required": True},
                {"name": "Key Figures", "type": "text", "required": False},
                {"name": "Category", "type": "text", "required": False},
                {"name": "Sources", "type": "text", "required": False}
            ],
            "entities": [
                {
                    "Event Name": "Declaration of Independence",
                    "Date": "1776-07-04",
                    "Location": "Philadelphia, Pennsylvania",
                    "Description": "The Continental Congress adopted the Declaration of Independence, declaring the 13 American colonies independent from British rule.",
                    "Significance": "Marked the birth of the United States of America and inspired independence movements worldwide.",
                    "Key Figures": "Thomas Jefferson, John Adams, Benjamin Franklin",
                    "Category": "Political Revolution",
                    "Sources": "National Archives, Library of Congress"
                },
                {
                    "Event Name": "First Moon Landing",
                    "Date": "1969-07-20",
                    "Location": "Sea of Tranquility, Moon",
                    "Description": "Apollo 11 mission successfully landed humans on the Moon for the first time.",
                    "Significance": "Marked a major achievement in space exploration and the Space Race.",
                    "Key Figures": "Neil Armstrong, Buzz Aldrin, Michael Collins",
                    "Category": "Space Exploration",
                    "Sources": "NASA Archives"
                }
            ]
        }
    ]
    
    # Display templates in a grid
    cols_per_row = 2
    rows = [templates[i:i+cols_per_row] for i in range(0, len(templates), cols_per_row)]
    
    for row in rows:
        cols = st.columns(cols_per_row)
        
        for i, template in enumerate(row):
            with cols[i]:
                with st.container(border=True):
                    st.markdown(f"### {template['icon']} {template['name']}")
                    st.markdown(template['description'])
                    
                    # Show a preview of aspects
                    st.markdown("**Aspects:**")
                    for aspect in template['aspects'][:3]:  # Show first 3 aspects
                        st.markdown(f"- {aspect['name']} ({aspect['type']})")
                    if len(template['aspects']) > 3:
                        st.markdown(f"... and {len(template['aspects']) - 3} more")
                    
                    # Show preview of entities
                    st.markdown("**Sample Entities:**")
                    for entity in template['entities'][:2]:  # Show first 2 entities
                        st.markdown(f"- {entity.get('Name', entity.get('Event Name', 'Entity'))}")
                    
                    # Add select button
                    if st.button(f"Select {template['name']}", key=f"select_{template['id']}", use_container_width=True):
                        st.session_state.topic_template = template
                        st.session_state.page = "topic_create"
                        st.rerun()
    
    # Add a back button
    st.divider()
    if st.button("Back to Topic Selection", use_container_width=True):
        st.session_state.page = "custom_topic_selector"
        st.rerun() 