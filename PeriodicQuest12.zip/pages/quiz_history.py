"""
Quiz history page module for the Science Learning Platform.
This page shows a history of all completed quizzes, allowing users
to view detailed results and element or particle information.
"""

import streamlit as st
import time
from data.elements import search_elements, get_element_by_symbol, get_element_by_name, get_all_elements
from data.standard_model.particles import get_particle_by_symbol, get_particle_by_name, get_all_particles
from utils.translations import get_translation, get_display_name

def render():
    """Render the quiz history page"""
    st.title(get_translation("quiz_history_title"))
    
    # Initialize session state variables for quiz history navigation
    if "quiz_history_viewing" not in st.session_state:
        st.session_state.quiz_history_viewing = None
        
    if not st.session_state.completed_quizzes:
        # No quizzes taken yet
        st.info(get_translation("no_quizzes_taken"))
        
        # Add button to take a quiz
        if st.button(get_translation("take_a_quiz"), key="take_quiz_from_history", use_container_width=True):
            st.session_state.page = "quiz"
            st.rerun()
            
    elif st.session_state.quiz_history_viewing is None:
        # MAIN QUIZ HISTORY VIEW - List of all completed quiz sets
        
        # Show summary statistics
        if len(st.session_state.completed_quizzes) > 0:
            total_questions = sum(q['total'] for q in st.session_state.completed_quizzes)
            total_correct = sum(q['score'] for q in st.session_state.completed_quizzes)
            avg_percentage = round((total_correct / total_questions) * 100, 1) if total_questions > 0 else 0
            
            st.markdown(f"### {get_translation('quiz_summary')}")
            
            # Display overall stats in a nice format
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric(get_translation("total_quizzes"), len(st.session_state.completed_quizzes))
            with col2:
                st.metric(get_translation("total_correct"), f"{total_correct}/{total_questions}")
            with col3:
                st.metric(get_translation("avg_accuracy"), f"{avg_percentage}%")
        
        st.markdown(f"### {get_translation('previous_quizzes')}")
        st.markdown(get_translation("click_to_view_details"))
        
        # Create a container for all quiz sets with a cleaner look
        sets_container = st.container()
        
        with sets_container:
            # Create rows of quiz sets
            for i, quiz in enumerate(st.session_state.completed_quizzes):
                # Create a border around each quiz
                st.markdown(f"""
                <div style="padding: 15px; margin-bottom: 15px; border: 1px solid #e0e0e0; border-radius: 5px;">
                    <h3 style="margin-top: 0px;">Quiz Set #{i+1}</h3>
                    <p><strong>{get_translation("date_taken")}:</strong> {quiz['date']}</p>
                    <p><strong>{get_translation("quiz_type")}:</strong> {quiz['quiz_type']}</p>
                    <p><strong>{get_translation("questions")}:</strong> {quiz['total']}</p>
                    <p><strong>{get_translation("score")}:</strong> {quiz['score']}/{quiz['total']} ({quiz['percentage']}%)</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Button to view this quiz's details
                if st.button(f"{get_translation('view_details')}", key=f"history_quiz_set_{i}", use_container_width=True):
                    st.session_state.quiz_history_viewing = i
                    st.rerun()
        
        # Add a reset button if there's history
        if len(st.session_state.completed_quizzes) > 0:
            st.markdown("---")
            if st.button(get_translation("reset_statistics"), key="history_reset_all_stats"):
                if "confirm_reset" not in st.session_state:
                    st.session_state.confirm_reset = True
                    st.warning(get_translation("confirm_reset_warning"))
                    st.rerun()
                else:
                    # User confirmed reset
                    st.session_state.quiz_score = 0
                    st.session_state.quiz_total = 0
                    st.session_state.quiz_history = []
                    st.session_state.completed_quizzes = []
                    st.session_state.pop("confirm_reset", None)
                    st.success(get_translation("reset_success"))
                    st.rerun()
            
            # Cancel reset if confirmation is showing
            if "confirm_reset" in st.session_state:
                if st.button(get_translation("cancel"), key="history_cancel_reset"):
                    st.session_state.pop("confirm_reset", None)
                    st.rerun()
            
            # Button to take a new quiz
            st.markdown("---")
            if st.button(get_translation("take_a_quiz"), key="take_quiz_from_history_list", use_container_width=True):
                st.session_state.page = "quiz"
                st.rerun()
        
    else:
        # DETAILED QUIZ VIEW - Viewing a specific quiz set
        quiz_index = st.session_state.quiz_history_viewing
        
        # Ensure valid index
        if 0 <= quiz_index < len(st.session_state.completed_quizzes):
            quiz = st.session_state.completed_quizzes[quiz_index]
            
            # Back button at the top
            if st.button(f"← {get_translation('back_to_list')}", key="history_back_btn", use_container_width=True):
                st.session_state.quiz_history_viewing = None
                st.rerun()
            
            # Quiz set header
            st.markdown(f"## {get_translation('quiz_detail')} - #{quiz_index+1}")
            
            # Quiz summary section
            st.markdown(f"""
            <div style="background-color: #f0f2f6; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
                <h3 style="margin-top: 0;">{get_translation('quiz_summary')}</h3>
                <div style="display: flex; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 200px; margin-right: 20px;">
                        <p><strong>{get_translation("date_taken")}:</strong> {quiz['date']}</p>
                        <p><strong>{get_translation("quiz_type")}:</strong> {quiz['quiz_type']}</p>
                        <p><strong>{get_translation("topics")}:</strong> {quiz['topics']}</p>
                    </div>
                    <div style="flex: 1; min-width: 200px;">
                        <p><strong>{get_translation("questions")}:</strong> {quiz['total']}</p>
                        <p><strong>{get_translation("correct_answers")}:</strong> {quiz['score']}</p>
                        <p><strong>{get_translation("accuracy_rate")}:</strong> {quiz['percentage']}%</p>
                    </div>
                </div>
                <div style="margin-top: 10px; background-color: #e0e0e0; height: 10px; border-radius: 5px; overflow: hidden;">
                    <div style="width: {quiz['percentage']}%; background-color: {'green' if quiz['percentage'] >= 70 else 'orange' if quiz['percentage'] >= 50 else 'red'}; height: 100%;"></div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Question list section
            st.markdown(f"## {get_translation('all_questions')}")
            
            # Show all questions from this quiz set
            for i, question in enumerate(quiz['questions']):
                is_correct = question['correct']
                question_text = question['question']
                user_answer = question['selected_answer']
                correct_answer = question['correct_answer']
                
                # Different styling based on correctness
                if is_correct:
                    with st.expander(f"{get_translation('question')} {i+1}: ✓ {question_text}", expanded=i==0):
                        # User answer was correct
                        st.success(f"{get_translation('your_answer')}: **{user_answer}** ✓")
                        
                        # Always display all original options if available from full_question
                        if 'full_question' in question and 'options' in question['full_question']:
                            st.markdown("#### " + get_translation('all_options'))
                            options = question['full_question']['options']
                            
                            # Display all original options with highlighting for correct answer
                            for j, option in enumerate(options):
                                if option == correct_answer:
                                    st.markdown(f"- **{option}** ✓")
                                else:
                                    st.markdown(f"- {option}")
                        
                        # First check if we have the element in the full_question
                        element = None
                        if 'full_question' in question and 'element' in question['full_question']:
                            element = question['full_question']['element']
                        
                        # If not found, try to find by answer
                        if not element:
                            element = _find_element_by_answer(correct_answer)
                        
                        # Display element information if found
                        if element:
                            # Show element info
                            _display_element_info(element, i)
                else:
                    # Incorrect answers are expanded by default
                    with st.expander(f"{get_translation('question')} {i+1}: ✗ {question_text}", expanded=True):
                        # Show user's incorrect answer
                        st.error(f"{get_translation('your_answer')}: **{user_answer}** ✗")
                        st.success(f"{get_translation('correct_answer')}: **{correct_answer}**")
                        
                        # Always display all original options if available from full_question
                        if 'full_question' in question and 'options' in question['full_question']:
                            st.markdown("#### " + get_translation('all_options'))
                            options = question['full_question']['options']
                            
                            # Display all original options with highlighting
                            for j, option in enumerate(options):
                                if option == correct_answer:
                                    st.markdown(f"- **{option}** ✓")
                                elif option == user_answer:
                                    st.markdown(f"- ~~{option}~~ ✗")
                                else:
                                    st.markdown(f"- {option}")
                        
                        # First check if we have the element in the full_question
                        element = None
                        if 'full_question' in question and 'element' in question['full_question']:
                            element = question['full_question']['element']
                        
                        # If not found, try to find by answer
                        if not element:
                            element = _find_element_by_answer(correct_answer)
                        
                        # Display element information if found
                        if element:
                            # Show element info
                            _display_element_info(element, i)
            
            # Back button at bottom
            st.markdown("---")
            if st.button(f"← {get_translation('back_to_list')}", key="history_back_btn_bottom", use_container_width=True):
                st.session_state.quiz_history_viewing = None
                st.rerun()
                
            # Take a new quiz button
            if st.button(get_translation("take_a_quiz"), key="take_quiz_from_history_detail", use_container_width=True):
                st.session_state.page = "quiz"
                st.rerun()
        else:
            st.error(get_translation("invalid_quiz_selection"))
            if st.button(get_translation("back_to_history"), key="history_fallback_back"):
                st.session_state.quiz_history_viewing = None
                st.rerun()

def _find_element_by_answer(answer):
    """Helper function to find an element or particle based on the answer text"""
    
    # Determine if we're looking for a chemical element or standard model particle based on current topic
    if st.session_state.current_topic == "Chemical Elements":
        from data.elements import search_elements
        
        # Try searching directly
        elements = search_elements(answer)
        if elements:
            return elements[0]
        
        # Try to find by symbol if the answer looks like a symbol
        if len(answer) <= 3:
            element = get_element_by_symbol(answer)
            if element:
                return element
                
        # Try to find by name
        element = get_element_by_name(answer)
        if element:
            return element
    
    else:  # Standard Model particles
        from data.standard_model.particles import search_particles
        
        # Try searching directly
        particles = search_particles(answer)
        if particles:
            return particles[0]
        
        # Try to find by symbol
        particle = get_particle_by_symbol(answer)
        if particle:
            return particle
            
        # Try to find by name
        particle = get_particle_by_name(answer)
        if particle:
            return particle
            
    return None

def _display_element_info(element, question_index):
    """Helper function to display element or particle information in quiz history"""
    
    # Check if this is a chemical element or particle
    if st.session_state.current_topic == "Chemical Elements":
        # Get element display name 
        display_name = get_display_name(element)
        
        # Element header
        st.markdown("### " + get_translation("element_information"))
        
        # Element properties in columns
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.markdown(f"""
            <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                <h3 style="margin-top: 0; color: #2B83BA;">{display_name}</h3>
                <div style="display: flex; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 200px; margin-right: 20px;">
                        <p><strong>{get_translation("symbol")}:</strong> {element['symbol']}</p>
                        <p><strong>{get_translation("atomic_number")}:</strong> {element['atomic_number']}</p>
                    </div>
                    <div style="flex: 1; min-width: 200px;">
                        <p><strong>{get_translation("category")}:</strong> {element['category'].capitalize()}</p>
                        <p><strong>{get_translation("electron_configuration")}:</strong> {element['electron_configuration']}</p>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            # Button to view full element details in the periodic table
            if st.button(get_translation("view_element_info"), key=f"history_view_elem_{question_index}", use_container_width=True):
                st.session_state.selected_element = element
                # Navigate to periodic table instead of element details
                st.session_state.page = "periodic_table"
                # Mark the element for highlighting in the periodic table
                st.session_state.highlight_element = element['atomic_number']
                # Make sure element description is shown
                st.session_state.current_element_description = element
                st.session_state.show_element_description = True
                st.rerun()
        
        # Always display element description regardless of quiz type
        st.markdown(f"#### {get_translation('description')}")
        
        # Show description based on language preference
        current_language = st.session_state.language if "language" in st.session_state else "English"
        
        # Always show description if available
        if current_language == "Korean" and "korean_description" in element and element["korean_description"]:
            # Show Korean description
            st.markdown(element["korean_description"])
        elif "description" in element and element["description"]:
            # Show English description
            st.markdown(element["description"])
        else:
            # Handle case where description might be missing
            st.info(get_translation("no_description_available") if "no_description_available" in st.session_state.translations[current_language] 
                    else "No description available for this element.")
    
    else:  # Standard Model particles
        # Particle header
        st.markdown(f"### Particle Information")
        
        # Get color for this category
        from data.standard_model.particles import get_particle_color
        color = get_particle_color(element['category'])
        
        # Particle properties with Wikipedia-like styling
        with st.container():
            # Title with background color based on category
            st.markdown(
                f"""<div style="background-color: {color}; padding: 0.5rem; border-radius: 5px 5px 0 0;">
                <h3 style="margin: 0; color: white; text-align: center;">{element['name']} ({element['symbol']})</h3>
                </div>""",
                unsafe_allow_html=True
            )
            
            # Main content with light background
            with st.container():
                st.markdown(
                    f"""<div style="border: 1px solid {color}; border-top: none; padding: 1rem; 
                    border-radius: 0 0 5px 5px; background-color: rgba({int(color[1:3], 16)}, 
                    {int(color[3:5], 16)}, {int(color[5:7], 16)}, 0.05);">""",
                    unsafe_allow_html=True
                )
                
                # Two-column layout for properties
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown(f"**Category:** {element['category'].capitalize()}")
                    st.markdown(f"**Charge:** {element['charge']}")
                    
                    # Add generation if it exists
                    if 'generation' in element:
                        st.markdown(f"**Generation:** {element['generation']}")
                
                with col2:
                    st.markdown(f"**Mass:** {element['mass']}")
                    st.markdown(f"**Spin:** {element['spin']}")
                    
                    # Add force if it exists and is not None
                    if 'force' in element and element['force'] is not None:
                        st.markdown(f"**Force:** {element['force']}")
                
                # Description section
                st.markdown("<hr style='margin: 0.5rem 0;'>", unsafe_allow_html=True)
                st.markdown("#### Description")
                st.markdown(element['description'])
                
                # Close the div for styling
                st.markdown("</div>", unsafe_allow_html=True)