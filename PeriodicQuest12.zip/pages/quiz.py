"""
Quiz page module for the Chemical Elements Explorer.
"""

import streamlit as st
import random
import time
import plotly.graph_objects as go
from utils.quiz import QuizGenerator, evaluate_answer, get_quiz_statistics, reset_quiz_statistics

def render():
    """Render the quiz page"""
    # Determine if we're in Chemical Elements or Custom Learning topic
    if st.session_state.current_topic == "Chemical Elements":
        st.title("Chemical Elements Quiz 🧪")
        quiz_type = "elements"
    else:
        st.title("Custom Learning Quiz 📚")
        quiz_type = "custom"
    
    # Initialize quiz state if not already done
    if "current_question" not in st.session_state:
        st.session_state.current_question = None
    if "answered" not in st.session_state:
        st.session_state.answered = False
    if "selected_answer" not in st.session_state:
        st.session_state.selected_answer = None
    if "quiz_mode" not in st.session_state:
        st.session_state.quiz_mode = "multiple_choice"
    if "quiz_in_progress" not in st.session_state:
        st.session_state.quiz_in_progress = False
    if "quiz_length" not in st.session_state:
        st.session_state.quiz_length = 10  # Default quiz length
    if "quiz_difficulty" not in st.session_state:
        st.session_state.quiz_difficulty = "easy"  # Default difficulty
    if "current_quiz_count" not in st.session_state:
        st.session_state.current_quiz_count = 0
    if "current_quiz_results" not in st.session_state:
        st.session_state.current_quiz_results = []
    if "quiz_history" not in st.session_state:
        st.session_state.quiz_history = []
    if "completed_quizzes" not in st.session_state:
        st.session_state.completed_quizzes = []
    if "quiz_tab" not in st.session_state:
        st.session_state.quiz_tab = "start"  # start, solve, or results
    if "question_index" not in st.session_state:
        st.session_state.question_index = 0  # Current question index
    if "quiz_questions" not in st.session_state:
        st.session_state.quiz_questions = []  # Storage for generated questions
    
    # Quiz settings and controls
    with st.expander("Quiz Settings and Statistics", expanded=True):
        stats = get_quiz_statistics()
        
        # Initialize range_type to avoid unbound variable issues
        range_type = "All Elements"

        # Quiz mode selection
        st.subheader("Quiz Mode")
        
        # Answer input mode selection
        quiz_mode = st.radio(
            "Select answer input mode:",
            ["Multiple Choice", "Text Input"],
            index=0 if st.session_state.quiz_mode == "multiple_choice" else 1,
            help="Choose between multiple choice questions or typing your answers"
        )
        
        if quiz_mode == "Multiple Choice":
            st.session_state.quiz_mode = "multiple_choice"
        else:
            st.session_state.quiz_mode = "text_input"
        
        # Quiz type selection
        st.subheader("Quiz Content")
        if "quiz_type" not in st.session_state:
            st.session_state.quiz_type = "all"
            
        # Different quiz options based on topic type
        if quiz_type == "elements":
            # Element quizzes
            quiz_content = st.selectbox(
                "Select quiz content type:",
                ["All Topics", "Atomic Numbers", "Element Symbols", "Element Names", "Element Categories"],
                help="Choose what type of questions to include in the quiz"
            )
            
            quiz_type_mapping = {
                "All Topics": "all",
                "Atomic Numbers": "atomic_number",
                "Element Symbols": "symbol",
                "Element Names": "name",
                "Element Categories": "category"
            }
            
            st.session_state.quiz_type = quiz_type_mapping[quiz_content]
        else:
            # Custom topic quizzes
            from utils.custom_content import get_custom_topics, get_custom_quizzes
            
            # Get user's custom topics for quiz selection
            custom_topics = get_custom_topics()
            if not custom_topics:
                st.info("You don't have any custom topics yet. Create a topic first to generate quizzes.")
            else:
                # Format topics for selection
                topic_options = ["All Topics"] + [f"{topic['icon']} {topic['title']}" for topic in custom_topics]
                
                selected_topic = st.selectbox(
                    "Select custom topic for quiz:",
                    options=topic_options,
                    help="Choose which custom topic to generate questions about"
                )
                
                if selected_topic == "All Topics":
                    st.session_state.custom_quiz_topic_id = None
                else:
                    # Find the selected topic
                    selected_index = topic_options.index(selected_topic) - 1  # Adjust for "All Topics"
                    if 0 <= selected_index < len(custom_topics):
                        selected_topic_data = custom_topics[selected_index]
                        st.session_state.custom_quiz_topic_id = selected_topic_data["id"]
                        
                        # Show available quizzes for this topic if any
                        topic_quizzes = get_custom_quizzes(topic_id=selected_topic_data["id"])
                        if topic_quizzes:
                            st.success(f"Found {len(topic_quizzes)} quiz(es) for this topic!")
                            quiz_select_options = ["Generate New Quiz"] + [f"{q['title']}" for q in topic_quizzes]
                            
                            selected_quiz = st.selectbox(
                                "Select existing quiz or create new:",
                                options=quiz_select_options,
                                help="Choose an existing quiz or generate a new one"
                            )
                            
                            if selected_quiz != "Generate New Quiz":
                                # Find the selected quiz
                                quiz_index = quiz_select_options.index(selected_quiz) - 1  # Adjust for "Generate New Quiz"
                                if 0 <= quiz_index < len(topic_quizzes):
                                    selected_quiz_data = topic_quizzes[quiz_index]
                                    st.session_state.custom_quiz_id = selected_quiz_data["id"]
                                    st.info(f"Selected quiz: {selected_quiz_data['title']} ({selected_quiz_data.get('difficulty', 'medium')} difficulty)")
                        else:
                            st.info("No quizzes found for this topic. A new quiz will be generated when you start.")
        
        # Quiz difficulty selection - prominently displayed between question type and quiz history
        st.markdown("---")
        st.subheader("Quiz Difficulty")
        
        # Use radio buttons for difficulty selection instead of buttons for better visibility
        difficulty_options = ["Easy", "Medium", "Hard"]
        difficulty_descriptions = {
            "Easy": "Simpler questions using beginner descriptions with more generous ranges for numerical questions.",
            "Medium": "Balanced questions using standard descriptions with moderate ranges for numerical questions.",
            "Hard": "Challenging questions using advanced descriptions with precise ranges for numerical questions."
        }
        
        # Convert session state value to title case for matching with options
        current_difficulty = st.session_state.quiz_difficulty.title()
        
        # Create the radio selection
        selected_difficulty = st.radio(
            "Choose how challenging the quiz should be:",
            difficulty_options,
            index=difficulty_options.index(current_difficulty) if current_difficulty in difficulty_options else 0,
            horizontal=True,
            help="Select difficulty level - affects question types and descriptions shown"
        )
        
        # Update session state if selection changed
        if selected_difficulty.lower() != st.session_state.quiz_difficulty:
            st.session_state.quiz_difficulty = selected_difficulty.lower()
        
        # Display description of the current difficulty level with a colored box based on difficulty
        difficulty_colors = {"Easy": "green", "Medium": "orange", "Hard": "red"}
        
        st.markdown(f"""
        <div style="padding: 10px; border-radius: 5px; border-left: 5px solid {difficulty_colors[selected_difficulty]}; background-color: rgba({', '.join(['144, 238, 144, 0.2' if selected_difficulty == 'Easy' else '255, 165, 0, 0.2' if selected_difficulty == 'Medium' else '255, 99, 71, 0.2'])});">
            <strong>{selected_difficulty} Mode:</strong> {difficulty_descriptions[selected_difficulty]}
        </div>
        """, unsafe_allow_html=True)
        
        # Element range selection - only for Chemical Elements quizzes
        if quiz_type == "elements":
            st.markdown("---")
            st.subheader("Element Range")
            
            # Range type selection
            range_type = st.radio(
                "Filter elements by:",
                ["All Elements", "Atomic Number Range", "Element Category"],
                help="Choose how to filter the elements included in the quiz"
            )
        
        # Only process range selections for chemical elements quiz
        if quiz_type == "elements" and range_type == "Atomic Number Range":
            # Get min and max atomic numbers from the database
            from data.elements import elements_df
            min_atomic = int(elements_df['atomic_number'].min())
            max_atomic = int(elements_df['atomic_number'].max())
            
            # Two options for selecting atomic number range
            range_selection_method = st.radio(
                "Select range method:",
                ["Use Slider", "Enter Specific Numbers"],
                horizontal=True,
                help="Choose how you want to specify the atomic number range"
            )
            
            if range_selection_method == "Use Slider":
                # Atomic number range slider
                atomic_range = st.slider(
                    "Select atomic number range:",
                    min_atomic, max_atomic, (min_atomic, max_atomic),
                    help="Only include elements within this atomic number range"
                )
                min_value, max_value = atomic_range[0], atomic_range[1]
            else:
                # Use number input fields for precise control
                cols = st.columns(2)
                with cols[0]:
                    min_value = st.number_input(
                        "Minimum atomic number:",
                        min_value=min_atomic, 
                        max_value=max_atomic,
                        value=min_atomic,
                        help="Enter the minimum atomic number"
                    )
                with cols[1]:
                    max_value = st.number_input(
                        "Maximum atomic number:",
                        min_value=min_atomic, 
                        max_value=max_atomic,
                        value=max_atomic,
                        help="Enter the maximum atomic number"
                    )
                    
                # Ensure min doesn't exceed max
                if min_value > max_value:
                    min_value = max_value
                    st.warning("Minimum value cannot exceed maximum value. Adjusting to match.")
            
            # Show the selected range
            st.info(f"Selected range: Elements with atomic numbers from {min_value} to {max_value}")
            
            st.session_state.element_filter = {
                'type': 'atomic_range',
                'min': min_value,
                'max': max_value
            }
            
        elif quiz_type == "elements" and range_type == "Element Category":
            # Category selection
            from data.elements import CATEGORIES
            categories = list(CATEGORIES.keys())
            categories.remove('unknown')  # Remove unknown category
            
            selected_category = st.selectbox(
                "Select element category:",
                categories,
                format_func=lambda x: x.capitalize(),
                help="Only include elements from this category"
            )
            
            st.session_state.element_filter = {
                'type': 'category',
                'value': selected_category
            }
            
        else:  # All Elements
            st.session_state.element_filter = {
                'type': 'all'
            }
        
        # Reset statistics button
        if st.button("Reset Statistics"):
            reset_quiz_statistics()
            st.rerun()
        
        # Quiz History section
        st.markdown("---")
        st.subheader("Quiz History")
        if not stats['history']:
            st.info("No quiz history yet. Start answering questions!")
        else:
            for i, item in enumerate(stats['history'][-5:]):  # Show last 5 items
                if item['correct']:
                    st.success(f"✓ {item['question']}")
                else:
                    st.error(f"✗ {item['question']} (Correct: {item['correct_answer']})")
    
    # Show quiz results if a quiz was just completed
    if not st.session_state.quiz_in_progress and "latest_quiz_id" in st.session_state and st.session_state.latest_quiz_id is not None:
        if st.session_state.latest_quiz_id >= 0 and st.session_state.latest_quiz_id < len(st.session_state.completed_quizzes):
            quiz = st.session_state.completed_quizzes[st.session_state.latest_quiz_id]
            
            st.markdown("---")
            st.subheader("🎉 Quiz Completed! 🎉")
            
            # Display quiz summary in a colorful box
            score_color = "green" if quiz['percentage'] >= 80 else "orange" if quiz['percentage'] >= 60 else "red"
            st.markdown(f"""
            <div style="padding: 20px; border-radius: 10px; background-color: #f0f2f6; margin-bottom: 20px;">
                <h3 style="margin-top: 0;">Quiz Results</h3>
                <p><strong>Score:</strong> {quiz['score']}/{quiz['total']} ({quiz['percentage']}%)</p>
                <p><strong>Quiz Type:</strong> {quiz['quiz_type']}</p>
                <p><strong>Topics:</strong> {quiz['topics']}</p>
                <div style="width: 100%; height: 20px; background-color: #eee; border-radius: 10px; margin-top: 10px;">
                    <div style="width: {quiz['percentage']}%; height: 20px; background-color: {score_color}; border-radius: 10px;"></div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Show detailed results
            st.subheader("Question Details")
            
            for i, q in enumerate(quiz['questions']):
                if q['correct']:
                    with st.expander(f"Question {i+1}: ✓ Correct"):
                        st.write(f"**Question:** {q['question']}")
                        st.write(f"**Your answer:** {q['selected_answer']}")
                        st.write(f"**Correct answer:** {q['correct_answer']}")
                else:
                    with st.expander(f"Question {i+1}: ✗ Incorrect", expanded=True):
                        st.write(f"**Question:** {q['question']}")
                        st.write(f"**Your answer:** {q['selected_answer']}")
                        st.write(f"**Correct answer:** {q['correct_answer']}")
            
            # Option to start a new quiz
            if st.button("Start a New Quiz", key="new_quiz_after_results"):
                st.session_state.latest_quiz_id = None
                # Clear current quiz results
                st.session_state.current_quiz_count = 0
                st.session_state.current_quiz_results = []
                st.rerun()
    
    # Quiz Length Selection (only show when not in a quiz and not showing results)
    if not st.session_state.quiz_in_progress and (
        "latest_quiz_id" not in st.session_state or 
        st.session_state.latest_quiz_id is None
    ):
        st.markdown("---")
        st.subheader("Start a New Quiz")
        
        cols = st.columns([2, 1])
        
        with cols[0]:
            # Quiz length options
            quiz_length_options = ["10 questions", "20 questions", "Custom length"]
            quiz_length_choice = st.radio(
                "Select quiz length:", 
                quiz_length_options,
                horizontal=True,
                help="Choose how many questions you want in your quiz"
            )
            
            if quiz_length_choice == "Custom length":
                custom_length = st.number_input(
                    "Enter number of questions:", 
                    min_value=1, 
                    max_value=100, 
                    value=st.session_state.quiz_length,
                    help="Choose a custom number of questions (1-100)"
                )
                st.session_state.quiz_length = custom_length
            else:
                # Extract number from the option text
                st.session_state.quiz_length = int(quiz_length_choice.split()[0])
                
        with cols[1]:
            if st.button("Start Quiz", use_container_width=True):
                st.session_state.quiz_in_progress = True
                st.session_state.current_quiz_count = 0
                st.session_state.current_quiz_results = []
                st.session_state.answered = False
                st.rerun()
        
        # Completed quizzes section
        if st.session_state.completed_quizzes:
            st.markdown("---")
            st.subheader("Previous Quizzes")
            
            for i, quiz in enumerate(st.session_state.completed_quizzes):
                with st.expander(f"Quiz #{i+1} - Score: {quiz['score']}/{quiz['total']} ({quiz['percentage']}%)"):
                    st.write(f"**Date:** {quiz['date']}")
                    st.write(f"**Quiz Type:** {quiz['quiz_type']}")
                    st.write(f"**Topics:** {quiz['topics']}")
                    
                    # Display quiz questions and answers
                    for j, q in enumerate(quiz['questions']):
                        if q['correct']:
                            st.success(f"Q{j+1}: {q['question']} ✓")
                            st.write(f"Your answer: {q['selected_answer']}")
                        else:
                            st.error(f"Q{j+1}: {q['question']} ✗")
                            st.write(f"Your answer: {q['selected_answer']}")
                            st.write(f"Correct answer: {q['correct_answer']}")
                        st.markdown("---")
    
    # Quiz content
    st.markdown("---")
    
    # If we're in a quiz, show the current progress
    if st.session_state.quiz_in_progress:
        progress_text = f"Question {st.session_state.current_quiz_count+1} of {st.session_state.quiz_length}"
        progress = st.progress((st.session_state.current_quiz_count) / st.session_state.quiz_length)
        
        # Button to end quiz early
        if st.button("End Quiz Early"):
            if len(st.session_state.current_quiz_results) > 0:
                # Calculate results
                correct = sum(1 for r in st.session_state.current_quiz_results if r['correct'])
                total = len(st.session_state.current_quiz_results)
                percentage = round((correct / total) * 100, 1) if total > 0 else 0
                
                # Save the completed quiz
                st.session_state.completed_quizzes.append({
                    'date': time.strftime("%Y-%m-%d %H:%M"),
                    'score': correct,
                    'total': total,
                    'percentage': percentage,
                    'quiz_type': st.session_state.quiz_mode,
                    'topics': st.session_state.quiz_type,
                    'questions': st.session_state.current_quiz_results.copy()
                })
            
            # Mark quiz as completed, but don't reset results immediately
            # We'll show the quiz results first
            st.session_state.quiz_in_progress = False
            st.session_state.answered = False
            
            # Store the latest quiz ID to display
            st.session_state.latest_quiz_id = len(st.session_state.completed_quizzes) - 1
            st.rerun()
    
    if st.session_state.answered:
        # Show result of previous question
        question = st.session_state.current_question
        selected_answer = st.session_state.selected_answer
        is_correct = evaluate_answer(question, selected_answer)
        
        if is_correct:
            st.success("Correct! Well done! ✅")
        else:
            # Safe get the correct answer
            correct_answer = question.get('correct_answer', 'Unknown') if question else 'Unknown'
            st.error(f"Incorrect! The correct answer is: {correct_answer} ❌")
        
        # Show element information for the correct element (not just the question element)
        # This ensures we display the correct element details regardless of the question type
        from data.elements import get_element_by_atomic_number, get_element_by_symbol, get_element_by_name
        
        # Default to None in case we can't determine the element
        element = None
        
        # Safely check question dictionary and extract information
        if question is not None and isinstance(question, dict):
            # Get the question text and correct answer if available
            question_text = question.get('question', '').lower() if question.get('question') else ''
            correct_answer = question.get('correct_answer')
            
            if question_text and correct_answer is not None:
                # For name questions, the correct answer is the element name
                if "what is the name" in question_text:
                    element = get_element_by_name(correct_answer)
                # For symbol questions, the correct answer is the element symbol
                elif "what is the symbol" in question_text:
                    element = get_element_by_symbol(correct_answer)
                # For atomic number questions, the correct answer is the atomic number
                elif "atomic number" in question_text:
                    element = get_element_by_atomic_number(correct_answer)
            
            # If we still don't have an element, try to get it from the question
            if element is None and 'element' in question:
                element = question.get('element')
            
        # Validate element before displaying to avoid errors
        if element:
            with st.expander(f"Learn more about {element['name']}", expanded=True):
                col1, col2 = st.columns([1, 2])
                
                with col1:
                    st.markdown(f"""
                    ### {element['name']} ({element['symbol']})
                    **Atomic Number:** {element['atomic_number']}  
                    **Category:** {element['category'].capitalize()}  
                    """)
                
                with col2:
                    st.markdown(f"""
                    **Electron Configuration:** {element['electron_configuration']}  
                    **Period:** {element['period']}  
                    **Group:** {element['group'] if element['group'] is not None else 'N/A'}  
                    
                    {element['description'][:200]}...
                    """)
        
        # Option to view full element details
        if st.button("View Full Element Details"):
            st.session_state.selected_element = element
            st.session_state.page = "element_details"
            st.rerun()
        
        # Button to get next question
        if st.button("Next Question", key="next_question"):
            st.session_state.answered = False
            st.session_state.selected_answer = None
            st.rerun()
    
    else:
        # Generate and show a new question
        quiz_generator = QuizGenerator(
            quiz_mode=st.session_state.quiz_mode,
            quiz_type=st.session_state.quiz_type,
            element_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
            difficulty=st.session_state.quiz_difficulty
        )
        question = quiz_generator.generate_question()
        st.session_state.current_question = question
        
        st.subheader(question['question'])
        
        if st.session_state.quiz_mode == "multiple_choice":
            # Display options as buttons
            for i, option in enumerate(question['options']):
                if st.button(f"{chr(65+i)}. {option}", key=f"option_{i}", use_container_width=True):
                    st.session_state.selected_answer = option
                    st.session_state.answered = True
                    
                    # Store result
                    is_correct = evaluate_answer(question, option)
                    
                    result = {
                        'question': question['question'],
                        'selected_answer': option,
                        'correct_answer': question['correct_answer'],
                        'correct': is_correct
                    }
                    
                    # Add result to current quiz results
                    st.session_state.current_quiz_results.append(result)
                    
                    # Increment quiz count
                    st.session_state.current_quiz_count += 1
                    
                    # Check if quiz is complete
                    if st.session_state.current_quiz_count >= st.session_state.quiz_length:
                        # Calculate results
                        correct = sum(1 for r in st.session_state.current_quiz_results if r['correct'])
                        total = len(st.session_state.current_quiz_results)
                        percentage = round((correct / total) * 100, 1) if total > 0 else 0
                        
                        # Save the completed quiz
                        st.session_state.completed_quizzes.append({
                            'date': time.strftime("%Y-%m-%d %H:%M"),
                            'score': correct,
                            'total': total,
                            'percentage': percentage,
                            'quiz_type': st.session_state.quiz_mode,
                            'topics': st.session_state.quiz_type,
                            'questions': st.session_state.current_quiz_results.copy()
                        })
                        
                        # Mark quiz as completed
                        st.session_state.quiz_in_progress = False
                        
                        # Store the latest quiz ID to display
                        st.session_state.latest_quiz_id = len(st.session_state.completed_quizzes) - 1
                    
                    st.rerun()
                    
        else:  # Text input mode
            # Allow user to enter their answer
            with st.form("quiz_answer_form"):
                user_answer = st.text_input("Enter your answer:")
                
                submitted = st.form_submit_button("Submit Answer")
                if submitted:
                    st.session_state.selected_answer = user_answer
                    st.session_state.answered = True
                    
                    # Store result (normalize both to lowercase for comparison)
                    is_correct = evaluate_answer(question, user_answer)
                    
                    result = {
                        'question': question['question'],
                        'selected_answer': user_answer,
                        'correct_answer': question['correct_answer'],
                        'correct': is_correct
                    }
                    
                    # Add result to current quiz results
                    st.session_state.current_quiz_results.append(result)
                    
                    # Increment quiz count
                    st.session_state.current_quiz_count += 1
                    
                    # Check if quiz is complete
                    if st.session_state.current_quiz_count >= st.session_state.quiz_length:
                        # Calculate results
                        correct = sum(1 for r in st.session_state.current_quiz_results if r['correct'])
                        total = len(st.session_state.current_quiz_results)
                        percentage = round((correct / total) * 100, 1) if total > 0 else 0
                        
                        # Save the completed quiz
                        st.session_state.completed_quizzes.append({
                            'date': time.strftime("%Y-%m-%d %H:%M"),
                            'score': correct,
                            'total': total,
                            'percentage': percentage,
                            'quiz_type': st.session_state.quiz_mode,
                            'topics': st.session_state.quiz_type,
                            'questions': st.session_state.current_quiz_results.copy()
                        })
                        
                        # Mark quiz as completed
                        st.session_state.quiz_in_progress = False
                        
                        # Store the latest quiz ID to display
                        st.session_state.latest_quiz_id = len(st.session_state.completed_quizzes) - 1
                    
                    st.rerun()