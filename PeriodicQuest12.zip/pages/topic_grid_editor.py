"""
Topic Grid Editor module for the Science Learning Platform.
This module provides a grid-like interface for editing topic entities and their aspects
in a spreadsheet-like format.
"""
import streamlit as st
import pandas as pd
import uuid
from datetime import datetime
from typing import Dict, List, Any, Optional

from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.topic_builder import (
    create_topic_structure, save_topic, load_topic, delete_topic,
    get_user_topics, get_all_topics, add_entity, update_entity, delete_entity,
    add_property, update_property, delete_property, get_entity_by_id,
    search_entities, generate_quiz_questions, ENTITY_TEMPLATES, PROPERTY_TYPES, CUSTOM_TOPICS_DIR
)

def render():
    """Render the topic grid editor page"""
    st.title("🔢 " + get_translation("topic_grid_editor", "Entity & Quiz Editor"))
    
    # Add back button in sidebar for easier navigation
    with st.sidebar:
        if st.button("↩️ " + get_translation("back_to_home", "Back to Home"), key="back_to_home_sidebar", use_container_width=True):
            st.session_state.page = "home"
            st.rerun()
    
    # Check if user is logged in
    if not is_logged_in():
        st.warning(get_translation("login_required", "You need to log in to create or manage topics."))
        
        # Add a button to go to the login page
        if st.button(get_translation("go_to_login", "Go to Login Page"), use_container_width=True):
            st.session_state.page = "login"
            st.rerun()
        return
    
    # Initialize session state for this page
    if "topic_grid_tab" not in st.session_state:
        st.session_state.topic_grid_tab = "entity_grid"
    if "selected_topic_id" not in st.session_state:
        st.session_state.selected_topic_id = None
    if "entity_grid_view" not in st.session_state:
        st.session_state.entity_grid_view = "table"  # "table" or "cards"
    if "editing_aspect_id" not in st.session_state:
        st.session_state.editing_aspect_id = None
        
    # First, select a topic
    topic_id = render_topic_selector()
    
    if not topic_id:
        st.info(get_translation("select_topic", "Please select a topic to edit its entities and aspects."))
        return
    
    # Load the selected topic
    topic = load_topic(topic_id)
    
    if not topic:
        st.error(get_translation("topic_not_found", "Topic not found."))
        st.session_state.selected_topic_id = None
        st.rerun()
        return
    
    # Display the topic title
    st.header(f"{topic.get('icon', '📚')} {topic.get('title', 'Unnamed Topic')}")
    
    # Create tabs for different editor views
    tabs = st.tabs([
        "📋 " + get_translation("aspects", "Aspects"),
        "📊 " + get_translation("entity_grid", "Entity Grid"),
        "📑 " + get_translation("quiz_settings", "Quiz Settings")
    ])
    
    # Determine which tab is active
    if st.session_state.topic_grid_tab == "aspects":
        active_tab = 0
    elif st.session_state.topic_grid_tab == "entity_grid":
        active_tab = 1
    elif st.session_state.topic_grid_tab == "quiz":
        active_tab = 2
    else:
        # If coming from the topic builder specifically to add aspects
        if st.session_state.get("show_aspects_first", False):
            active_tab = 0  # Default to aspects management
            st.session_state.topic_grid_tab = "aspects"
            st.session_state.show_aspects_first = False  # Reset flag
        else:
            active_tab = 1  # Default to entity grid for other cases
    
    # Check if we're in aspect editor mode
    in_aspect_editor = st.session_state.get("editing_aspect_id") is not None
    
    # If in aspect editor mode, show a notification and quick navigation
    if in_aspect_editor:
        col1, col2 = st.columns(2)
        with col1:
            st.info(get_translation("editing_aspect", "You are currently editing an aspect. Use the tabs to switch views."))
        
        # Add buttons to cancel editing or switch to grid
        with col2:
            c1, c2 = st.columns(2)
            with c1:
                if st.button("🔙 " + get_translation("cancel_editing", "Cancel Editing"), use_container_width=True):
                    st.session_state.editing_aspect_id = None
                    st.rerun()
            with c2:
                if st.button("📊 " + get_translation("return_to_grid", "Return to Grid"), use_container_width=True):
                    st.session_state.editing_aspect_id = None
                    st.session_state.topic_grid_tab = "entity_grid"
                    st.rerun()
    
    # Render the active tab content
    with tabs[active_tab]:
        if active_tab == 0:
            render_aspect_management(topic)
            st.session_state.topic_grid_tab = "aspects"
        elif active_tab == 1:
            # If editing an aspect, show an option to continue editing in this view
            if in_aspect_editor:
                with st.expander("Continue Editing Aspect", expanded=True):
                    render_aspect_editor(topic)
                    
                    if st.button(get_translation("save_continue", "Save & Continue to Grid"), 
                                key="save_continue_grid", type="primary", use_container_width=True):
                        # This will be handled by the form submit logic in the aspect editor
                        pass
                        
                # Add a separator before showing the grid
                st.divider()
                
            # Always render the entity grid in this tab
            render_entity_grid(topic)
            st.session_state.topic_grid_tab = "entity_grid"
        elif active_tab == 2:
            # If editing an aspect, show an option to continue editing in this view
            if in_aspect_editor:
                with st.expander("Continue Editing Aspect", expanded=True):
                    render_aspect_editor(topic)
                    
                    if st.button(get_translation("save_continue", "Save & Continue to Quiz Settings"), 
                                key="save_continue_quiz", type="primary", use_container_width=True):
                        # This will be handled by the form submit logic in the aspect editor
                        pass
                
                # Add a separator before showing the quiz settings
                st.divider()
                
            render_quiz_settings(topic)
            st.session_state.topic_grid_tab = "quiz"
            
def render_topic_selector():
    """Render a dropdown to select a topic"""
    # Get the current user's topics
    username = get_current_user()
    topics = get_user_topics(username)
    
    if not topics:
        st.warning(get_translation("no_topics", "You don't have any topics yet."))
        
        # Add a button to create a new topic
        if st.button(get_translation("create_topic", "Create a New Topic"), use_container_width=True):
            st.session_state.page = "topic_builder"
            st.session_state.topic_builder_tab = "create_topic"
            st.rerun()
        return None
    
    # Create a selectbox for topics
    topic_options = [f"{t.get('icon', '📚')} {t.get('title', 'Unnamed Topic')}" for t in topics]
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        selected_index = topic_options.index(f"{topics[0].get('icon', '📚')} {topics[0].get('title', 'Unnamed Topic')}") if st.session_state.selected_topic_id is None else next((i for i, t in enumerate(topics) if t.get("id") == st.session_state.selected_topic_id), 0)
        selected_topic = st.selectbox(
            get_translation("select_topic", "Select a Topic"),
            options=topic_options,
            index=selected_index
        )
    
    with col2:
        # Add a button to create a new topic
        if st.button(get_translation("create_topic", "Create Topic"), use_container_width=True):
            st.session_state.page = "topic_builder"
            st.session_state.topic_builder_tab = "create_topic"
            st.rerun()
    
    # Get the selected topic's ID
    selected_index = topic_options.index(selected_topic)
    selected_topic_id = topics[selected_index].get("id")
    
    # Store the selected topic ID in session state
    st.session_state.selected_topic_id = selected_topic_id
    
    return selected_topic_id

def render_aspect_management(topic):
    """Render the aspect management page"""
    st.subheader(get_translation("aspects_management", "Aspects Management"))
    
    properties = topic.get("properties", [])
    entity_name_singular = topic.get("entity_name_singular", "Item")
    
    # Add a detailed explanation of aspects and how they work
    with st.container(border=True):
        st.markdown("### " + get_translation("about_aspects", "Understanding Aspects"))
        
        # Basic explanation
        st.markdown(get_translation(
            "aspect_note", 
            f"""
            **Aspects** define the properties that all {entity_name_singular}s will have. They are like columns in a spreadsheet.
            
            - When you add a new aspect, it will be added to all {entity_name_singular}s
            - When you remove an aspect, it will be removed from all {entity_name_singular}s
            """
        ))
        
        # Add explanation about quiz functionality
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### " + get_translation("quiz_questions", "Quiz Questions"))
            st.markdown(get_translation("question_usage", """
            Mark an aspect as **Use as quiz question** to make questions like:
            
            *"What is the [other aspect] of the [entity] whose [this aspect] is [value]?"*
            
            Example: "What is the symbol of the element whose atomic number is 6?"
            """))
            
        with col2:
            st.markdown("#### " + get_translation("quiz_options", "Quiz Options"))
            st.markdown(get_translation("option_usage", """
            Mark an aspect as **Use as quiz option** to use its values as answer choices.
            
            Add **Bait Values** to create custom wrong answers instead of using values from other entities.
            
            Example: For "State of Matter", bait values might be "Plasma" or "Superfluid"
            """))
    
    # Add a prominent button to add a new property
    col1, col2 = st.columns([3, 1])
    with col2:
        if st.button(get_translation("add_aspect", "Add New Aspect"), 
                    key="add_new_aspect", 
                    use_container_width=True,
                    type="primary"):
            st.session_state.editing_aspect_id = "new"
            st.rerun()
    
    with col1:
        st.markdown("#### " + get_translation("existing_aspects", "Current Aspects"))
        if not properties:
            st.caption(get_translation("no_aspects_yet", "No aspects defined yet. Click 'Add New Aspect' to create one."))
    
    # Display the existing properties in a grid layout
    if properties:
        for i in range(0, len(properties), 2):
            cols = st.columns(2)
            
            for j in range(2):
                if i + j < len(properties):
                    prop = properties[i + j]
                    prop_id = prop.get("id", "")
                    prop_name = prop.get("name", "")
                    prop_type = prop.get("type", "text")
                    prop_description = prop.get("description", "")
                    prop_options = prop.get("options", [])
                    
                    with cols[j]:
                        # Create a card for the property
                        with st.container(border=True):
                            st.subheader(prop_name)
                            st.caption(f"Type: {prop_type}")
                            st.write(prop_description if prop_description else "-")
                            
                            if prop_type == "select" and prop_options:
                                st.write("Options: " + ", ".join(prop_options))
                            
                            # Add buttons for editing and deleting
                            col1, col2 = st.columns(2)
                            with col1:
                                if st.button(get_translation("edit", "Edit"), key=f"edit_prop_{prop_id}", use_container_width=True):
                                    st.session_state.editing_aspect_id = prop_id
                                    st.rerun()
                            
                            with col2:
                                if st.button(get_translation("delete", "Delete"), key=f"delete_prop_{prop_id}", use_container_width=True):
                                    # Confirm deletion
                                    if st.session_state.get(f"confirm_delete_prop_{prop_id}", False):
                                        # Remove the property from the topic and from all entities
                                        properties = [p for p in properties if p.get("id") != prop_id]
                                        topic["properties"] = properties
                                        
                                        # Also remove the property from all entities
                                        entities = topic.get("entities", [])
                                        for entity in entities:
                                            if "values" in entity and prop_id in entity["values"]:
                                                del entity["values"][prop_id]
                                        
                                        topic["entities"] = entities
                                        
                                        # Save the topic
                                        if save_topic(topic):
                                            st.success(get_translation("property_deleted", "Aspect deleted successfully."))
                                            st.rerun()
                                        else:
                                            st.error(get_translation("property_delete_error", "Failed to delete aspect."))
                                    else:
                                        st.session_state[f"confirm_delete_prop_{prop_id}"] = True
                                        st.warning(get_translation("confirm_delete", "Click delete again to confirm."))
                                        st.rerun()
    
    # If editing a property, display the property editor
    if st.session_state.editing_aspect_id:
        render_aspect_editor(topic)

def render_aspect_editor(topic):
    """Render the property editor form"""
    properties = topic.get("properties", [])
    
    # If creating a new property
    if st.session_state.editing_aspect_id == "new":
        prop = {"id": f"prop_{uuid.uuid4().hex[:8]}", "name": "", "type": "text", "description": "", "options": []}
        editor_title = get_translation("new_aspect", "Create New Aspect")
    else:
        # Find the property being edited
        prop = next((p for p in properties if p.get("id") == st.session_state.editing_aspect_id), None)
        editor_title = get_translation("edit_aspect", "Edit Aspect")
    
    if not prop:
        st.error(get_translation("property_not_found", "Aspect not found."))
        st.session_state.editing_aspect_id = None
        st.rerun()
        return
    
    # Create the property editor form with improved styling
    with st.container(border=True):
        st.subheader(editor_title)
        
        with st.form(key=f"edit_property_{prop.get('id')}_form"):
            # Basic information section
            st.markdown("### " + get_translation("basic_info", "Basic Information"))
            
            # Property name
            prop_name = st.text_input(
                get_translation("property_name", "Aspect Name"),
                value=prop.get("name", ""),
                placeholder="Enter a descriptive name like 'Color' or 'Weight'"
            )
            
            # Property description
            prop_description = st.text_area(
                get_translation("property_description", "Description"),
                value=prop.get("description", ""),
                height=100,
                placeholder="Explain what this aspect represents and how it should be used"
            )
            
            # Data type section
            st.markdown("### " + get_translation("data_type", "Data Type"))
            
            # Property type
            property_types = [
                ("text", "Text"),
                ("number", "Number"),
                ("textarea", "Long Text"),
                ("boolean", "Yes/No"),
                ("select", "Select from options"),
                ("color", "Color Picker")
            ]
            
            property_type_options = [t[0] for t in property_types]
            property_type_labels = [t[1] for t in property_types]
            
            current_type = prop.get("type", "text")
            current_type_index = property_type_options.index(current_type) if current_type in property_type_options else 0
            
            prop_type = st.selectbox(
                get_translation("property_type", "Aspect Type"),
                options=property_type_labels,
                index=current_type_index,
                format_func=lambda x: x
            )
            
            selected_type = property_type_options[property_type_labels.index(prop_type)]
            
            # If type is select, show options editor
            options = prop.get("options", [])
            if selected_type == "select":
                st.markdown("#### " + get_translation("select_options", "Select Options"))
                st.caption(get_translation("options_help", "Enter one option per line"))
                
                option_text = st.text_area(
                    get_translation("options", "Options"),
                    value="\n".join(options) if options else "",
                    height=150,
                    placeholder="Red\nGreen\nBlue"
                )
                
                # Parse options from text
                new_options = [opt.strip() for opt in option_text.split("\n") if opt.strip()]
            else:
                new_options = []
            
            # Quiz settings for this property
            st.markdown("### " + get_translation("quiz_settings", "Quiz Settings"))
            st.caption(get_translation("quiz_settings_help", "Determine how this aspect will be used in quizzes"))
            
            use_as_question = st.checkbox(
                get_translation("use_as_question", "Use as quiz question"),
                value=prop.get("use_as_question", False)
            )
            
            use_as_option = st.checkbox(
                get_translation("use_as_option", "Use as quiz option"),
                value=prop.get("use_as_option", False)
            )
            
            # Bait values for incorrect options
            if use_as_option:
                st.markdown("#### " + get_translation("bait_values", "Bait Values (Custom Wrong Options)"))
                
                # Enhanced description of bait values with example
                with st.container(border=True):
                    st.markdown(get_translation("bait_description_improved", """
                    **Bait values** are custom incorrect options that will be used in quizzes.
                    
                    For example, if this aspect is 'Color' and possible values are 'Red', 'Blue', 'Green', you might add bait values like:
                    - Yellow
                    - Purple
                    - Orange
                    
                    This gives you control over what incorrect options students see, instead of random values from other entities.
                    """))
                
                # Add examples for different property types
                prop_type = prop.get("type", "text")
                if prop_type == "number":
                    example = "For numeric fields, add numbers outside the normal range, e.g., 999, -42"
                elif prop_type == "select":
                    example = "Add options that aren't in your selection list but could be plausible"
                else:
                    example = "Enter believable but incorrect values, one per line"
                
                bait_text = st.text_area(
                    get_translation("bait_values", "Bait Values"),
                    value="\n".join(prop.get("bait_values", [])) if prop.get("bait_values", []) else "",
                    height=150,
                    placeholder=example
                )
                
                # Parse bait values from text
                bait_values = [bait.strip() for bait in bait_text.split("\n") if bait.strip()]
                
                # Show a preview of how bait values will be used
                if bait_values:
                    st.success(get_translation("bait_preview", f"✓ {len(bait_values)} custom incorrect options will be used in quizzes"))
            else:
                bait_values = []
                # Show note that no bait values will be used since this aspect isn't for options
                if prop.get("bait_values"):
                    st.info(get_translation("bait_disabled", "Existing bait values will be preserved but not used in quizzes until this aspect is marked for use as quiz options."))
            
            # Submit buttons
            st.markdown("---")
            col1, col2 = st.columns(2)
            with col1:
                cancel = st.form_submit_button(get_translation("cancel", "Cancel"), use_container_width=True)
            with col2:
                # Different button label based on where we came from
                if st.session_state.topic_grid_tab == "entity_grid":
                    save_label = get_translation("save_to_grid", "Save & Return to Grid")
                elif st.session_state.topic_grid_tab == "quiz":
                    save_label = get_translation("save_to_quiz", "Save & Return to Quiz")
                else:
                    save_label = get_translation("save", "Save")
                    
                submit = st.form_submit_button(save_label, use_container_width=True, type="primary")
        
        if submit:
            if not prop_name:
                st.error(get_translation("name_required", "Aspect name is required."))
            else:
                with st.spinner(get_translation("saving_aspect", "Saving aspect...")):
                    # Update the property
                    prop["name"] = prop_name
                    prop["description"] = prop_description
                    prop["type"] = selected_type
                    prop["use_as_question"] = use_as_question
                    prop["use_as_option"] = use_as_option
                    prop["bait_values"] = bait_values
                    
                    if selected_type == "select":
                        prop["options"] = new_options
                    
                    # If creating a new property, add it to the list
                    if st.session_state.editing_aspect_id == "new":
                        properties.append(prop)
                        
                        # Add a blank value for this property to all entities
                        entities = topic.get("entities", [])
                        for entity in entities:
                            if "values" not in entity:
                                entity["values"] = {}
                            entity["values"][prop["id"]] = ""
                        
                        topic["entities"] = entities
                    
                    # Save the properties to the topic
                    topic["properties"] = properties
                    
                    # Save the topic
                    if save_topic(topic):
                        st.success(get_translation("property_saved", "Aspect saved successfully."))
                        
                        # If we're on a tab other than aspects, stay on that tab
                        current_tab = st.session_state.topic_grid_tab
                        
                        # For new aspects, we might want to redirect based on where we came from
                        if st.session_state.editing_aspect_id == "new":
                            # If we were already on a specific tab, stay there
                            if current_tab not in ["aspects", None]:
                                st.session_state.topic_grid_tab = current_tab
                            else:
                                # Default to entity grid for new aspects
                                st.session_state.topic_grid_tab = "entity_grid"
                        else:
                            # For existing aspects, preserve the current tab
                            st.session_state.topic_grid_tab = current_tab
                            
                        # Clear the editing state
                        st.session_state.editing_aspect_id = None
                        st.rerun()
                    else:
                        st.error(get_translation("property_save_error", "Failed to save aspect."))
        
        if cancel:
            # When canceling, maintain the current tab
            current_tab = st.session_state.topic_grid_tab
            st.session_state.editing_aspect_id = None
            
            # Preserve the current tab instead of defaulting to aspects tab
            st.session_state.topic_grid_tab = current_tab
            st.rerun()

def render_entity_grid(topic):
    """Render the entity grid with editable cells"""
    st.subheader(get_translation("entity_grid", "Entity Grid"))
    
    # Get the entities and properties for the topic
    entities = topic.get("entities", [])
    properties = topic.get("properties", [])
    
    # Add quick aspect management in grid view
    col1, col2 = st.columns([3, 1])
    with col1:
        st.caption(get_translation("manage_aspects_tip", "Manage aspects directly from the grid view"))
    
    with col2:
        if st.button(get_translation("add_aspect_grid", "Add New Aspect"), key="add_aspect_grid", 
                    use_container_width=True, type="primary"):
            st.session_state.editing_aspect_id = "new"
            st.session_state.topic_grid_tab = "aspects"
            st.rerun()
            
    # Show quick aspect management panel
    if properties:
        with st.expander(get_translation("quick_aspects", "Quick Aspect Management"), expanded=False):
            st.caption(get_translation("aspects_used_quiz", "Aspects used in quizzes are marked with Q (question) and A (answer)"))
            
            # Display aspects in a grid layout for quick access
            cols = st.columns(3)
            for i, prop in enumerate(properties):
                with cols[i % 3]:
                    with st.container(border=True):
                        st.markdown(f"**{prop.get('name', '')}**")
                        st.caption(f"Type: {prop.get('type', 'text')}")
                        
                        # Show quiz usage indicators
                        quiz_settings = []
                        if prop.get("use_as_question", False):
                            quiz_settings.append("Q")
                        if prop.get("use_as_option", False):
                            quiz_settings.append("A")
                        
                        if quiz_settings:
                            st.caption(f"Quiz use: {', '.join(quiz_settings)}")
                        
                        # Edit button
                        if st.button(get_translation("edit", "Edit"), key=f"quick_edit_{prop.get('id')}", use_container_width=True):
                            st.session_state.editing_aspect_id = prop.get('id')
                            st.session_state.topic_grid_tab = "aspects"
                            st.rerun()
                
                # Limit the number of aspects shown in the quick view
                if i >= 5 and i < len(properties) - 1:
                    with cols[(i + 1) % 3]:
                        st.caption(f"+ {len(properties) - (i + 1)} more aspects")
                    break
    
    if not properties:
        st.info(get_translation("no_properties", "Please add aspects (properties) first before adding entities."))
        st.session_state.topic_grid_tab = "aspects"
        st.rerun()
        return
    
    # Add a button to add a new entity
    if st.button(get_translation("add_entity", "Add New Entity"), use_container_width=True):
        # Create a new entity ID
        entity_id = f"entity_{uuid.uuid4().hex[:8]}"
        
        # Create a basic entity structure
        new_entity = {
            "id": entity_id,
            "name": f"New {topic.get('entity_name_singular', 'Item')}",
            "description": "",
            "values": {}
        }
        
        # Add default values for each property
        for prop in properties:
            prop_id = prop.get("id")
            if prop_id:
                new_entity["values"][prop_id] = ""
        
        # Add the entity to the topic
        entities.append(new_entity)
        topic["entities"] = entities
        
        # Save the topic
        if save_topic(topic):
            st.success(get_translation("entity_added", "Entity added successfully."))
            st.rerun()
        else:
            st.error(get_translation("entity_add_error", "Failed to add entity."))
    
    # If no entities exist yet, show a message
    if not entities:
        st.info(get_translation("no_entities", "No entities have been added yet."))
        return
    
    # Create a DataFrame to display the entities and their properties
    data = []
    for entity in entities:
        row = {
            "id": entity.get("id", ""),
            "name": entity.get("name", "")
        }
        
        # Add property values
        values = entity.get("values", {})
        for prop in properties:
            prop_id = prop.get("id", "")
            prop_name = prop.get("name", "")
            row[prop_name] = values.get(prop_id, "")
        
        data.append(row)
    
    # Create the DataFrame
    df = pd.DataFrame(data)
    
    # Set the ID column as the index
    if not df.empty and "id" in df.columns:
        df = df.set_index("id")
    
    # Button to save changes
    save_button = st.button(get_translation("save_changes", "Save Changes"), use_container_width=True, key="save_grid_button")
    
    # Create an editable dataframe
    edited_df = st.data_editor(
        df, 
        use_container_width=True,
        hide_index=True,
        key="entity_grid_editor"
    )
    
    # Process any changes when the save button is clicked
    if save_button and edited_df is not None:
        changes_made = False
        
        for i, row in edited_df.iterrows():
            entity_id = i
            entity = next((e for e in entities if e.get("id") == entity_id), None)
            
            if entity:
                # Update entity name
                if "name" in row and row["name"] != entity.get("name", ""):
                    entity["name"] = row["name"]
                    changes_made = True
                
                # Update property values
                for prop in properties:
                    prop_id = prop.get("id", "")
                    prop_name = prop.get("name", "")
                    
                    if prop_name in row:
                        # Initialize values dict if it doesn't exist
                        if "values" not in entity:
                            entity["values"] = {}
                        
                        # Update the value if changed
                        current_value = entity["values"].get(prop_id, "")
                        new_value = row[prop_name]
                        
                        if str(new_value) != str(current_value):
                            entity["values"][prop_id] = str(new_value)
                            changes_made = True
        
        # Save the topic if changes were made
        if changes_made:
            if save_topic(topic):
                st.success(get_translation("grid_saved", "Grid data saved successfully."))
                st.rerun()
            else:
                st.error(get_translation("grid_save_error", "Failed to save grid data."))
        else:
            st.info(get_translation("no_changes", "No changes were detected."))

def render_quiz_settings(topic):
    """Render the quiz settings section"""
    st.subheader(get_translation("quiz_settings", "Quiz Settings"))
    
    # Get the properties for quiz generation
    properties = topic.get("properties", [])
    
    # Filter properties that are marked for questions or options
    question_properties = [p for p in properties if p.get("use_as_question", False)]
    option_properties = [p for p in properties if p.get("use_as_option", False)]
    
    if not question_properties and not option_properties:
        st.warning(get_translation("no_quiz_properties", "No aspects are marked for use in quizzes."))
        st.info(get_translation("mark_properties", "Go to the Aspects tab and mark aspects for use in quizzes."))
        return
    
    # Create a form for quiz settings
    with st.form(key="quiz_settings_form"):
        st.write(get_translation("quiz_configuration", "Quiz Configuration"))
        
        # Quiz title
        quiz_title = st.text_input(
            get_translation("quiz_title", "Quiz Title"),
            value=topic.get("quiz_title", f"{topic.get('title', 'Topic')} Quiz")
        )
        
        # Quiz description
        quiz_description = st.text_area(
            get_translation("quiz_description", "Quiz Description"),
            value=topic.get("quiz_description", "Test your knowledge")
        )
        
        # Default number of questions
        default_questions = st.number_input(
            get_translation("default_questions", "Default Number of Questions"),
            min_value=1,
            max_value=20,
            value=topic.get("default_quiz_questions", 5)
        )
        
        # Available question types
        st.subheader(get_translation("question_types", "Question Types"))
        
        if not question_properties:
            st.info(get_translation("no_question_properties", "No aspects are marked as question sources."))
        else:
            st.write(get_translation("question_property_note", "The following aspects can be used as question sources:"))
            
            for prop in question_properties:
                st.write(f"• {prop.get('name', '')}")
        
        if not option_properties:
            st.info(get_translation("no_option_properties", "No aspects are marked as option sources."))
        else:
            st.write(get_translation("option_property_note", "The following aspects can be used for quiz options:"))
            
            for prop in option_properties:
                st.write(f"• {prop.get('name', '')}")
                if prop.get("bait_values", []):
                    st.caption(f"  Bait values: {', '.join(prop.get('bait_values', []))}")
        
        # Quiz generation settings
        st.subheader(get_translation("generation_settings", "Generation Settings"))
        
        include_all_entities = st.checkbox(
            get_translation("include_all_entities", "Include all entities in quiz pool"),
            value=topic.get("quiz_include_all_entities", True)
        )
        
        if not include_all_entities:
            # Allow selecting specific entities
            entities = topic.get("entities", [])
            if entities:
                included_entities = topic.get("quiz_included_entities", [])
                
                entity_options = [e.get("id") for e in entities]
                entity_labels = [e.get("name", "Unnamed") for e in entities]
                
                selected_entities = st.multiselect(
                    get_translation("select_entities", "Select entities to include in quizzes"),
                    options=entity_options,
                    default=included_entities,
                    format_func=lambda x: entity_labels[entity_options.index(x)] if x in entity_options else x
                )
            else:
                selected_entities = []
                st.info(get_translation("no_entities", "No entities available to select."))
        else:
            selected_entities = []
        
        # Submit button
        submit = st.form_submit_button(get_translation("save_settings", "Save Quiz Settings"), use_container_width=True)
        
        if submit:
            # Update the topic with quiz settings
            topic["quiz_title"] = quiz_title
            topic["quiz_description"] = quiz_description
            topic["default_quiz_questions"] = default_questions
            topic["quiz_include_all_entities"] = include_all_entities
            
            if not include_all_entities:
                topic["quiz_included_entities"] = selected_entities
            
            # Save the topic
            if save_topic(topic):
                st.success(get_translation("settings_saved", "Quiz settings saved successfully."))
            else:
                st.error(get_translation("settings_save_error", "Failed to save quiz settings."))
    
    # Add a button to generate and test a quiz
    if st.button(get_translation("generate_test_quiz", "Generate Sample Quiz"), key="generate_test_quiz", use_container_width=True):
        # Ensure we have properties for questions and options
        if not question_properties:
            st.error(get_translation("no_question_properties_error", "Cannot generate quiz: No aspects are marked as question sources."))
            return
        
        if not option_properties:
            st.error(get_translation("no_option_properties_error", "Cannot generate quiz: No aspects are marked as option sources."))
            return
        
        # Generate quiz questions
        try:
            # Get the topic ID to pass to the function
            topic_id = topic.get("id")
            
            # Create a list of question and answer aspect IDs to pass to the generator
            question_aspect_ids = [p.get("id") for p in question_properties]
            answer_aspect_ids = [p.get("id") for p in option_properties]
            
            # Check if any aspects have bait values
            has_bait_values = any(len(p.get("bait_values", [])) > 0 for p in option_properties)
            if has_bait_values:
                st.info(get_translation("using_bait_values", "Using custom bait values for quiz options."))
            
            # Call the enhanced quiz generator with explicit aspect IDs
            questions = generate_quiz_questions(
                topic_id, 
                count=5,
                question_aspects=question_aspect_ids,
                answer_aspects=answer_aspect_ids
            )
            
            if questions:
                st.success(get_translation("quiz_generated", "Sample quiz generated successfully."))
                
                # Display the questions
                st.subheader(get_translation("sample_questions", "Sample Questions"))
                
                for i, question in enumerate(questions):
                    with st.container(border=True):
                        st.write(f"**{i+1}. {question.get('question_text', '') or question.get('question', '')}**")
                        
                        options = question.get("options", [])
                        correct_answer = question.get("correct_answer", "")
                        
                        for option in options:
                            if option == correct_answer:
                                st.write(f"✓ {option} (correct)")
                            else:
                                st.write(f"• {option}")
                        
                        # Show explanation if available
                        if explanation := question.get("explanation"):
                            st.caption(f"Explanation: {explanation}")
            else:
                st.warning(get_translation("no_questions_generated", "No questions could be generated. Check your entity and aspect data."))
        except Exception as e:
            st.error(f"Error generating quiz: {str(e)}")