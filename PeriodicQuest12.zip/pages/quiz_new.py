"""
Quiz page module for the Science Learning Platform.
"""

import streamlit as st
import random
import time
import datetime
import plotly.graph_objects as go
from utils.quiz import QuizGenerator, evaluate_answer, get_quiz_statistics, reset_quiz_statistics
from utils.particle_quiz import ParticleQuizGenerator, evaluate_particle_answer, get_particle_quiz_statistics, reset_particle_quiz_statistics
from utils.translations import get_translation, get_display_name
from data.elements import search_elements, get_element_by_name, get_element_by_symbol
from data.standard_model.particles import get_all_particles, get_particle_by_name
from utils.user_auth import is_logged_in, get_current_user, save_quiz_result
from utils.custom_content import get_custom_quiz

# Helper function to handle question text from either format
def get_question_text(question_dict):
    """Get question text from either format (element or particle question)"""
    return question_dict.get('question', question_dict.get('question_text', 'No question available'))

def render():
    """Render the quiz page"""
    st.title(get_translation("quiz_title"))
    
    # Initialize quiz state if not already done
    if "current_question" not in st.session_state:
        st.session_state.current_question = None
    if "answered" not in st.session_state:
        st.session_state.answered = False
    if "selected_answer" not in st.session_state:
        st.session_state.selected_answer = None
    if "quiz_mode" not in st.session_state:
        st.session_state.quiz_mode = "multiple_choice"
    if "quiz_in_progress" not in st.session_state:
        st.session_state.quiz_in_progress = False
    if "quiz_length" not in st.session_state:
        st.session_state.quiz_length = 10  # Default quiz length
    if "quiz_difficulty" not in st.session_state:
        st.session_state.quiz_difficulty = "easy"  # Default difficulty
    if "current_quiz_count" not in st.session_state:
        st.session_state.current_quiz_count = 0
    if "current_quiz_results" not in st.session_state:
        st.session_state.current_quiz_results = []
    if "quiz_history" not in st.session_state:
        st.session_state.quiz_history = []
    if "completed_quizzes" not in st.session_state:
        st.session_state.completed_quizzes = []
    if "quiz_tab" not in st.session_state:
        st.session_state.quiz_tab = "start"  # start, solve, or results
    if "question_index" not in st.session_state:
        st.session_state.question_index = 0  # Current question index
    if "quiz_questions" not in st.session_state:
        st.session_state.quiz_questions = []  # Storage for generated questions
    
    # Quiz settings and controls
    with st.expander(get_translation("quiz_settings"), expanded=True):
        # Check if we're in custom learning mode
        is_custom_learning = "custom_learning" in st.session_state and st.session_state.custom_learning
        
        # Get appropriate stats based on current mode and topic
        if is_custom_learning:
            # Custom learning mode uses custom quiz stats
            # For now, use a placeholder until custom quiz stats are implemented
            stats = {
                "correct": 0,
                "total": 0,
                "percentage": 0
            }
        elif st.session_state.current_topic == "Chemical Elements":
            stats = get_quiz_statistics()
        else:  # Standard Model
            particle_stats = get_particle_quiz_statistics()
            # Convert particle stats format to match element stats format
            stats = {
                "correct": particle_stats["correct_answers"],
                "total": particle_stats["total_questions"],
                "percentage": round((particle_stats["correct_answers"] / particle_stats["total_questions"]) * 100, 1) 
                            if particle_stats["total_questions"] > 0 else 0
            }
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader(get_translation("quiz_statistics"))
            st.metric(get_translation("score"), f"{stats['correct']}/{stats['total']}")
            st.metric(get_translation("percentage"), f"{stats['percentage']}%")
            
            # Quiz mode selection
            st.subheader(get_translation("quiz_type"))
            
            # Answer input mode selection
            quiz_mode = st.radio(
                get_translation("select_answer_input_mode"),
                [get_translation("quiz_multiple_choice"), get_translation("quiz_text_input")],
                index=0 if st.session_state.quiz_mode == "multiple_choice" else 1,
                help=get_translation("quiz_mode_help")
            )
            
            if quiz_mode == get_translation("quiz_multiple_choice"):
                st.session_state.quiz_mode = "multiple_choice"
            else:
                st.session_state.quiz_mode = "text_input"
            
            # Quiz type selection
            if "quiz_type" not in st.session_state:
                st.session_state.quiz_type = "all"
                
            st.markdown(f"### {get_translation('question_types')}")
            st.markdown(get_translation("select_topics"))
            
            # Default to all selected if no specific type is selected
            default_all = st.session_state.quiz_type == "all"
            
            # Checkbox for all topics
            all_topics = st.checkbox(get_translation("all_topics"), value=default_all, key="all_topics", 
                                    help=get_translation("all_topics_help"))
            
            # If all topics is selected, disable other checkboxes
            disabled = all_topics
            
            # Individual topic checkboxes based on current topic
            col1, col2 = st.columns(2)
            
            # Different quiz types based on the current topic
            if st.session_state.current_topic == "Chemical Elements":
                # Elements-specific checkboxes
                with col1:
                    atomic_numbers = st.checkbox(get_translation("atomic_numbers"), value=st.session_state.quiz_type == "atomic_number", 
                                              disabled=disabled, key="atomic_numbers")
                    element_symbols = st.checkbox(get_translation("element_symbols"), value=st.session_state.quiz_type == "symbol", 
                                               disabled=disabled, key="element_symbols")
                    element_names = st.checkbox(get_translation("element_names"), value=st.session_state.quiz_type == "name", 
                                             disabled=disabled, key="element_names")
                    element_categories = st.checkbox(get_translation("element_categories"), value=st.session_state.quiz_type == "category", 
                                                 disabled=disabled, key="element_categories")
                
                with col2:
                    element_descriptions = st.checkbox(get_translation("element_descriptions"), value=st.session_state.quiz_type == "description", 
                                                   disabled=disabled, key="element_descriptions")
                    electron_config = st.checkbox(get_translation("electron_configuration"), value=st.session_state.quiz_type == "electron_config", 
                                               disabled=disabled, key="electron_config")
                    period_group = st.checkbox(get_translation("periods_and_groups"), value=st.session_state.quiz_type == "period_group", 
                                            disabled=disabled, key="period_group")
                    
                # Process the selected topics for Elements
                selected_topics = []
                if atomic_numbers:
                    selected_topics.append("atomic_number")
                if element_symbols:
                    selected_topics.append("symbol")
                if element_names:
                    selected_topics.append("name")  # Korean names are now alternatives to element names
                if element_categories:
                    selected_topics.append("category")
                if element_descriptions:
                    selected_topics.append("description")
                if electron_config:
                    selected_topics.append("electron_config")
                if period_group:
                    selected_topics.append("period_group")
            
            else:  # Standard Model Particles
                # Particle-specific checkboxes
                with col1:
                    particle_symbols = st.checkbox(get_translation("particle_symbols"), value=st.session_state.quiz_type == "symbol", 
                                               disabled=disabled, key="particle_symbols")
                    particle_names = st.checkbox(get_translation("particle_names"), value=st.session_state.quiz_type == "name", 
                                             disabled=disabled, key="particle_names")
                    particle_categories = st.checkbox(get_translation("particle_categories"), value=st.session_state.quiz_type == "category", 
                                                 disabled=disabled, key="particle_categories")
                    particle_charges = st.checkbox(get_translation("particle_charges"), value=st.session_state.quiz_type == "charge", 
                                               disabled=disabled, key="particle_charges")
                
                with col2:
                    particle_masses = st.checkbox(get_translation("particle_masses"), value=st.session_state.quiz_type == "mass", 
                                              disabled=disabled, key="particle_masses")
                    particle_spins = st.checkbox(get_translation("particle_spins"), value=st.session_state.quiz_type == "spin", 
                                             disabled=disabled, key="particle_spins")
                    particle_forces = st.checkbox(get_translation("particle_forces"), value=st.session_state.quiz_type == "force", 
                                              disabled=disabled, key="particle_forces")
                    particle_generations = st.checkbox(get_translation("particle_generations"), value=st.session_state.quiz_type == "generation", 
                                                   disabled=disabled, key="particle_generations")
                
                # Process the selected topics for Particles
                selected_topics = []
                if particle_symbols:
                    selected_topics.append("symbol")
                if particle_names:
                    selected_topics.append("name")
                if particle_categories:
                    selected_topics.append("category")
                if particle_charges:
                    selected_topics.append("charge")
                if particle_masses:
                    selected_topics.append("mass")
                if particle_spins:
                    selected_topics.append("spin")
                if particle_forces:
                    selected_topics.append("force")
                if particle_generations:
                    selected_topics.append("generation")
            
            # Set the quiz type based on selection
            if all_topics or not selected_topics:
                st.session_state.quiz_type = "all"
            elif len(selected_topics) == 1:
                st.session_state.quiz_type = selected_topics[0]
            else:
                # When multiple topics are selected, we'll create a list
                # The quiz generator will be customized to handle multiple types
                st.session_state.quiz_type = selected_topics
            
            # Filter selection based on current topic
            if st.session_state.current_topic == "Chemical Elements":
                # Element range selection
                st.subheader(get_translation("element_range"))
                
                # Range type selection
                range_type = st.radio(
                    get_translation("filter_elements_by"),
                    [get_translation("all_elements"), get_translation("atomic_number_range"), get_translation("element_category")],
                    help=get_translation("filter_help")
                )
                
                if range_type == get_translation("atomic_number_range"):
                    # Get min and max atomic numbers from the database
                    from data.elements import elements_df
                    min_atomic = int(elements_df['atomic_number'].min())
                    max_atomic = int(elements_df['atomic_number'].max())
                    
                    # Atomic number range slider
                    # Allow users to choose between slider or direct input
                    range_selection_method = st.radio(
                        "Select range method:",  # Simple direct label without translation
                        ["Slider", "Direct Input"],
                        horizontal=True,
                        help="Choose how to specify the atomic number range"
                    )
                    
                    if range_selection_method == "Slider":
                        # Use slider for range selection
                        atomic_range = st.slider(
                            get_translation("select_atomic_number_range"),
                            min_atomic, max_atomic, (min_atomic, max_atomic),
                            help=get_translation("atomic_number_range_help")
                        )
                        min_value, max_value = atomic_range[0], atomic_range[1]
                    else:
                        # Use direct number input fields
                        cols = st.columns(2)
                        with cols[0]:
                            min_value = st.number_input(
                                "Minimum atomic number:",
                                min_value=min_atomic, 
                                max_value=max_atomic,
                                value=min_atomic,
                                help="Enter the minimum atomic number"
                            )
                        with cols[1]:
                            max_value = st.number_input(
                                "Maximum atomic number:",
                                min_value=min_atomic, 
                                max_value=max_atomic,
                                value=max_atomic,
                                help="Enter the maximum atomic number"
                            )
                            
                        # Ensure min doesn't exceed max
                        if min_value > max_value:
                            min_value = max_value
                            st.warning("Minimum value cannot exceed maximum value. Adjusting to match.")
                    
                    # Display the selected range
                    st.info(f"Selected range: {min_value} - {max_value}")
                    
                    st.session_state.element_filter = {
                        'type': 'atomic_range',
                        'min': min_value,
                        'max': max_value
                    }
                    
                elif range_type == get_translation("element_category"):
                    # Category selection
                    from data.elements import CATEGORIES
                    categories = list(CATEGORIES.keys())
                    categories.remove('unknown')  # Remove unknown category
                    
                    selected_category = st.selectbox(
                        get_translation("select_element_category"),
                        categories,
                        format_func=lambda x: x.capitalize(),
                        help=get_translation("category_selection_help")
                    )
                    
                    st.session_state.element_filter = {
                        'type': 'category',
                        'value': selected_category
                    }
                    
                else:  # All Elements
                    st.session_state.element_filter = {
                        'type': 'all'
                    }
                    
            else:  # Standard Model Particles
                # Particle filter selection
                st.subheader(get_translation("particle_selection"))
                
                # Filter type selection
                filter_type = st.radio(
                    "Filter particles by:",
                    [get_translation("all_particles"), get_translation("particle_category_filter"), get_translation("particle_generation_filter")],
                    help="Choose how to filter particles for the quiz"
                )
                
                if filter_type == get_translation("particle_category_filter"):
                    # Get particle categories
                    particle_categories = ["quark", "lepton", "gauge boson", "scalar boson"]
                    
                    selected_category = st.selectbox(
                        get_translation("select_element_category"),
                        particle_categories,
                        format_func=lambda x: x.capitalize(),
                        help="Choose a specific particle category for the quiz"
                    )
                    
                    st.session_state.element_filter = {
                        'type': 'category',
                        'value': selected_category
                    }
                    
                elif filter_type == get_translation("particle_generation_filter"):
                    # Generations are only applicable to quarks and leptons
                    selected_generation = st.selectbox(
                        get_translation("generation"),
                        [1, 2, 3],
                        help="Choose a specific fermion generation (applies to quarks and leptons only)"
                    )
                    
                    st.session_state.element_filter = {
                        'type': 'generation',
                        'value': selected_generation
                    }
                    
                else:  # All Particles
                    st.session_state.element_filter = {
                        'type': 'all'
                    }
            
            # Quiz difficulty selection
            st.subheader(get_translation("quiz_difficulty"))
            
            # Use radio buttons for difficulty selection
            difficulty_options = [
                get_translation("difficulty_easy"), 
                get_translation("difficulty_medium"), 
                get_translation("difficulty_hard")
            ]
            difficulty_descriptions = {
                get_translation("difficulty_easy"): get_translation("difficulty_easy_desc"),
                get_translation("difficulty_medium"): get_translation("difficulty_medium_desc"),
                get_translation("difficulty_hard"): get_translation("difficulty_hard_desc")
            }
            
            # Map internal difficulty values to translated options
            difficulty_mapping = {
                "easy": get_translation("difficulty_easy"),
                "medium": get_translation("difficulty_medium"),
                "hard": get_translation("difficulty_hard")
            }
            
            # Get the translated version of the current difficulty
            current_difficulty_translated = difficulty_mapping.get(st.session_state.quiz_difficulty, get_translation("difficulty_easy"))
            
            # Create the radio selection
            selected_difficulty_translated = st.radio(
                get_translation("choose_difficulty"),
                difficulty_options,
                index=difficulty_options.index(current_difficulty_translated) if current_difficulty_translated in difficulty_options else 0,
                horizontal=True,
                help="Select difficulty level - affects question types and descriptions shown"
            )
            
            # Map the translated selection back to internal value
            reverse_mapping = {v: k for k, v in difficulty_mapping.items()}
            selected_difficulty = reverse_mapping.get(selected_difficulty_translated, "easy")
            
            # Update session state if selection changed
            if selected_difficulty != st.session_state.quiz_difficulty:
                st.session_state.quiz_difficulty = selected_difficulty
            
            # Display description of the current difficulty level with a colored box based on difficulty
            difficulty_colors = {
                get_translation("difficulty_easy"): "green",
                get_translation("difficulty_medium"): "orange", 
                get_translation("difficulty_hard"): "red"
            }
            
            # Get background color based on difficulty
            bg_color = "144, 238, 144, 0.2" if selected_difficulty == "easy" else \
                      "255, 165, 0, 0.2" if selected_difficulty == "medium" else \
                      "255, 99, 71, 0.2"
                      
            # Get translated difficulty name
            difficulty_name = difficulty_mapping[selected_difficulty]
            
            st.markdown(f"""
            <div style="padding: 10px; border-radius: 5px; border-left: 5px solid {difficulty_colors[difficulty_name]}; background-color: rgba({bg_color});">
                <strong>{difficulty_name}:</strong> {difficulty_descriptions[difficulty_name]}
            </div>
            """, unsafe_allow_html=True)
            
            # Reset statistics button
            if st.button(get_translation("reset_statistics")):
                if st.session_state.current_topic == "Chemical Elements":
                    reset_quiz_statistics()
                else:
                    reset_particle_quiz_statistics()
                st.rerun()
        
        with col2:
            st.subheader(get_translation("quiz_history"))
            
            # Add a button to navigate to the dedicated quiz history page
            if st.button(get_translation("quiz_history"), key="view_quiz_history_btn", use_container_width=True):
                st.session_state.page = "quiz_history"
                st.rerun()
    
    # Quiz content
    st.markdown("---")
    
    # Create the quiz interface with tabs for Start, Solve, and Results
    if st.session_state.quiz_in_progress:
        # When quiz is in progress, only show the Solve tab
        tabs = st.tabs([get_translation("solve_questions")])
        
        with tabs[0]:
            # Show progress bar
            if st.session_state.question_index < len(st.session_state.quiz_questions):
                progress_text = f"Question {st.session_state.question_index + 1} of {st.session_state.quiz_length}"
                st.write(progress_text)
                progress = st.progress((st.session_state.question_index) / st.session_state.quiz_length)
                
                # Display the current question and handle answers
                if st.session_state.answered:
                    # Show result of previous question
                    question = st.session_state.current_question
                    selected_answer = st.session_state.selected_answer
                    
                    # Use appropriate evaluate function based on the current topic
                    if st.session_state.current_topic == "Chemical Elements":
                        is_correct = evaluate_answer(question, selected_answer)
                    else:  # Standard Model
                        is_correct = evaluate_particle_answer(question, selected_answer)
                    
                    # Display whether the answer is correct or not
                    if is_correct:
                        st.success(get_translation("correct"))
                    else:
                        # Get the correct answer
                        correct_answer = question.get('correct_answer', get_translation("unknown")) if question else get_translation("unknown")
                        st.error(get_translation("incorrect").format(correct_answer))
                    
                    # Show item information for educational purpose
                    if st.session_state.current_topic == "Chemical Elements":
                        # Element information
                        from data.elements import get_element_by_atomic_number, get_element_by_symbol, get_element_by_name
                        
                        # Default to None in case we can't determine the element
                        element = None
                        
                        # Safely check question dictionary and extract information
                        if question is not None and isinstance(question, dict):
                            # Get the question text and correct answer if available
                            question_text = question.get('question', '').lower() if question.get('question') else ''
                            correct_answer = question.get('correct_answer')
                            
                            if question_text and correct_answer is not None:
                                # For name questions, the correct answer is the element name
                                if "what is the name" in question_text:
                                    element = get_element_by_name(correct_answer)
                                # For symbol questions, the correct answer is the element symbol
                                elif "what is the symbol" in question_text:
                                    element = get_element_by_symbol(correct_answer)
                                # For atomic number questions, the correct answer is the atomic number
                                elif "atomic number" in question_text:
                                    element = get_element_by_atomic_number(correct_answer)
                            
                            # If we still don't have an element, try to get it from the question
                            if element is None and 'element' in question:
                                element = question.get('element')
                            
                        # Validate element before displaying to avoid errors
                        if element:
                            # Import get_display_name function at the point of use to avoid UnboundLocalError
                            from utils.translations import get_display_name as get_element_display_name
                            
                            with st.expander(get_translation("learn_more_about").format(get_element_display_name(element)), expanded=True):
                                col1, col2 = st.columns([1, 2])
                                
                                with col1:
                                    # Get element display name based on current language
                                    element_name = get_element_display_name(element)
                                        
                                    st.markdown(f"""
                                    ### {element_name} ({element['symbol']})
                                    **{get_translation("atomic_number")}:** {element['atomic_number']}  
                                    **{get_translation("category")}:** {element['category'].capitalize()}  
                                    **{get_translation("electron_configuration")}:** {element['electron_configuration']}
                                    """)
                                
                                with col2:
                                    # Show element description based on selected language
                                    st.markdown(f"**{get_translation('description')}:**")
                                    
                                    # If language is Korean, show Korean description first
                                    if st.session_state.language == "Korean":
                                        if 'korean_description' in element and element['korean_description']:
                                            # Show Korean description directly
                                            st.markdown(element['korean_description'])
                                        else:
                                            # Show message that Korean description is not available
                                            st.info(get_translation("korean_description_not_available"))
                                            # Fall back to English description
                                            st.markdown(element['description'])
                                    else:
                                        # For English language, show English description
                                        st.markdown(element['description'])
                    
                    else:  # Standard Model Particles
                        # Particle information
                        from data.standard_model.particles import get_particle_by_name, get_particle_by_symbol
                        
                        # Default to None in case we can't determine the particle
                        particle = None
                        
                        # Safely check question dictionary and extract information
                        if question is not None and isinstance(question, dict):
                            # Get the question text and correct answer if available
                            question_text = question.get('question', '').lower() if question.get('question') else ''
                            correct_answer = question.get('correct_answer')
                            
                            if question_text and correct_answer is not None:
                                # For name questions, the correct answer is the particle name
                                if "what is the name" in question_text:
                                    particle = get_particle_by_name(correct_answer)
                                # For symbol questions, the correct answer is the particle symbol
                                elif "what is the symbol" in question_text:
                                    particle = get_particle_by_symbol(correct_answer)
                            
                            # If we still don't have a particle, try to get it from the question
                            if particle is None and 'particle' in question:
                                particle = question.get('particle')
                        
                        # Validate particle before displaying to avoid errors
                        if particle:
                            # Get color for this particle category
                            from data.standard_model.particles import get_particle_color
                            color = get_particle_color(particle["category"])
                            
                            with st.expander(f"Learn more about {particle['name']}", expanded=True):
                                # Title with background color based on category
                                st.markdown(
                                    f"""<div style="background-color: {color}; padding: 0.5rem; border-radius: 5px 5px 0 0;">
                                    <h3 style="margin: 0; color: white; text-align: center;">{particle['name']} ({particle['symbol']})</h3>
                                    </div>""",
                                    unsafe_allow_html=True
                                )
                                
                                # Main content with light background
                                with st.container():
                                    st.markdown(
                                        f"""<div style="border: 1px solid {color}; border-top: none; padding: 1rem; 
                                        border-radius: 0 0 5px 5px; background-color: rgba({int(color[1:3], 16)}, 
                                        {int(color[3:5], 16)}, {int(color[5:7], 16)}, 0.05);">""",
                                        unsafe_allow_html=True
                                    )
                                    
                                    # Two-column layout for properties
                                    col1, col2 = st.columns(2)
                                    
                                    with col1:
                                        st.markdown(f"**Category:** {particle['category'].capitalize()}")
                                        st.markdown(f"**Charge:** {particle['charge']}")
                                        
                                        # Add generation if it exists
                                        if 'generation' in particle:
                                            st.markdown(f"**Generation:** {particle['generation']}")
                                    
                                    with col2:
                                        st.markdown(f"**Mass:** {particle['mass']}")
                                        st.markdown(f"**Spin:** {particle['spin']}")
                                        
                                        # Add force if it exists and is not None
                                        if 'force' in particle and particle['force'] is not None:
                                            st.markdown(f"**Force:** {particle['force']}")
                                    
                                    # Description section
                                    st.markdown("<hr style='margin: 0.5rem 0;'>", unsafe_allow_html=True)
                                    st.markdown("**Description:**")
                                    st.markdown(particle['description'])
                                    
                                    # Close the div for styling
                                    st.markdown("</div>", unsafe_allow_html=True)
                    
                    # Navigation buttons for questions
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        if st.session_state.question_index > 0:
                            if st.button(get_translation("previous_question"), key="prev_question"):
                                st.session_state.question_index -= 1
                                st.session_state.current_question = st.session_state.quiz_questions[st.session_state.question_index]
                                st.session_state.answered = True  # Question was already answered
                                st.session_state.selected_answer = st.session_state.current_quiz_results[st.session_state.question_index]['selected_answer']
                                st.rerun()
                    
                    with col2:
                        if st.session_state.question_index < st.session_state.quiz_length - 1:
                            # Next question button
                            if st.button(get_translation("next_question"), key="next_question"):
                                st.session_state.question_index += 1
                                
                                # Check if we've already generated this question
                                if st.session_state.question_index < len(st.session_state.quiz_questions):
                                    # Use existing question
                                    st.session_state.current_question = st.session_state.quiz_questions[st.session_state.question_index]
                                    
                                    # Check if it was already answered
                                    if st.session_state.question_index < len(st.session_state.current_quiz_results):
                                        st.session_state.answered = True
                                        st.session_state.selected_answer = st.session_state.current_quiz_results[st.session_state.question_index]['selected_answer']
                                    else:
                                        st.session_state.answered = False
                                        st.session_state.selected_answer = None
                                else:
                                    # Check if we're in custom learning mode
                                    is_custom_learning = "custom_learning" in st.session_state and st.session_state.custom_learning
                                    quiz_generator = None
                                    should_generate_question = True
                                    
                                    # Generate a new question based on mode and topic
                                    if is_custom_learning:
                                        # For custom learning, use the custom quiz questions if available
                                        if "active_custom_quiz_id" in st.session_state and st.session_state.active_custom_quiz_id:
                                            # This will be handled by the custom quiz code later
                                            custom_quiz = get_custom_quiz(st.session_state.active_custom_quiz_id)
                                            # Need to prevent generating a standard question when using custom quiz
                                            should_generate_question = False
                                            st.info("Custom quiz detected. Loading custom questions...")
                                            st.rerun() # Exit early
                                        else:
                                            # Default to using the particle quiz generator as a fallback
                                            quiz_generator = ParticleQuizGenerator(
                                                quiz_mode=st.session_state.quiz_mode,
                                                quiz_type=st.session_state.quiz_type,
                                                particle_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
                                                difficulty=st.session_state.quiz_difficulty
                                            )
                                    elif st.session_state.current_topic == "Chemical Elements":
                                        quiz_generator = QuizGenerator(
                                            quiz_mode=st.session_state.quiz_mode,
                                            quiz_type=st.session_state.quiz_type,
                                            element_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
                                            difficulty=st.session_state.quiz_difficulty
                                        )
                                    else:  # Standard Model or other topics
                                        quiz_generator = ParticleQuizGenerator(
                                            quiz_mode=st.session_state.quiz_mode,
                                            quiz_type=st.session_state.quiz_type,
                                            particle_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
                                            difficulty=st.session_state.quiz_difficulty
                                        )
                                    
                                    # Only check if quiz generator is None since we already handled should_generate_question
                                    if quiz_generator is None:
                                        st.error("Unable to generate quiz questions. Please try a different quiz type.")
                                        st.rerun()
                                    question = quiz_generator.generate_question()
                                    st.session_state.quiz_questions.append(question)
                                    st.session_state.current_question = question
                                    st.session_state.answered = False
                                    st.session_state.selected_answer = None
                                
                                st.rerun()
                        elif st.session_state.question_index == st.session_state.quiz_length - 1:
                            # Quiz completed
                            if st.button(get_translation("see_results"), key="see_results", use_container_width=True):
                                # Calculate results
                                correct = sum(1 for r in st.session_state.current_quiz_results if r['correct'])
                                total = len(st.session_state.current_quiz_results)
                                percentage = round((correct / total) * 100, 1) if total > 0 else 0
                                
                                # Create quiz results data
                                quiz_data = {
                                    'date': time.strftime("%Y-%m-%d %H:%M"),
                                    'score': correct,
                                    'total': total,
                                    'percentage': percentage,
                                    'quiz_type': st.session_state.quiz_mode,
                                    'topics': st.session_state.quiz_type,
                                    'questions': st.session_state.current_quiz_results.copy(),
                                    'topic': st.session_state.current_topic,
                                    'quiz_options': {
                                        'quiz_mode': st.session_state.quiz_mode,
                                        'quiz_type': st.session_state.quiz_type,
                                        'difficulty': st.session_state.quiz_difficulty
                                    },
                                    'total_questions': total,
                                    'incorrect_answers': [q for q in st.session_state.current_quiz_results if not q['correct']]
                                }
                                
                                # Save to session state for non-logged in users
                                st.session_state.completed_quizzes.append(quiz_data)
                                
                                # If user is logged in, save to user account
                                if is_logged_in():
                                    username = get_current_user()
                                    save_quiz_result(username, quiz_data)
                                    st.success(get_translation("quiz_saved_to_account"))
                                
                                # Mark quiz as completed
                                st.session_state.quiz_in_progress = False
                                
                                # Store the latest quiz ID to display results
                                st.session_state.latest_quiz_id = len(st.session_state.completed_quizzes) - 1
                                
                                # Navigate directly to quiz history page with this quiz selected
                                st.session_state.page = "quiz_history"
                                st.session_state.quiz_history_viewing = st.session_state.latest_quiz_id
                                st.rerun()
                else:
                    # Show the current question
                    if st.session_state.question_index < len(st.session_state.quiz_questions):
                        # Use existing question
                        question = st.session_state.quiz_questions[st.session_state.question_index]
                    else:
                        # Check if we're in custom learning mode
                        is_custom_learning = "custom_learning" in st.session_state and st.session_state.custom_learning
                        quiz_generator = None
                        
                        # Generate a new question based on mode and topic
                        if is_custom_learning:
                            # For custom learning, use the custom quiz questions if available
                            if "active_custom_quiz_id" in st.session_state and st.session_state.active_custom_quiz_id:
                                # This will be handled by the custom quiz code later
                                custom_quiz = get_custom_quiz(st.session_state.active_custom_quiz_id)
                                # Need to prevent generating a standard question when using custom quiz
                                st.info("Custom quiz detected. Loading custom questions...")
                                st.rerun() # Exit early
                            else:
                                # Default to using the particle quiz generator as a fallback
                                quiz_generator = ParticleQuizGenerator(
                                    quiz_mode=st.session_state.quiz_mode,
                                    quiz_type=st.session_state.quiz_type,
                                    particle_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
                                    difficulty=st.session_state.quiz_difficulty
                                )
                        elif st.session_state.current_topic == "Chemical Elements":
                            quiz_generator = QuizGenerator(
                                quiz_mode=st.session_state.quiz_mode,
                                quiz_type=st.session_state.quiz_type,
                                element_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
                                difficulty=st.session_state.quiz_difficulty
                            )
                        else:  # Standard Model or other topics
                            quiz_generator = ParticleQuizGenerator(
                                quiz_mode=st.session_state.quiz_mode,
                                quiz_type=st.session_state.quiz_type,
                                particle_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
                                difficulty=st.session_state.quiz_difficulty
                            )
                        
                        # Check if quiz generator is None
                        if quiz_generator is None:
                            st.error("Unable to generate quiz questions. Please try a different quiz type.")
                            st.rerun()
                        question = quiz_generator.generate_question()
                        st.session_state.quiz_questions.append(question)
                    
                    st.session_state.current_question = question
                    
                    # Display the question with auto-height container - handle both question formats
                    question_text = question.get('question', question.get('question_text', 'Error: No question text found'))
                    st.markdown(f"### {question_text}")
                    
                    # Add some space based on question length
                    if len(question_text) > 100:
                        st.markdown("<div style='margin-bottom: 20px;'></div>", unsafe_allow_html=True)
                    
                    if st.session_state.quiz_mode == "multiple_choice":
                        # Display options as buttons with auto-height
                        for i, option in enumerate(question['options']):
                            # Create a container that will adjust to content
                            with st.container():
                                # Use index in the key to ensure uniqueness
                                if st.button(str(option), key=f"option_{st.session_state.question_index}_{i}", use_container_width=True):
                                    # Record answer
                                    st.session_state.answered = True
                                    st.session_state.selected_answer = option
                                    
                                    # Update statistics based on current mode and topic
                                    is_custom_learning = "custom_learning" in st.session_state and st.session_state.custom_learning
                                    
                                    if is_custom_learning:
                                        # For custom learning quizzes, just do a direct comparison
                                        # This is the same approach used for both element and particle quizzes
                                        is_correct = str(option).lower().strip() == str(question['correct_answer']).lower().strip()
                                    elif st.session_state.current_topic == "Chemical Elements":
                                        is_correct = evaluate_answer(question, option)
                                    else:  # Standard Model
                                        is_correct = evaluate_particle_answer(question, option)
                                        
                                    if is_correct:
                                        st.session_state.quiz_score += 1
                                    
                                    st.session_state.quiz_total += 1
                                    
                                    # Update history
                                    st.session_state.quiz_history.append({
                                        'question': get_question_text(question),
                                        'selected_answer': option,
                                        'correct_answer': question['correct_answer'],
                                        'correct': is_correct
                                    })
                                    
                                    # Update current quiz results
                                    if len(st.session_state.current_quiz_results) <= st.session_state.question_index:
                                        st.session_state.current_quiz_results.append({
                                            'question': get_question_text(question),
                                            'selected_answer': option,
                                            'correct_answer': question['correct_answer'],
                                            'correct': is_correct,
                                            'full_question': question  # Store the complete question object
                                        })
                                    else:
                                        # Replace existing result (in case of revisiting question)
                                        st.session_state.current_quiz_results[st.session_state.question_index] = {
                                            'question': get_question_text(question),
                                            'selected_answer': option,
                                            'correct_answer': question['correct_answer'],
                                            'correct': is_correct,
                                            'full_question': question  # Store the complete question object
                                        }
                                    
                                    st.rerun()
                    else:  # text_input mode
                        # Get input type and hint
                        input_type = "str"
                        input_hint = ""
                        
                        # Determine the answer type and hint based on the question
                        question_text = question.get('question', question.get('question_text', '')).lower()
                        if "atomic number" in question_text:
                            input_type = "number"
                            input_hint = get_translation("input_atomic_number")
                        elif "symbol" in question_text:
                            input_hint = get_translation("input_element_symbol")
                        elif "name" in question_text:
                            input_hint = get_translation("input_element_name")
                        elif "category" in question_text:
                            input_hint = get_translation("input_element_category")
                        else:
                            input_hint = get_translation("enter_answer")
                        
                        # Create the input field
                        user_answer = None
                        if input_type == "number":
                            # Ensure we always have a non-empty label for the number input
                            if not input_hint or input_hint.strip() == "":
                                input_hint = get_translation("input_atomic_number")
                            user_answer = st.number_input(input_hint, min_value=1, max_value=118, step=1, key=f"number_input_{st.session_state.question_index}")
                        else:
                            # Ensure we always have a non-empty label for the text input
                            if not input_hint or input_hint.strip() == "":
                                input_hint = get_translation("enter_answer")
                            user_answer = st.text_input(input_hint, key=f"text_input_{st.session_state.question_index}")
                        
                        # Submit button
                        if st.button(get_translation("submit_answer"), key=f"submit_answer_btn_{st.session_state.question_index}", use_container_width=True):
                            if user_answer:
                                # Record answer
                                st.session_state.answered = True
                                st.session_state.selected_answer = user_answer
                                
                                # Update statistics based on current mode and topic
                                is_custom_learning = "custom_learning" in st.session_state and st.session_state.custom_learning
                                
                                if is_custom_learning:
                                    # For custom learning quizzes, just do a direct comparison
                                    # This is the same approach used for both element and particle quizzes
                                    is_correct = str(user_answer).lower().strip() == str(question['correct_answer']).lower().strip()
                                elif st.session_state.current_topic == "Chemical Elements":
                                    is_correct = evaluate_answer(question, user_answer)
                                else:  # Standard Model
                                    is_correct = evaluate_particle_answer(question, user_answer)
                                    
                                if is_correct:
                                    st.session_state.quiz_score += 1
                                
                                st.session_state.quiz_total += 1
                                
                                # Update history
                                st.session_state.quiz_history.append({
                                    'question': get_question_text(question),
                                    'selected_answer': user_answer,
                                    'correct_answer': question['correct_answer'],
                                    'correct': is_correct
                                })
                                
                                # Update current quiz results
                                if len(st.session_state.current_quiz_results) <= st.session_state.question_index:
                                    st.session_state.current_quiz_results.append({
                                        'question': get_question_text(question),
                                        'selected_answer': user_answer,
                                        'correct_answer': question['correct_answer'],
                                        'correct': is_correct,
                                        'full_question': question  # Store the complete question object
                                    })
                                else:
                                    # Replace existing result (in case of revisiting question)
                                    st.session_state.current_quiz_results[st.session_state.question_index] = {
                                        'question': get_question_text(question),
                                        'selected_answer': user_answer,
                                        'correct_answer': question['correct_answer'],
                                        'correct': is_correct,
                                        'full_question': question  # Store the complete question object
                                    }
                                
                                st.rerun()
                            else:
                                st.warning("Please enter an answer before submitting.")
            
            # Button to end quiz early
            if st.button("End Quiz Early", key="end_quiz_early_button"):
                if len(st.session_state.current_quiz_results) > 0:
                    # Calculate results
                    correct = sum(1 for r in st.session_state.current_quiz_results if r['correct'])
                    total = len(st.session_state.current_quiz_results)
                    percentage = round((correct / total) * 100, 1) if total > 0 else 0
                    
                    # Save the completed quiz
                    st.session_state.completed_quizzes.append({
                        'date': time.strftime("%Y-%m-%d %H:%M"),
                        'score': correct,
                        'total': total,
                        'percentage': percentage,
                        'quiz_type': st.session_state.quiz_mode,
                        'topics': st.session_state.quiz_type,
                        'questions': st.session_state.current_quiz_results.copy()
                    })
                    
                # Mark quiz as completed
                st.session_state.quiz_in_progress = False
                
                # Store the latest quiz ID to display
                st.session_state.latest_quiz_id = len(st.session_state.completed_quizzes) - 1
                
                # Navigate directly to quiz history page with this quiz selected
                st.session_state.page = "quiz_history"
                st.session_state.quiz_history_viewing = st.session_state.latest_quiz_id
                st.rerun()
    else:
        # Check if a custom quiz is active
        is_custom_quiz = "active_custom_quiz_id" in st.session_state and st.session_state.active_custom_quiz_id
        
        # When no quiz is in progress, show appropriate tabs
        if is_custom_quiz:
            # For custom quizzes, only show Start and Results tabs
            if "latest_quiz_id" in st.session_state and st.session_state.latest_quiz_id is not None:
                # Quiz results are available to show
                tabs = st.tabs([
                    get_translation("start_quiz_tab"), 
                    get_translation("quiz_results_tab")
                ])
                tab_index = 1  # Default to results tab after quiz completion
            else:
                # No recent quiz results to show
                tabs = st.tabs([
                    get_translation("start_quiz_tab")
                ])
                tab_index = 0
        else:
            # For regular quizzes, show all tabs including performance
            if "latest_quiz_id" in st.session_state and st.session_state.latest_quiz_id is not None:
                # Quiz results are available to show
                tabs = st.tabs([
                    get_translation("start_quiz_tab"), 
                    get_translation("quiz_results_tab"), 
                    get_translation("performance_tab")
                ])
                tab_index = 1  # Default to results tab after quiz completion
            else:
                # No recent quiz results to show
                tabs = st.tabs([
                    get_translation("start_quiz_tab"), 
                    get_translation("performance_tab")
                ])
                tab_index = 0
        
        # Start Quiz Tab
        with tabs[0]:
            st.subheader("Start a New Quiz")
            
            cols = st.columns([2, 1])
            
            with cols[0]:
                # Quiz length options
                quiz_length_options = ["10 questions", "20 questions", "Custom length"]
                quiz_length_choice = st.radio(
                    "Select quiz length:", 
                    quiz_length_options,
                    horizontal=True,
                    help="Choose how many questions you want in your quiz",
                    key="quiz_length_radio"
                )
                
                if quiz_length_choice == "Custom length":
                    custom_length = st.number_input(
                        "Enter number of questions:", 
                        min_value=1, 
                        max_value=100, 
                        value=st.session_state.quiz_length,
                        help="Choose a custom number of questions (1-100)",
                        key="custom_quiz_length"
                    )
                    st.session_state.quiz_length = custom_length
                else:
                    # Extract number from the option text
                    st.session_state.quiz_length = int(quiz_length_choice.split()[0])
                    
            with cols[1]:
                if st.button("Start Quiz", key="start_quiz_button", use_container_width=True):
                    # Set up a new quiz and generate the first question immediately
                    st.session_state.quiz_in_progress = True
                    st.session_state.question_index = 0
                    st.session_state.quiz_questions = []
                    st.session_state.current_quiz_results = []
                    st.session_state.current_quiz_count = 0
                    st.session_state.answered = False
                    
                    # Check if this is a custom quiz
                    if "active_custom_quiz_id" in st.session_state and st.session_state.active_custom_quiz_id:
                        # Get the custom quiz data
                        custom_quiz = get_custom_quiz(st.session_state.active_custom_quiz_id)
                        
                        if custom_quiz and "questions" in custom_quiz and custom_quiz["questions"]:
                            # Prepare the questions from custom quiz
                            custom_questions = []
                            for i, q in enumerate(custom_quiz["questions"]):
                                # Format question to match the expected format
                                formatted_question = {
                                    "id": q["id"],
                                    "question": q["question_text"],  # Use 'question' key for compatibility
                                    "correct_answer": q["correct_answer"],
                                    "question_type": q["question_type"],  # Fix: use question_type consistently
                                    "options": q.get("options", []) if q["question_type"] == "multiple_choice" else None,
                                    "explanation": q.get("explanation", "")
                                }
                                custom_questions.append(formatted_question)
                            
                            # Store the questions and set the first one
                            if custom_questions:
                                # Randomize the questions
                                random.shuffle(custom_questions)
                                st.session_state.quiz_questions = custom_questions
                                st.session_state.current_question = custom_questions[0]
                                # Set quiz mode based on the first question
                                st.session_state.quiz_mode = custom_questions[0].get("question_type", "multiple_choice")
                            else:
                                st.error("This custom quiz doesn't have any questions.")
                                st.session_state.quiz_in_progress = False
                        else:
                            st.error("Could not find the custom quiz or it has no questions.")
                            st.session_state.quiz_in_progress = False
                    else:
                        # Pre-generate the first question to avoid empty quiz based on current topic
                        if st.session_state.current_topic == "Chemical Elements":
                            quiz_generator = QuizGenerator(
                                quiz_mode=st.session_state.quiz_mode,
                                quiz_type=st.session_state.quiz_type,
                                element_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
                                difficulty=st.session_state.quiz_difficulty
                            )
                        else:  # Standard Model or other topics
                            quiz_generator = ParticleQuizGenerator(
                                quiz_mode=st.session_state.quiz_mode,
                                quiz_type=st.session_state.quiz_type,
                                particle_filter=st.session_state.element_filter if "element_filter" in st.session_state else None,
                                difficulty=st.session_state.quiz_difficulty
                            )
                        question = quiz_generator.generate_question()
                        st.session_state.quiz_questions.append(question)
                        st.session_state.current_question = question
                    
                    st.rerun()
        
        # Results Tab (only shown if results are available)
        if "latest_quiz_id" in st.session_state and st.session_state.latest_quiz_id is not None:
            with tabs[1]:
                if st.session_state.latest_quiz_id >= 0 and st.session_state.latest_quiz_id < len(st.session_state.completed_quizzes):
                    quiz = st.session_state.completed_quizzes[st.session_state.latest_quiz_id]
                    
                    st.subheader("🎉 Quiz Results 🎉")
                    
                    # Display quiz summary in a colorful box
                    score_color = "green" if quiz['percentage'] >= 80 else "orange" if quiz['percentage'] >= 60 else "red"
                    st.markdown(f"""
                    <div style="padding: 20px; border-radius: 10px; background-color: #f0f2f6; margin-bottom: 20px;">
                        <h3 style="margin-top: 0;">Quiz Results</h3>
                        <p><strong>Score:</strong> {quiz['score']}/{quiz['total']} ({quiz['percentage']}%)</p>
                        <p><strong>Quiz Type:</strong> {quiz['quiz_type']}</p>
                        <p><strong>Topics:</strong> {quiz['topics']}</p>
                        <div style="width: 100%; height: 20px; background-color: #eee; border-radius: 10px; margin-top: 10px;">
                            <div style="width: {quiz['percentage']}%; height: 20px; background-color: {score_color}; border-radius: 10px;"></div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Show detailed results
                    st.subheader("Question Results")
                    
                    for i, q in enumerate(quiz['questions']):
                        if q['correct']:
                            with st.expander(f"Question {i+1}: ✓ Correct"):
                                st.write(f"**Question:** {q['question']}")
                                st.write(f"**Your answer:** {q['selected_answer']}")
                                st.write(f"**Correct answer:** {q['correct_answer']}")
                        else:
                            with st.expander(f"Question {i+1}: ✗ Incorrect", expanded=True):
                                st.write(f"**Question:** {q['question']}")
                                st.write(f"**Your answer:** {q['selected_answer']}")
                                st.write(f"**Correct answer:** {q['correct_answer']}")
                    
                    # Option to start a new quiz
                    if st.button("Start a New Quiz", key="new_quiz_after_results"):
                        st.session_state.latest_quiz_id = None
                        st.session_state.quiz_tab = "start"
                        st.rerun()
        
        # Performance Tab (not shown for custom quizzes)
        is_custom_quiz = "active_custom_quiz_id" in st.session_state and st.session_state.active_custom_quiz_id
        
        # Only show performance tab for standard quizzes
        if not is_custom_quiz and len(tabs) > 1:
            if len(tabs) == 3:  # Three tabs (Start, Results, Performance)
                performance_tab_index = 2
            else:  # Two tabs (Start, Performance)
                performance_tab_index = 1
                
            with tabs[performance_tab_index]:
                st.subheader(get_translation("quiz_history_title"))
                
                # Add a button to navigate to the dedicated Quiz History page
                if st.session_state.completed_quizzes:
                    # Show a brief summary of quiz history
                    total_quizzes = len(st.session_state.completed_quizzes)
                    st.write(f"{get_translation('total_quizzes')}: {total_quizzes}")
                else:
                    st.info(get_translation("no_quizzes_taken"))
                
                # Button to view full quiz history
                if st.button(get_translation("view_details"), key="view_quiz_history_details", use_container_width=True):
                    st.session_state.page = "quiz_history"
                    st.rerun()

def _display_element_info(element, question_index):
    """Helper function to display element or particle information in quiz history"""
    
    # Check if this is a chemical element or particle
    if st.session_state.current_topic == "Chemical Elements":
        # Get element display name
        from utils.translations import get_display_name
        display_name = get_display_name(element)
        
        # Element header
        st.markdown(f"### {get_translation('element_information')}")
        
        # Element properties in columns
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.markdown(f"""
            <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                <h3 style="margin-top: 0; color: #2B83BA;">{display_name}</h3>
                <div style="display: flex; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 200px; margin-right: 20px;">
                        <p><strong>{get_translation("symbol")}:</strong> {element['symbol']}</p>
                        <p><strong>{get_translation("atomic_number")}:</strong> {element['atomic_number']}</p>
                    </div>
                    <div style="flex: 1; min-width: 200px;">
                        <p><strong>{get_translation("category")}:</strong> {element['category'].capitalize()}</p>
                        <p><strong>{get_translation("electron_configuration")}:</strong> {element['electron_configuration']}</p>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            # Button to view full element details
            if st.button(get_translation("view_element_info"), key=f"view_elem_details_{question_index}", use_container_width=True):
                st.session_state.selected_element = element
                st.session_state.page = "element_details"
                st.rerun()
        
        # Element description
        st.markdown(f"#### {get_translation('description')}")
        
        # Show description based on language preference
        if st.session_state.language == "Korean" and "korean_description" in element and element["korean_description"]:
            st.markdown(element["korean_description"])
        else:
            st.markdown(element["description"])
    
    else:  # Standard Model particles
        # Particle header
        st.markdown(f"### Particle Information")
        
        # Get color for this category
        from data.standard_model.particles import get_particle_color
        color = get_particle_color(element['category'])
        
        # Particle properties with Wikipedia-like styling
        with st.container():
            # Title with background color based on category
            st.markdown(
                f"""<div style="background-color: {color}; padding: 0.5rem; border-radius: 5px 5px 0 0;">
                <h3 style="margin: 0; color: white; text-align: center;">{element['name']} ({element['symbol']})</h3>
                </div>""",
                unsafe_allow_html=True
            )
            
            # Main content with light background
            with st.container():
                st.markdown(
                    f"""<div style="border: 1px solid {color}; border-top: none; padding: 1rem; 
                    border-radius: 0 0 5px 5px; background-color: rgba({int(color[1:3], 16)}, 
                    {int(color[3:5], 16)}, {int(color[5:7], 16)}, 0.05);">""",
                    unsafe_allow_html=True
                )
                
                # Two-column layout for properties
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown(f"**Category:** {element['category'].capitalize()}")
                    st.markdown(f"**Charge:** {element['charge']}")
                    
                    # Add generation if it exists
                    if 'generation' in element:
                        st.markdown(f"**Generation:** {element['generation']}")
                
                with col2:
                    st.markdown(f"**Mass:** {element['mass']}")
                    st.markdown(f"**Spin:** {element['spin']}")
                    
                    # Add force if it exists and is not None
                    if 'force' in element and element['force'] is not None:
                        st.markdown(f"**Force:** {element['force']}")
                
                # Description section
                st.markdown("<hr style='margin: 0.5rem 0;'>", unsafe_allow_html=True)
                st.markdown("#### Description")
                st.markdown(element['description'])
                
                # Close the div for styling
                st.markdown("</div>", unsafe_allow_html=True)