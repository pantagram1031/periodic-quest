"""
Home page module for the Chemical Elements Explorer.
"""

import streamlit as st
from data.elements import search_elements, get_element_suggestions, get_element_by_atomic_number
from utils.translations import get_translation, get_display_name

def render():
    """Render the home page"""
    st.title(get_translation("app_title") + " ⚗️")
    
    # Main welcome message and features
    welcome_text = get_translation("welcome_message")
    
    # Display content in the current language
    features_text = {
        "English": """
        ### Features:
        
        - **Explore the Periodic Table**: View an interactive periodic table and discover detailed information about each element.
        - **Element Details**: Get comprehensive data about each element including properties, history, and uses.
        - **Test Your Knowledge**: Take quizzes to test your understanding of chemical elements.
        - **Track Your Progress**: Monitor your quiz performance with score tracking.
        
        ### Get Started:
        
        - Use the navigation sidebar to explore the application
        - Search for elements below
        - Click on any element in the periodic table to view its details
        - Take a quiz to test your knowledge
        """,
        "Korean": """
        ### 기능:
        
        - **주기율표 탐색**: 대화형 주기율표를 보고 각 원소에 대한 상세 정보를 확인하세요.
        - **원소 세부 정보**: 각 원소의 속성, 역사, 용도를 포함한 종합적인 데이터를 확인하세요.
        - **지식 테스트**: 퀴즈를 통해 화학 원소에 대한 이해도를 테스트하세요.
        - **진행 상황 확인**: 점수 추적으로 퀴즈 성과를 모니터링하세요.
        
        ### 시작하기:
        
        - 탐색 사이드바를 사용하여 응용 프로그램 탐색
        - 아래에서 원소 검색
        - 주기율표에서 원소를 클릭하여 세부 정보 보기
        - 퀴즈를 풀어 지식 테스트하기
        """
    }
    
    # Show the welcome message and features in the selected language
    st.markdown(welcome_text)
    st.markdown(features_text[st.session_state.language])
    
    # Search functionality with live preview
    st.subheader(get_translation("search_elements"))
    search_col1, search_col2 = st.columns([3, 1])
    
    with search_col1:
        search_query = st.text_input(get_translation("search_placeholder"), key="home_search")
    
    # Show search preview as the user types
    if search_query and len(search_query) >= 1:
        # Show suggestions as the user types (for partial queries)
        if len(search_query) <= 3:
            suggestions = get_element_suggestions(search_query)
            if suggestions:
                st.write(get_translation("suggestions") + ":")
                suggestion_cols = st.columns(min(5, len(suggestions)))
                
                for i, element in enumerate(suggestions):
                    with suggestion_cols[i]:
                        # Show element name differently based on language
                        display_name = get_display_name(element)
                        if st.button(f"{element['symbol']} ({display_name})", key=f"suggest_{element['atomic_number']}"):
                            # Redirect to periodic table with element selected
                            st.session_state.current_element_description = element
                            st.session_state.show_element_description = True
                            st.session_state.page = "periodic_table"
                            st.rerun()
        
        # Get full search results
        preview_results = search_elements(search_query)
        
        # Show search preview
        if preview_results:
            found_msg = get_translation("found_elements").format(len(preview_results))
            st.success(found_msg)
            
            # Show quick preview buttons for top 5 matches
            if len(preview_results) > 0:
                st.write(get_translation("quick_preview") + ":")
                preview_cols = st.columns(min(5, len(preview_results)))
                
                for i, element in enumerate(preview_results[:5]):
                    with preview_cols[i]:
                        # Show element name differently based on language
                        display_name = get_display_name(element)
                        if st.button(f"{element['symbol']} - {display_name}", key=f"preview_{element['atomic_number']}"):
                            st.session_state.current_element_description = element
                            st.session_state.show_element_description = True
                            st.session_state.page = "periodic_table"
                            st.rerun()
            
            # Show full results
            for element in preview_results:
                # Get the appropriate display name based on language
                display_name = get_display_name(element)
                
                with st.expander(f"{display_name} ({element['symbol']})"):
                    col1, col2 = st.columns([1, 3])
                    
                    with col1:
                        st.markdown(f"""
                        ### {display_name}
                        **{get_translation("symbol")}:** {element['symbol']}  
                        **{get_translation("atomic_number")}:** {element['atomic_number']}  
                        **{get_translation("category")}:** {element['category'].capitalize()}  
                        """)
                        
                        if st.button(get_translation("view_details"), key=f"view_{element['atomic_number']}"):
                            st.session_state.current_element_description = element
                            st.session_state.show_element_description = True
                            st.session_state.page = "periodic_table"
                            st.rerun()
                    
                    with col2:
                        # Select the appropriate description based on language
                        description = element['korean_description'] if st.session_state.language == "Korean" and 'korean_description' in element and element['korean_description'] else element['description']
                        
                        discovered_by = element['discovered_by'] if element['discovered_by'] else get_translation("unknown")
                        discovery_year = element['discovery_year'] if element['discovery_year'] else get_translation("ancient")
                        
                        st.markdown(f"""
                        **{get_translation("atomic_weight")}:** {element['atomic_weight']} u  
                        **{get_translation("electron_configuration")}:** {element['electron_configuration']}  
                        **{get_translation("discovered_by")}:** {discovered_by}  
                        **{get_translation("discovery_year")}:** {discovery_year}
                        
                        {description[:200]}...
                        """)
        else:
            st.error(get_translation("no_results"))
    
    # Quick access buttons for different views
    st.subheader(get_translation("get_started"))
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button(get_translation("explore_periodic_table"), use_container_width=True):
            st.session_state.page = "periodic_table"
            st.rerun()
    
    with col2:
        if st.button(get_translation("take_quiz"), use_container_width=True):
            st.session_state.page = "quiz"
            st.rerun()
    
    with col3:
        # Random element button - the text for this doesn't exist in translations yet, so we'll add it
        random_element_text = "Random Element" if st.session_state.language == "English" else "무작위 원소"
        if st.button(random_element_text, use_container_width=True):
            import random
            from data.elements import get_all_elements
            
            elements = get_all_elements()
            random_element = random.choice(elements)
            
            st.session_state.current_element_description = random_element
            st.session_state.show_element_description = True
            st.session_state.page = "periodic_table"
            st.rerun()
