"""
Template Content Assistant module for the Science Learning Platform.
This module provides an interface to generate custom learning content 
using predefined templates instead of requiring an external API.
"""
import streamlit as st
import json
import datetime
import uuid
import os
from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.custom_content import (
    create_custom_topic, create_custom_quiz, add_content_section, 
    add_quiz_question, get_custom_topics, get_custom_quizzes
)
from utils.content_templates import (
    get_topic_categories, get_topics_by_category, get_all_topics,
    get_random_topics, get_similar_topics, generate_content_section,
    generate_quiz_questions
)

def render():
    """Render the Template Content Assistant page"""
    st.title("📚 " + get_translation("template_content_assistant", "Template Content Assistant"))
    
    # Check if user is logged in - only logged-in users can create custom content
    if not is_logged_in():
        st.warning(get_translation("login_required_template_content", "You need to log in to create or manage custom content."))
        
        # Add a button to go to the login page
        if st.button(get_translation("go_to_login", "Go to Login Page"), use_container_width=True):
            st.session_state.page = "login"
            st.rerun()
        return
    
    # Initialize session state for this page
    if "selected_template" not in st.session_state:
        st.session_state.selected_template = None
    if "current_template_sections" not in st.session_state:
        st.session_state.current_template_sections = None
    if "current_template_questions" not in st.session_state:
        st.session_state.current_template_questions = None
    
    # Create tabs for different content generation features
    tab1, tab2, tab3, tab4 = st.tabs([
        "💡 Topic Templates",
        "📝 Content Sections",
        "❓ Quiz Templates",
        "🤖 ChatGPT Template"
    ])
    
    with tab1:
        _render_topic_templates()
    
    with tab2:
        _render_content_sections()
    
    with tab3:
        _render_quiz_templates()
    
    with tab4:
        _render_chatgpt_template()

def _render_topic_templates():
    """Render the topic templates interface"""
    st.header("💡 " + get_translation("topic_templates", "Topic Templates"))
    st.markdown(get_translation("topic_templates_description", "Browse and use predefined topic templates to quickly create learning content."))
    
    # Create category filter
    categories = get_topic_categories()
    category = st.selectbox(
        get_translation("select_category", "Select Category"),
        options=["All"] + categories
    )
    
    # Get topics based on selected category
    if category == "All":
        topics = get_all_topics()
    else:
        topics = get_topics_by_category(category)
    
    st.subheader(get_translation("available_templates", "Available Templates"))
    
    # Display available templates
    for i, topic in enumerate(topics):
        with st.expander(f"{topic.get('icon', '📚')} {topic.get('title', 'Topic Template')}"):
            st.write(f"**{get_translation('description', 'Description')}:** {topic.get('description', '')}")
            
            # Show details about the template
            if 'sections' in topic:
                st.write(f"**{get_translation('content_sections', 'Content Sections')}:** {len(topic['sections'])}")
            if 'quiz_questions' in topic:
                st.write(f"**{get_translation('quiz_questions', 'Quiz Questions')}:** {len(topic['quiz_questions'])}")
            
            # Create topic button
            if st.button(get_translation("use_this_template", "Use This Template"), key=f"use_template_{i}"):
                st.session_state.selected_template = topic
                
                # Store template sections and questions in session state
                if 'sections' in topic:
                    st.session_state.current_template_sections = topic['sections']
                if 'quiz_questions' in topic:
                    st.session_state.current_template_questions = topic['quiz_questions']
                
                st.success(get_translation("template_selected", "Template selected! You can now customize it."))
    
    # Create a custom topic if template is selected
    if st.session_state.selected_template:
        topic = st.session_state.selected_template
        
        st.subheader(get_translation("customize_and_create", "Customize and Create"))
        
        with st.form("create_from_template_form"):
            title = st.text_input(get_translation("topic_title", "Topic Title"), value=topic.get('title', ''))
            description = st.text_area(get_translation("topic_description", "Description"), value=topic.get('description', ''))
            icon = st.text_input(get_translation("icon", "Icon (emoji)"), value=topic.get('icon', '📚'))
            
            create_button = st.form_submit_button(get_translation("create_topic", "Create Topic"))
            
            if create_button:
                if not title:
                    st.error(get_translation("title_required", "Topic title is required."))
                else:
                    username = get_current_user()
                    
                    # Create the topic
                    created_topic = create_custom_topic(
                        title=title,
                        description=description,
                        icon=icon,
                        created_by=username
                    )
                    
                    if created_topic:
                        # Add sections if available
                        if 'sections' in topic:
                            for section in topic['sections']:
                                if section['content_type'] == 'text':
                                    add_content_section(
                                        topic_id=created_topic['id'],
                                        title=section['title'],
                                        content_type='text',
                                        content_data={'text': section['content']}
                                    )
                                elif section['content_type'] == 'chart':
                                    add_content_section(
                                        topic_id=created_topic['id'],
                                        title=section['title'],
                                        content_type='chart',
                                        content_data={
                                            'chart_type': section['chart_type'],
                                            'title': section['title'],
                                            'x_label': section['x_label'],
                                            'y_label': section['y_label'],
                                            'x_data': section['x_data'],
                                            'y_data': section['y_data']
                                        }
                                    )
                        
                        # Create quiz if questions are available
                        if 'quiz_questions' in topic and topic['quiz_questions']:
                            # Create quiz
                            created_quiz = create_custom_quiz(
                                title=f"{title} Quiz",
                                description=f"Quiz about {title}",
                                topic_id=created_topic['id'],
                                created_by=username,
                                difficulty="medium"
                            )
                            
                            # Add questions to the quiz
                            if created_quiz:
                                for question in topic['quiz_questions']:
                                    add_quiz_question(
                                        quiz_id=created_quiz['id'],
                                        question_text=question['question_text'],
                                        question_type=question['question_type'],
                                        correct_answer=question['correct_answer'],
                                        options=question.get('options'),
                                        explanation=question.get('explanation', '')
                                    )
                        
                        st.success(get_translation("topic_created_successfully", "Topic created successfully with template content!"))
                        
                        # Clear the selected template
                        st.session_state.selected_template = None
                        st.session_state.current_template_sections = None
                        st.session_state.current_template_questions = None
                        
                        # Offer to view the topic
                        st.info(get_translation("view_created_topic_info", "You can now view your newly created topic."))
                        # Set up session state for auto-redirect to view
                        st.session_state.topic_id = created_topic['id']
                        st.session_state.page = "topic_view"
                        st.rerun()
                    else:
                        st.error(get_translation("failed_to_create", "Failed to create topic."))

def _render_content_sections():
    """Render the content sections template interface"""
    st.header("📝 " + get_translation("content_sections", "Content Sections"))
    st.markdown(get_translation("content_sections_description", "Generate and customize content sections to add to your topics."))
    
    # Get user's custom topics
    topics = get_custom_topics()
    
    if not topics:
        st.info(get_translation("no_custom_topics", "You haven't created any custom topics yet. Use the Topic Templates tab to create one!"))
        return
    
    # Section type selection
    section_type = st.selectbox(
        get_translation("content_type", "Content Type"),
        options=["Text", "Chart"],
        format_func=lambda x: {"Text": get_translation("text_section", "Text Section"), 
                              "Chart": get_translation("chart_section", "Chart/Visualization")}[x]
    )
    
    # Generate content template button
    if st.button(get_translation("generate_template", "Generate Template"), key="generate_template_btn"):
        template_type = "text" if section_type == "Text" else "chart_data"
        section_template = generate_content_section(template_type)
        
        if "error" in section_template:
            st.error(section_template["error"])
        else:
            st.session_state.current_section_template = section_template
            st.success(get_translation("template_generated", "Template generated! You can now customize it."))
    
    # Display and edit generated template
    if "current_section_template" in st.session_state and st.session_state.current_section_template:
        template = st.session_state.current_section_template
        
        st.subheader(get_translation("customize_section", "Customize Section"))
        
        # Select a topic to add the section to
        topic_options = [f"{topic['icon']} {topic['title']}" for topic in topics]
        selected_topic_display = st.selectbox(
            get_translation("select_topic", "Select a Topic"),
            options=topic_options
        )
        
        # Extract selected topic
        selected_topic_index = topic_options.index(selected_topic_display)
        selected_topic = topics[selected_topic_index]
        
        with st.form("section_editor_form"):
            if section_type == "Text":
                section_title = st.text_input(get_translation("section_title", "Section Title"), value=template.get("title", ""))
                section_content = st.text_area(get_translation("content", "Content"), value=template.get("content", ""), height=300)
                
                save_button = st.form_submit_button(get_translation("add_to_topic", "Add to Topic"))
                
                if save_button:
                    # Add content section to topic
                    updated_topic = add_content_section(
                        topic_id=selected_topic['id'],
                        title=section_title,
                        content_type="text",
                        content_data={"text": section_content}
                    )
                    
                    if updated_topic:
                        st.success(get_translation("content_section_added", "Content section added to topic!"))
                        st.session_state.current_section_template = None
                        st.rerun()
                    else:
                        st.error(get_translation("failed_to_add", "Failed to add content section."))
            
            elif section_type == "Chart":
                section_title = st.text_input(get_translation("section_title", "Section Title"), value=template.get("title", ""))
                chart_type = st.selectbox(
                    get_translation("chart_type", "Chart Type"),
                    options=["bar", "line", "scatter", "pie"],
                    index=["bar", "line", "scatter", "pie"].index(template.get("chart_type", "bar"))
                )
                
                x_label = st.text_input(get_translation("x_axis_label", "X-Axis Label"), value=template.get("x_label", ""))
                y_label = st.text_input(get_translation("y_axis_label", "Y-Axis Label"), value=template.get("y_label", ""))
                
                # Convert x_data and y_data to strings for editing
                x_data_str = st.text_area(
                    get_translation("x_axis_data", "X-Axis Data (comma separated)"),
                    value=", ".join([str(x) for x in template.get("x_data", [])])
                )
                y_data_str = st.text_area(
                    get_translation("y_axis_data", "Y-Axis Data (comma separated)"),
                    value=", ".join([str(y) for y in template.get("y_data", [])])
                )
                
                save_button = st.form_submit_button(get_translation("add_to_topic", "Add to Topic"))
                
                if save_button:
                    try:
                        # Parse data
                        x_data = [x.strip() for x in x_data_str.split(",")]
                        y_data = [float(y.strip()) for y in y_data_str.split(",")]
                        
                        # Add content section to topic
                        updated_topic = add_content_section(
                            topic_id=selected_topic['id'],
                            title=section_title,
                            content_type="chart",
                            content_data={
                                "chart_type": chart_type,
                                "title": section_title,
                                "x_label": x_label,
                                "y_label": y_label,
                                "x_data": x_data,
                                "y_data": y_data
                            }
                        )
                        
                        if updated_topic:
                            st.success(get_translation("chart_data_added", "Chart data added to topic!"))
                            st.session_state.current_section_template = None
                            st.rerun()
                        else:
                            st.error(get_translation("failed_to_add", "Failed to add chart data."))
                    except Exception as e:
                        st.error(f"{get_translation('error_parsing_data', 'Error parsing data')}: {str(e)}")

def _render_chatgpt_template():
    """Render the ChatGPT template interface"""
    st.header("🤖 " + get_translation("chatgpt_template", "ChatGPT Template Generator"))
    st.markdown(get_translation("chatgpt_template_description", 
                              "Use this template with ChatGPT to generate custom topics that can be imported into the platform."))
    
    # Get the template content
    try:
        with open("chatgpt_topic_generator_template.md", "r") as file:
            template_content = file.read()
            
        # Display the template
        st.subheader(get_translation("template_instructions", "Instructions"))
        st.markdown("""
        1. Copy the template below
        2. Paste it into ChatGPT or another AI assistant
        3. Follow the instructions to generate a JSON topic
        4. Save the generated JSON to a file with a `.json` extension
        5. Import the file using the Import/Export tab in the Topic Builder
        """)
        
        # Display in a code block with scroll
        st.code(template_content, language="markdown")
        
        # Add a download button
        st.download_button(
            label=get_translation("download_template", "Download Template"),
            data=template_content,
            file_name="topic_generator_template.md",
            mime="text/markdown",
            use_container_width=True
        )
        
        # Add a note about customization
        st.info(get_translation("template_customization_note", 
                              "You can customize this template to generate topics about any subject you're interested in."))
        
    except Exception as e:
        st.error(f"Error loading template: {str(e)}")
        

def _render_quiz_templates():
    """Render the quiz templates interface"""
    st.header("❓ " + get_translation("quiz_templates", "Quiz Templates"))
    st.markdown(get_translation("quiz_templates_description", "Generate and customize quiz questions for your topics."))
    
    # Get user's custom topics
    topics = get_custom_topics()
    
    if not topics:
        st.info(get_translation("no_custom_topics", "You haven't created any custom topics yet. Use the Topic Templates tab to create one!"))
        return
    
    # Select a topic
    topic_options = [f"{topic['icon']} {topic['title']}" for topic in topics]
    selected_topic_display = st.selectbox(
        get_translation("select_topic", "Select a Topic"),
        options=topic_options,
        key="quiz_topic_selector"
    )
    
    # Extract selected topic
    selected_topic_index = topic_options.index(selected_topic_display)
    selected_topic = topics[selected_topic_index]
    
    # Quiz settings
    col1, col2 = st.columns(2)
    
    with col1:
        difficulty = st.selectbox(
            get_translation("difficulty", "Difficulty"),
            options=["easy", "medium", "hard"],
            format_func=lambda x: x.capitalize()
        )
    
    with col2:
        num_questions = st.slider(
            get_translation("number_of_questions", "Number of Questions"),
            min_value=1,
            max_value=10,
            value=5
        )
    
    # Generate questions button
    if st.button(get_translation("generate_quiz_templates", "Generate Quiz Templates"), key="generate_questions_btn"):
        questions = generate_quiz_questions(
            selected_topic['title'],
            difficulty,
            num_questions
        )
        
        st.session_state.current_template_questions = questions
        st.success(f"{get_translation('templates_generated', 'Templates generated!')} {len(questions)} {get_translation('questions', 'questions')}!")
    
    # Display and edit generated questions
    if "current_template_questions" in st.session_state and st.session_state.current_template_questions:
        questions = st.session_state.current_template_questions
        
        with st.form("create_quiz_form"):
            st.subheader(get_translation("create_new_quiz", "Create New Quiz"))
            
            quiz_title = st.text_input(get_translation("quiz_title", "Quiz Title"), value=f"{selected_topic['title']} Quiz")
            quiz_description = st.text_area(
                get_translation("quiz_description", "Quiz Description"),
                value=f"A {difficulty} difficulty quiz about {selected_topic['title']}."
            )
            
            st.subheader(get_translation("customize_questions", "Customize Questions"))
            
            # Make questions editable
            custom_questions = []
            for i, question in enumerate(questions):
                with st.expander(f"{get_translation('question', 'Question')} {i+1}"):
                    q_text = st.text_input(get_translation("question_text", "Question Text"), value=question["question_text"], key=f"q_text_{i}")
                    q_type = question["question_type"]
                    
                    st.write(f"**{get_translation('question_type', 'Question Type')}:** {q_type}")
                    
                    if q_type == "multiple_choice":
                        options = []
                        for j, option in enumerate(question.get("options", [])):
                            opt = st.text_input(f"{get_translation('option', 'Option')} {j+1}", value=option, key=f"opt_{i}_{j}")
                            options.append(opt)
                        
                        correct_answer = st.selectbox(
                            get_translation("correct_answer", "Correct Answer"),
                            options=options,
                            index=options.index(question["correct_answer"]) if question["correct_answer"] in options else 0,
                            key=f"correct_{i}"
                        )
                    else:  # text_input
                        options = None
                        correct_answer = st.text_input(
                            get_translation("correct_answer", "Correct Answer"),
                            value=question["correct_answer"],
                            key=f"correct_{i}"
                        )
                    
                    explanation = st.text_area(
                        get_translation("explanation", "Explanation"),
                        value=question.get("explanation", ""),
                        key=f"expl_{i}"
                    )
                    
                    # Add customized question to the list
                    custom_questions.append({
                        "question_text": q_text,
                        "question_type": q_type,
                        "options": options,
                        "correct_answer": correct_answer,
                        "explanation": explanation
                    })
            
            save_button = st.form_submit_button(get_translation("create_quiz", "Create Quiz"))
            
            if save_button:
                username = get_current_user()
                
                # Create the quiz
                created_quiz = create_custom_quiz(
                    title=quiz_title,
                    description=quiz_description,
                    topic_id=selected_topic['id'],
                    created_by=username,
                    difficulty=difficulty
                )
                
                if created_quiz:
                    # Add questions to the quiz
                    success = True
                    for question in custom_questions:
                        # Format question for storage
                        question_type = question.get('question_type', 'multiple_choice')
                        options = question.get('options', []) if question_type == "multiple_choice" else None
                        
                        result = add_quiz_question(
                            quiz_id=created_quiz['id'],
                            question_text=question.get('question_text', ''),
                            question_type=question_type,
                            correct_answer=question.get('correct_answer', ''),
                            options=options,
                            explanation=question.get('explanation', '')
                        )
                        
                        if not result:
                            success = False
                    
                    if success:
                        st.success(get_translation("quiz_created_successfully", "Quiz created successfully!"))
                        st.session_state.current_template_questions = None
                        
                        # Offer to take the quiz
                        st.info(get_translation("take_quiz_info", "You can now take the quiz from the Quiz page."))
                        if st.button(get_translation("take_quiz_now", "Take Quiz Now")):
                            st.session_state.active_custom_quiz_id = created_quiz['id']
                            st.session_state.page = "quiz"
                            st.session_state.quiz_tab = "start"  # Reset to start tab
                            st.rerun()
                    else:
                        st.warning(get_translation("quiz_created_warning", "Quiz created but some questions could not be added."))
                else:
                    st.error(get_translation("failed_to_create_quiz", "Failed to create quiz."))