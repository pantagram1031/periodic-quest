"""
Custom Topic Selector module for the Science Learning Platform.
This module provides a selection interface for custom topics.
"""
import streamlit as st
from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.topic_builder import get_custom_topics

def render():
    """Render the custom topic selector page"""
    st.title("Custom Topics")
    
    # Check if user is logged in
    if not is_logged_in():
        st.warning("Please log in to view and create custom topics.")
        if st.button("Go to Login"):
            st.session_state.page = "login"
            st.rerun()
        return
    
    # Get current user
    username = get_current_user()
    
    # Get custom topics
    custom_topics = get_custom_topics(username)
    
    # Display create new topic button
    col1, col2 = st.columns([1, 3])
    with col1:
        if st.button("Create New Topic", use_container_width=True):
            # Show template selection options
            st.session_state.template_selection_step = True
            st.rerun()
    
    # If template selection step is active, show the options
    if st.session_state.get("template_selection_step"):
        st.subheader("Choose Template Type")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### Preset Templates")
            st.markdown("Choose from pre-defined templates with common aspects and entities.")
            if st.button("Use Preset Template", use_container_width=True):
                st.session_state.page = "preset_template_selector"
                st.rerun()
        
        with col2:
            st.markdown("### Custom Template")
            st.markdown("Create a topic from scratch with your own aspects and entities.")
            if st.button("Create Custom Template", use_container_width=True):
                # Clear any existing template data
                if "topic_template" in st.session_state:
                    del st.session_state.topic_template
                st.session_state.page = "topic_create"
                st.rerun()
        
        # Add a back button
        st.divider()
        if st.button("Back", use_container_width=True):
            del st.session_state.template_selection_step
            st.rerun()
        return
    
    # Display custom topics if any exist
    if custom_topics:
        st.subheader("Your Topics")
        
        # Display topics in a grid
        cols_per_row = 2
        rows = [custom_topics[i:i+cols_per_row] for i in range(0, len(custom_topics), cols_per_row)]
        
        for row in rows:
            cols = st.columns(cols_per_row)
            
            for i, topic in enumerate(row):
                with cols[i]:
                    with st.container(border=True):
                        st.markdown(f"### {topic.get('icon', '📚')} {topic['title']}")
                        st.markdown(topic['description'])
                        
                        # Show entity count
                        entity_count = len(topic.get('entities', []))
                        st.markdown(f"**{entity_count} {topic['entity_type']}{'s' if entity_count != 1 else ''}**")
                        
                        # Show aspect count
                        aspect_count = len(topic.get('aspects', []))
                        st.markdown(f"**{aspect_count} aspects**")
                        
                        # Add select button
                        if st.button(f"Open {topic['title']}", key=f"select_{topic['id']}", use_container_width=True):
                            st.session_state.selected_topic_id = topic['id']
                            st.session_state.page = "topic_builder"
                            st.rerun()
    else:
        st.info("You haven't created any custom topics yet. Click 'Create New Topic' to get started!")
    
    # Add a back button
    st.divider()
    if st.button("Back to Home", use_container_width=True):
        st.session_state.page = "home"
        st.rerun()