"""
Home page module for the Standard Model Explorer.
"""

import streamlit as st
from utils.translations import get_translation

def render():
    """Render the Standard Model home page"""
    
    # Header and introduction
    st.markdown(f"""
    # {get_translation("standard_model_title")}
    
    The Standard Model of particle physics is one of the most successful scientific theories ever developed. 
    It explains three of the four fundamental forces of nature and classifies all known elementary particles.
    
    This interactive tool allows you to explore the particles that make up our universe and understand 
    their properties and interactions.
    """)
    
    # Main sections
    col1, col2 = st.columns([3, 2])
    
    with col1:
        st.subheader("What is the Standard Model?")
        st.markdown("""
        The Standard Model is a theory in particle physics that describes three of the four known fundamental 
        forces (electromagnetic, weak, and strong interactions - excluding gravity) and classifies all known 
        elementary particles.
        
        It's a quantum field theory that combines:
        - The electroweak theory (unifying electromagnetic and weak interactions)
        - Quantum chromodynamics (describing strong interactions)
        
        Despite its success, we know the Standard Model is incomplete. It doesn't include gravity, 
        explain dark matter or dark energy, or account for neutrino masses.
        """)
        
        st.subheader("Key Components")
        st.markdown("""
        The Standard Model includes:
        - **Fermions**: Matter particles (quarks and leptons)
        - **Gauge Bosons**: Force carrier particles
        - **Higgs Boson**: The particle associated with the Higgs field that gives other particles mass
        """)
    
    with col2:
        # Image or diagram
        st.image("https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/Standard_Model_of_Elementary_Particles.svg/800px-Standard_Model_of_Elementary_Particles.svg.png", 
                 caption="The Standard Model of Elementary Particles", 
                 use_container_width=True)
                 
        # Quick links
        st.subheader("Explore")
        st.markdown("""
        - **[Particles Visualization](particles)**: Interactive visualization of all Standard Model particles
        - **[Quiz](quiz)**: Test your knowledge of the Standard Model
        - **[Quiz History](quiz_history)**: Review your past quiz results
        """)
    
    # Additional information section
    st.markdown("---")
    st.subheader("Particle Categories")
    
    # Create three columns for the three main particle types
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        ### Quarks
        The building blocks of protons and neutrons
        
        - **Up, Down** (1st generation)
        - **Charm, Strange** (2nd generation)
        - **Top, Bottom** (3rd generation)
        
        All quarks have fractional electric charge and experience the strong force.
        """)
    
    with col2:
        st.markdown("""
        ### Leptons
        Lightweight particles that don't experience the strong force
        
        - **Electron, Electron Neutrino** (1st generation)
        - **Muon, Muon Neutrino** (2nd generation)
        - **Tau, Tau Neutrino** (3rd generation)
        
        Charged leptons (electron, muon, tau) have a -1 charge, while neutrinos are neutral.
        """)
    
    with col3:
        st.markdown("""
        ### Bosons
        Force carrier particles
        
        - **Photon** (γ): Electromagnetic force
        - **W and Z Bosons**: Weak force
        - **Gluons** (g): Strong force
        - **Higgs Boson** (H): Gives mass to particles
        
        Bosons have integer spin, unlike fermions which have half-integer spin.
        """)
    
    # Final note
    st.markdown("---")
    st.info("This tool is designed for educational purposes to help visualize and understand the Standard Model of particle physics.")