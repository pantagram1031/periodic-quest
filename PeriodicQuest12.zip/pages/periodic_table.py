"""
Periodic table page module for the Chemical Elements Explorer.
"""

import streamlit as st
from utils.periodic_table import create_periodic_table
from data.elements import get_element_by_atomic_number, get_element_by_symbol, search_elements, get_element_suggestions
from utils.translations import get_translation, get_display_name

def render():
    """Render the periodic table page"""
    st.title(get_translation("periodic_table_title"))
    
    # Initialize session state for element description display
    if "show_element_description" not in st.session_state:
        st.session_state.show_element_description = False
    if "current_element_description" not in st.session_state:
        st.session_state.current_element_description = None
    
    st.markdown(get_translation("periodic_table_intro"))
    
    # Element categories legend at the top
    st.subheader(get_translation("element_categories"))
    from data.elements import CATEGORIES
    
    # Display the categories in a horizontal grid at the top
    legend_cols = st.columns(5)  # Show 5 categories per row
    category_items = list(CATEGORIES.items())
    
    # Remove 'unknown' category
    category_items = [(cat, color) for cat, color in category_items if cat != 'unknown']
    
    # Display the legend in rows of 5
    for i, (category, color) in enumerate(category_items):
        col_index = i % 5  # 5 columns per row
        with legend_cols[col_index]:
            st.markdown(
                f"""
                <div style="
                    background-color: {color}; 
                    padding: 5px; 
                    border-radius: 5px; 
                    margin-bottom: 5px;
                    text-align: center;
                    color: black;
                    font-size: 0.8em;
                ">
                    {category.capitalize()}
                </div>
                """, 
                unsafe_allow_html=True
            )
    
    # Add a toggle for direct navigation to element pages
    st.markdown("### " + get_translation("direct_navigation"))
    
    # Use a simple button to toggle direct navigation mode
    direct_nav = st.session_state.direct_navigation
    
    # For clarity, display the current mode
    current_mode_text = "Direct mode: ON" if direct_nav else "Direct mode: OFF"
    mode_color = "green" if direct_nav else "gray"
    
    st.markdown(f"<p style='color:{mode_color}; font-weight:bold;'>{current_mode_text}</p>", unsafe_allow_html=True)
    
    # Button to toggle navigation mode
    if st.button("Toggle direct navigation", key="direct_nav_btn"):
        # Toggle the mode
        st.session_state.direct_navigation = not st.session_state.direct_navigation
        st.rerun()
    
    # Check if we need to highlight a specific element
    highlight_element = None
    if 'highlight_element' in st.session_state:
        highlight_element = st.session_state.highlight_element
        # Clear the highlight flag after using it once
        # (so it doesn't stay highlighted if the user navigates away and back)
        # We'll keep it in this render call but remove it for future renders
        st.session_state.highlight_element = None
    
    # Create the interactive periodic table with highlighted element if needed
    # Use mobile mode if enabled in session state
    mobile_mode = st.session_state.mobile_mode if "mobile_mode" in st.session_state else False
    fig = create_periodic_table(highlight_atomic_number=highlight_element, mobile_mode=mobile_mode)
    
    # Display the periodic table with click event handling
    # Use a custom key to ensure the chart rerenders with the highlight
    plotly_key = f"periodic_table_{highlight_element if highlight_element else 'default'}"
    
    # Add specific styling for mobile mode
    if mobile_mode:
        # Use an HTML container with fixed positioning for better mobile view
        st.markdown("""
        <style>
        /* Create a fixed container for the periodic table */
        .fixed-chart-container {
            width: 100%;
            overflow: hidden;
            background-color: #f0f0f0;
            padding: 8px 0;
            border-radius: 8px;
            border: 1px solid #ddd;
            margin-bottom: 10px;
        }
        .fixed-chart-container iframe {
            display: block;
            border: none;
            width: 100%;
            margin: 0 auto;
        }
        /* Increase clickable area on mobile */
        g.points path {
            stroke-width: 12px;
        }
        /* Set a fixed display for Streamlit elements */
        .stPlotlyChart {
            overflow: hidden !important;
        }
        </style>

        <div class="periodic-table-instructions">
            <p style="color: #0366d6; font-weight: bold; font-size: 14px; text-align: center; margin-bottom: 5px;">
                Fixed periodic table for easier viewing
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Mobile-specific instructions with updated guidance
        st.warning("""
        **Mobile View Tips:**
        - The table is fixed for better viewing
        - Use the element list below for easier element selection
        - Tap an element in the table to view its details
        """)
        
        # Create a simpler explanation of categories for mobile
        st.info("Each color represents a different element category (metals, non-metals, etc.)")
    
    # Set up a container to capture the chart click return value
    click_container = st.container()
    with click_container:
        # Display the plot and capture the click return value
        # Using on_click_param='customdata' to ensure proper click event data capture
        # This setting tells Plotly to include customdata in the clickData event
        # For mobile, we need additional config for better touch interaction
        config = {
            'displayModeBar': mobile_mode,  # Show mode bar for zooming on mobile
            'responsive': True,            # Make the chart responsive
            'scrollZoom': mobile_mode,     # Enable scroll zoom on mobile for better navigation
            'modeBarButtonsToRemove': ['lasso2d', 'select2d', 'autoScale2d'], # Remove unnecessary buttons
            'toImageButtonOptions': {'format': 'png', 'filename': 'periodic_table'}, # For download option
            'displaylogo': False,          # Remove plotly logo
        }
        
        # Add mobile-specific config options
        if mobile_mode:
            config.update({
                'staticPlot': True,        # Make the plot fixed (no panning or zooming)
                'editable': False,         # Prevent editing
                'modeBarButtonsToAdd': [], # Remove all additional buttons for simplicity
            })
        
        # For mobile mode, we wrap the chart in a scrollable container
        if mobile_mode:
            # First render the chart to a variable (don't display it yet)
            html_chart = fig.to_html(
                include_plotlyjs='cdn',
                config=config,
                full_html=False,
            )
            
            # Now wrap the chart in a fixed container
            fixed_container = f"""
            <div class="fixed-chart-container">
                {html_chart}
            </div>
            """
            
            # Display the wrapped chart
            st.markdown(fixed_container, unsafe_allow_html=True)
            
            # Also render the regular chart (but with height=0 to hide it) 
            # to maintain the Streamlit chart functionality for click events
            chart_data = st.plotly_chart(
                fig, 
                use_container_width=True, 
                key=plotly_key, 
                return_fig_js=True,
                config=config,
                height=1  # Almost invisible but still functional
            )
        else:
            # Standard rendering for desktop
            chart_data = st.plotly_chart(
                fig, 
                use_container_width=True, 
                key=plotly_key, 
                return_fig_js=True,
                config=config
            )
    
    # Handle click events from the plotly chart
    # Wrap this in try-except to handle various edge cases
    try:
        # Add debug output to help troubleshoot click events
        if chart_data and isinstance(chart_data, dict):
            # Check if we have click data available
            if 'clickData' in chart_data:
                click_data = chart_data['clickData']
                if click_data and 'points' in click_data and len(click_data['points']) > 0:
                    point = click_data['points'][0]
                    
                    # Log the point data to help debug
                    # st.write(f"Debug - Point data: {point}")  # Uncomment for debugging
                    
                    if 'customdata' in point and point['customdata'] is not None:
                        atomic_number = int(point['customdata'][0])
                        # Get element information
                        from data.elements import get_element_by_atomic_number
                        element = get_element_by_atomic_number(atomic_number)
                        
                        if element:
                            # Display a message about the clicked element
                            st.info(f"Clicked on element: {element['name']} (#{element['atomic_number']})")
                            
                            if st.session_state.direct_navigation:
                                # Navigate directly to the element details page
                                st.session_state.selected_element = element
                                st.session_state.page = "element_details"
                                st.rerun()
                            else:
                                # Show element description in the current page
                                st.session_state.current_element_description = element
                                st.session_state.show_element_description = True
                                st.session_state.highlight_element = atomic_number
                                st.rerun()
    except Exception as e:
        # For debugging only, show the error to help identify issues
        st.error(f"Error handling click: {str(e)}")
        import traceback
        st.error(f"Traceback: {traceback.format_exc()}")
    
    # Process click events from the plotly chart
    # This requires JavaScript interaction which Streamlit doesn't directly support
    # Instead, we'll use Streamlit's built-in features for interaction
    st.markdown("""
    <div style="text-align: center; margin-top: 10px; margin-bottom: 15px;">
        <p style="color: #666;">Click on any element in the table to view its details</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Element description section below the periodic table
    st.markdown("---")
    
    # Element details section
    if st.session_state.show_element_description and st.session_state.current_element_description:
        element = st.session_state.current_element_description
        
        # Use columns for desktop, single column for mobile
        mobile_mode = st.session_state.mobile_mode if "mobile_mode" in st.session_state else False
        
        if mobile_mode:
            # Single column layout for mobile
            col_main = st.container()
            col1 = col_main
            col2 = col_main
        else:
            # Use columns for a better desktop layout
            col1, col2 = st.columns([1, 2])
        
        with col1:
            # Display element information with proper name formatting based on language
            display_name = get_display_name(element)
            st.markdown(f"## {display_name} ({element['symbol']})")
            
            # Color box for the element category
            from data.elements import get_element_color
            category_color = get_element_color(element['category'])
            
            # Get translated category label
            category_label = get_translation("category")
            
            st.markdown(
                f"""
                <div style="background-color: {category_color}; padding: 10px; border-radius: 5px; margin-bottom: 10px;">
                    <p style="margin: 0; color: black;"><strong>{category_label}:</strong> {element['category'].capitalize()}</p>
                </div>
                """, 
                unsafe_allow_html=True
            )
            
            # Translate static labels
            group_text = element['group'] if element['group'] is not None else get_translation("not_applicable")
            discovered_by = element['discovered_by'] if element['discovered_by'] else get_translation("ancient")
            discovery_year = element['discovery_year'] if element['discovery_year'] else get_translation("unknown")
            
            st.markdown(f"""
            **{get_translation("atomic_number")}:** {element['atomic_number']}  
            **{get_translation("atomic_weight")}:** {element['atomic_weight']}  
            **{get_translation("group")}:** {group_text}  
            **{get_translation("period")}:** {element['period']}  
            **{get_translation("electron_configuration")}:** {element['electron_configuration']}  
            **{get_translation("discovered_by")}:** {discovered_by}  
            **{get_translation("discovery_year")}:** {discovery_year}  
            """)
        
        with col2:
            st.markdown(f"### {get_translation('description')}")
            
            # If the language is set to Korean, show Korean description first if available
            if st.session_state.language == "Korean":
                if 'korean_description' in element and element['korean_description']:
                    # Show Korean description directly when language is Korean
                    st.markdown(element['korean_description'])
                    
                    # Add more detailed information in Korean if available
                    if 'electron_configuration' in element:
                        st.markdown(f"**전자 배치**: {element['electron_configuration']}")
                    
                    if 'uses' in element and element['uses']:
                        st.markdown(f"**주요 용도**: {element['uses']}")
                    
                    if 'discovered_by' in element and element['discovered_by']:
                        discovered_by = element['discovered_by']
                        discovery_year = element['discovery_year'] if 'discovery_year' in element and element['discovery_year'] else get_translation("unknown")
                        st.markdown(f"**발견**: {discovered_by} ({discovery_year})")
                else:
                    # Show a message that Korean description is not available
                    st.info(get_translation("korean_description_not_available"))
                    # Fall back to English description with Korean headers
                    st.markdown(f"{element['description']}")
                    
                    # Add more detailed information with Korean headers
                    if 'electron_configuration' in element:
                        st.markdown(f"**전자 배치**: {element['electron_configuration']}")
                    
                    if 'uses' in element and element['uses']:
                        st.markdown(f"**주요 용도**: {element['uses']}")
                    
                    if 'discovered_by' in element and element['discovered_by']:
                        discovered_by = element['discovered_by']
                        discovery_year = element['discovery_year'] if 'discovery_year' in element and element['discovery_year'] else get_translation("unknown")
                        st.markdown(f"**발견**: {discovered_by} ({discovery_year})")
            else:
                # For English language, show English description
                st.markdown(f"{element['description']}")
                
                # Add additional details in English
                if 'uses' in element and element['uses']:
                    st.markdown(f"**Common Uses**: {element['uses']}")
                
                if 'discovered_by' in element and element['discovered_by']:
                    discovered_by = element['discovered_by']
                    discovery_year = element['discovery_year'] if 'discovery_year' in element and element['discovery_year'] else get_translation("unknown")
                    st.markdown(f"**Discovery**: {discovered_by} ({discovery_year})")
            
            # Additional physical properties if available
            st.markdown(f"### {get_translation('physical_properties')}")
            st.markdown(f"""
            **{get_translation('melting_point')}:** {element['melting_point']} K  
            **{get_translation('boiling_point')}:** {element['boiling_point']} K  
            **{get_translation('density')}:** {element['density']} g/cm³  
            """)
            
            # Buttons to view full details or go back to periodic table
            col1, col2 = st.columns(2)
            with col1:
                view_details_text = get_translation("view_details")
                if st.button(view_details_text, key="view_full_details", use_container_width=True):
                    st.session_state.selected_element = element
                    st.session_state.page = "element_details"
                    st.rerun()
            with col2:
                # Button to scroll back to the periodic table
                if st.button("Back to Table", key="back_to_table", use_container_width=True):
                    # Clear element description to show just the table
                    st.session_state.show_element_description = False
                    st.rerun()
    else:
        st.info("👆 Click on any element in the periodic table above to view its detailed information here.")
    
    # Direct element selection with customizable sorting and layout
    st.markdown(f"### {get_translation('direct_element_selection')}")
    st.write(get_translation("select_element_by_symbol"))
    
    # Create a grid of buttons for quick element selection
    from data.elements import elements_df
    
    # We now initialize session state in the main app.py file
    
    # Create sorting and layout options
    with st.container():
        # Check if mobile mode is enabled
        mobile_mode = st.session_state.mobile_mode if "mobile_mode" in st.session_state else False
        
        if mobile_mode:
            # Stacked layout for mobile - one option per row
            # Sorting options
            sort_options = {
                "atomic_number": get_translation("atomic_number") if "atomic_number" in get_translation("atomic_number") else "Atomic Number",
                "symbol": get_translation("symbol") if "symbol" in get_translation("symbol") else "Symbol",
                "name": get_translation("name") if "name" in get_translation("name") else "Name",
                "category": get_translation("category") if "category" in get_translation("category") else "Category",
                "period": get_translation("period") if "period" in get_translation("period") else "Period"
            }
            
            selected_sort = st.selectbox(
                get_translation("sort_by"),
                options=list(sort_options.keys()),
                format_func=lambda x: sort_options[x],
                index=list(sort_options.keys()).index(st.session_state.element_sort_by),
                key="sort_selector"
            )
            st.session_state.element_sort_by = selected_sort
            
            # Layout options (vertical or horizontal)
            layout_options = {
                "vertical": get_translation("vertical") if "vertical" in get_translation("vertical") else "Vertical",
                "horizontal": get_translation("horizontal") if "horizontal" in get_translation("horizontal") else "Horizontal"
            }
            
            selected_layout = st.selectbox(
                get_translation("layout"),
                options=list(layout_options.keys()),
                format_func=lambda x: layout_options[x],
                index=list(layout_options.keys()).index(st.session_state.element_layout),
                key="layout_selector"
            )
            st.session_state.element_layout = selected_layout
        else:
            # Side-by-side layout for desktop
            col1, col2 = st.columns(2)
            with col1:
                # Sorting options
                sort_options = {
                    "atomic_number": get_translation("atomic_number") if "atomic_number" in get_translation("atomic_number") else "Atomic Number",
                    "symbol": get_translation("symbol") if "symbol" in get_translation("symbol") else "Symbol",
                    "name": get_translation("name") if "name" in get_translation("name") else "Name",
                    "category": get_translation("category") if "category" in get_translation("category") else "Category",
                    "period": get_translation("period") if "period" in get_translation("period") else "Period"
                }
                
                selected_sort = st.selectbox(
                    get_translation("sort_by"),
                    options=list(sort_options.keys()),
                    format_func=lambda x: sort_options[x],
                    index=list(sort_options.keys()).index(st.session_state.element_sort_by),
                    key="sort_selector"
                )
                st.session_state.element_sort_by = selected_sort
                
            with col2:
                # Layout options (vertical or horizontal)
                layout_options = {
                    "vertical": get_translation("vertical") if "vertical" in get_translation("vertical") else "Vertical",
                    "horizontal": get_translation("horizontal") if "horizontal" in get_translation("horizontal") else "Horizontal"
                }
                
                selected_layout = st.selectbox(
                    get_translation("layout"),
                    options=list(layout_options.keys()),
                    format_func=lambda x: layout_options[x],
                    index=list(layout_options.keys()).index(st.session_state.element_layout),
                    key="layout_selector"
                )
                st.session_state.element_layout = selected_layout
    
    # Get a copy of the elements dataframe
    elements = elements_df.copy()
    
    # Sort elements according to user preference
    if st.session_state.element_sort_by == "atomic_number":
        elements = elements.sort_values(by="atomic_number")
    elif st.session_state.element_sort_by == "symbol":
        elements = elements.sort_values(by="symbol")
    elif st.session_state.element_sort_by == "name":
        elements = elements.sort_values(by="name")
    elif st.session_state.element_sort_by == "category":
        elements = elements.sort_values(by=["category", "atomic_number"])
    elif st.session_state.element_sort_by == "period":
        elements = elements.sort_values(by=["period", "group"])
    
    # Create element grid based on layout preference and mobile mode
    mobile_mode = st.session_state.mobile_mode if "mobile_mode" in st.session_state else False
    
    # In mobile mode, always use a fixed grid layout that works well on small screens
    # regardless of user's layout preference
    if mobile_mode:
        # For mobile, create a simpler table-based layout with two elements per row
        st.write("##### Direct Element Selection")
        
        # Show the current sorting category
        st.caption(f"Sorted by: {st.session_state.element_sort_by.capitalize()}")
        
        # Create a grid using Streamlit components for better mobile compatibility
        with st.container():
            # We'll create a grid of elements using Streamlit columns
            # Process elements in groups of 2 for the mobile layout
            batch_size = 2  # 2 elements per row on mobile
            
            # Add custom styling for the element buttons with better responsiveness
            st.markdown("""
            <style>
            /* Style for mobile element grid - always 2 elements per row */
            .stPlaceholder [data-testid="stHorizontalBlock"] {
                flex-wrap: nowrap !important;
                gap: 5px !important;
            }
            
            /* Responsive button styling so they stay aligned */
            .element-button {
                width: 100% !important;
                min-height: 30px !important;
                padding: 0 !important;
                border-radius: 0 !important;
            }
            
            /* Make the element blocks more visible on mobile */
            div[data-testid="column"] > div[data-baseweb="card"] {
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                height: 120px !important;
                padding: 0;
                margin: 0;
            }
            </style>
            """, unsafe_allow_html=True)
            
            # Create a grid of elements - 2 per row
            # Process elements in groups of 2 for the mobile layout
            batch_size = 2  # Always use 2 columns on mobile
            
            # Let's use a simple reliable approach with Streamlit's built-in columns
            # Process elements in batches of 2 for the mobile view
            
            st.markdown("## Periodic Table Elements")
            st.markdown("Click on an element in the dropdown below to view details")
            
            # Show elements in a simple 2-column grid without complicated HTML
            for i in range(0, len(elements), 2):
                # Create a row with 2 columns
                cols = st.columns(2)
                
                # Get elements for this row (up to 2)
                row_elements = elements.iloc[i:min(i+2, len(elements))]
                
                # Add elements to columns
                for j, (_, element) in enumerate(row_elements.iterrows()):
                    if j < len(cols):  # Make sure we don't exceed column count
                        with cols[j]:
                            # Extract element data
                            symbol = element['symbol']
                            atomic_number = element['atomic_number']
                            name = element['name']
                            category = element['category']
                            
                            # Get the category color
                            from data.elements import get_element_color
                            category_color = get_element_color(category)
                            
                            # Create a container with CSS for the element
                            st.markdown(f"""
                            <div style="
                                background-color: {category_color};
                                border-radius: 8px;
                                padding: 8px 4px;
                                height: 120px;
                                text-align: center;
                                border: 1px solid #333;
                                margin-bottom: 8px;
                            ">
                                <div style="font-size: 28px; font-weight: bold;">{symbol}</div>
                                <div style="font-size: 16px;">{atomic_number}</div>
                                <div style="font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{name}</div>
                            </div>
                            """, unsafe_allow_html=True)
            
            # Use a standard approach for element selection that works on all devices
            st.markdown("### Select an Element")
            
            # Create a dropdown with all elements
            element_options = [(i, f"{el['symbol']} ({el['atomic_number']}) - {el['name']}") 
                              for i, (_, el) in enumerate(elements.iterrows())]
            
            selected_element_idx = st.selectbox(
                "Choose an element:",
                options=range(len(element_options)),
                format_func=lambda x: element_options[x][1],
                key="mobile_element_select",
                label_visibility="collapsed"
            )
            
            if st.button("View Element Details", use_container_width=True, key="mobile_view_details"):
                # Get the selected element
                element_dict = elements.iloc[selected_element_idx].to_dict()
                
                # Handle based on navigation preference
                if st.session_state.direct_navigation:
                    st.session_state.selected_element = element_dict
                    st.session_state.page = "element_details"
                    st.rerun()
                else:
                    # Show element description
                    st.session_state.current_element_description = element_dict
                    st.session_state.show_element_description = True
                    st.session_state.highlight_element = element_dict['atomic_number']
                    st.rerun()
        
        # Skip the rest of the layout code for mobile mode
        pass
        
    # For desktop, use the original vertical/horizontal layout as selected
    elif st.session_state.element_layout == "vertical":
        # Vertical layout (traditional grid)
        # Define how many columns to show for desktop
        cols_per_row = 8  # 8 columns for desktop vertical layout
        
        # Create rows of elements
        for i in range(0, len(elements), cols_per_row):
            # Get elements for this row
            row_elements = elements.iloc[i:min(i + cols_per_row, len(elements))]
            
            # Create columns for buttons
            cols = st.columns(min(cols_per_row, len(row_elements)))
            
            # Add buttons for each element in this row
            for j, (_, element) in enumerate(row_elements.iterrows()):
                with cols[j]:
                    symbol = element['symbol']
                    atomic_number = element['atomic_number']
                    # Use both symbol and atomic number for better visibility
                    button_label = f"{symbol}\n{atomic_number}"
                    
                    # Use the row and column indices as part of the key to ensure uniqueness
                    if st.button(button_label, key=f"el_btn_idx_{i}_{j}_{_}"):
                        element_dict = element.to_dict()
                        # Show element description and highlight in periodic table
                        st.session_state.current_element_description = element_dict
                        st.session_state.show_element_description = True
                        st.session_state.highlight_element = atomic_number
                        st.rerun()
    else:
        # Horizontal layout (list style) with category boxes
        # Set the default number of columns per row for wrapping based on device
        mobile_mode = st.session_state.mobile_mode if "mobile_mode" in st.session_state else False
        cols_per_row = 5 if mobile_mode else 10  # Fewer columns on mobile for better touch targets
        
        # Group elements by category or another property if needed
        if st.session_state.element_sort_by == "category":
            # Group by category first
            categories = sorted(elements['category'].unique())
            
            for category in categories:
                # Get category color for consistency
                from data.elements import get_element_color
                category_color = get_element_color(category)
                category_bg_color = f"rgba{tuple(int(category_color.lstrip('#')[i:i+2], 16) for i in (0, 2, 4)) + (0.2,)}"
                
                # Create a container with border and background for this category
                with st.container():
                    st.markdown(f"""
                    <div style="border: 1px solid {category_color}; 
                                border-radius: 10px; 
                                padding: 10px; 
                                margin-bottom: 15px;
                                background-color: {category_bg_color};">
                        <h3 style="margin-top: 0;">{category.capitalize()}</h3>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Get elements in this category
                    category_elements = elements[elements['category'] == category]
                    
                    # Calculate how many elements to fit in each row for proper wrapping
                    # We'll create a flexible grid for better wrapping behavior
                    elements_html = ""
                    
                    for _, element in category_elements.iterrows():
                        symbol = element['symbol']
                        atomic_number = element['atomic_number']
                        name = element['name']
                        
                        # Create a custom HTML for each element button with direct navigation handling
                        element_id = f"el_btn_cat_{category}_{atomic_number}"
                        
                        # Create HTML for an element button
                        elements_html += f"""
                        <div class="element-box" 
                             id="{element_id}" 
                             onclick="handleElementClick({atomic_number});"
                             style="display: inline-block; 
                                    width: 80px; 
                                    height: 80px; 
                                    margin: 5px;
                                    padding: 5px;
                                    text-align: center;
                                    background-color: {category_color};
                                    border: 1px solid #333;
                                    border-radius: 5px;
                                    cursor: pointer;
                                    color: black;
                                    overflow: hidden;
                                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                            <div style="font-size: 20px; font-weight: bold;">{symbol}</div>
                            <div style="font-size: 12px;">{atomic_number}</div>
                            <div style="font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{name}</div>
                        </div>
                        """
                    
                    # For the horizontal layout, we'll use a simpler approach with Streamlit components
                    # instead of trying to use JavaScript which is having issues
                    
                    # Create flexible columns for wrapping based on device
                    cols = st.columns(cols_per_row)
                    
                    # Add buttons for each element in this category
                    for i, (_, element) in enumerate(category_elements.iterrows()):
                        col_index = i % cols_per_row  # Distribute across cols_per_row columns
                        with cols[col_index]:
                            symbol = element['symbol']
                            atomic_number = element['atomic_number']
                            name = element['name']
                            
                            # Create a unique key for each button
                            button_key = f"cat_btn_{category}_{atomic_number}_{i}"
                            
                            # Use st.container with markdown to create custom styled buttons
                            with st.container():
                                # Create a styled button-like element with markdown
                                html = f"""
                                <div style="
                                    background-color: {category_color};
                                    border-radius: 5px;
                                    padding: 5px;
                                    margin: 2px 0;
                                    text-align: center;
                                    cursor: pointer;
                                    color: black;
                                    border: 1px solid #333;
                                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                                ">
                                    <div style="font-size: 16px; font-weight: bold;">{symbol}</div>
                                    <div style="font-size: 10px;">{atomic_number}</div>
                                    <div style="font-size: 9px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{name}</div>
                                </div>
                                """
                                st.markdown(html, unsafe_allow_html=True)
                                
                                # Use an invisible button over the styled div for the actual click handling
                                if st.button("", key=button_key, help=f"{name} (Z={atomic_number})"):
                                    element_dict = element.to_dict()
                                    # Handle based on navigation preference
                                    if st.session_state.direct_navigation:
                                        st.session_state.selected_element = element_dict
                                        st.session_state.page = "element_details"
                                    else:
                                        # Show element description and highlight in periodic table
                                        st.session_state.current_element_description = element_dict
                                        st.session_state.show_element_description = True
                                        st.session_state.highlight_element = atomic_number
                                    st.rerun()
        else:
            # Simple horizontal listing without grouping but with improved wrapping
            # Create a container for all elements
            with st.container():
                # For the horizontal layout with no category grouping, we'll use streamlit components
                # instead of trying to use JavaScript which is having issues
                
                # Create flexible columns for wrapping based on device
                cols = st.columns(cols_per_row)
                
                # Add buttons for each element
                for i, (_, element) in enumerate(elements.iterrows()):
                    col_index = i % cols_per_row  # Distribute across cols_per_row columns
                    with cols[col_index]:
                        symbol = element['symbol']
                        atomic_number = element['atomic_number']
                        name = element['name']
                        category = element['category']
                        
                        # Get color based on category
                        from data.elements import get_element_color
                        category_color = get_element_color(category)
                        
                        # Create a unique key for each button
                        button_key = f"hor_btn_{atomic_number}_{i}"
                        
                        # Use st.container with markdown to create custom styled buttons
                        with st.container():
                            # Create a styled button-like element with markdown
                            html = f"""
                            <div style="
                                background-color: {category_color};
                                border-radius: 5px;
                                padding: 5px;
                                margin: 2px 0;
                                text-align: center;
                                cursor: pointer;
                                color: black;
                                border: 1px solid #333;
                                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                            ">
                                <div style="font-size: 16px; font-weight: bold;">{symbol}</div>
                                <div style="font-size: 10px;">{atomic_number}</div>
                                <div style="font-size: 9px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{name}</div>
                            </div>
                            """
                            st.markdown(html, unsafe_allow_html=True)
                            
                            # Use an invisible button over the styled div for the actual click handling
                            if st.button("", key=button_key, help=f"{name} (Z={atomic_number})"):
                                element_dict = element.to_dict()
                                # Handle based on navigation preference
                                if st.session_state.direct_navigation:
                                    st.session_state.selected_element = element_dict
                                    st.session_state.page = "element_details"
                                else:
                                    # Show element description and highlight in periodic table
                                    st.session_state.current_element_description = element_dict
                                    st.session_state.show_element_description = True
                                    st.session_state.highlight_element = atomic_number
                                st.rerun()
    
    # Element search box with preview
    st.markdown("---")
    st.subheader(get_translation("search_elements"))
    
    search_col1, search_col2 = st.columns([3, 1])
    
    with search_col1:
        search_query = st.text_input(get_translation("search_placeholder"), key="pt_search")
    
    # Show search preview as the user types
    if search_query and len(search_query) >= 1:
        # Show suggestions as the user types (for partial queries)
        if len(search_query) <= 3:
            suggestions = get_element_suggestions(search_query)
            if suggestions:
                st.write(f"{get_translation('suggestions')}:")
                suggestion_cols = st.columns(min(5, len(suggestions)))
                
                for i, element in enumerate(suggestions):
                    with suggestion_cols[i]:
                        # Use display name to show Korean name if appropriate
                        display_name = get_display_name(element)
                        if st.button(f"{element['symbol']} ({display_name})", key=f"pt_suggest_{element['atomic_number']}"):
                            st.session_state.current_element_description = element
                            st.session_state.show_element_description = True
                            st.rerun()
        
        # Get preview results
        preview_results = search_elements(search_query)
        
        # Show search preview
        if preview_results:
            found_msg = get_translation("found_elements").format(len(preview_results))
            st.success(found_msg)
            
            # Show quick preview buttons for top 5 matches
            if len(preview_results) > 0:
                st.write(f"{get_translation('quick_preview')}:")
                preview_cols = st.columns(min(5, len(preview_results)))
                
                for i, element in enumerate(preview_results[:5]):
                    with preview_cols[i]:
                        display_name = get_display_name(element)
                        if st.button(f"{element['symbol']} - {display_name}", key=f"pt_preview_{element['atomic_number']}"):
                            st.session_state.current_element_description = element
                            st.session_state.show_element_description = True
                            st.rerun()
            
            # Show full results
            for element in preview_results:
                # Format title using display name function
                display_name = get_display_name(element)
                title = f"{display_name} ({element['symbol']})"
                
                with st.expander(title):
                    col1, col2 = st.columns([1, 3])
                    
                    with col1:
                        st.markdown(f"""
                        ### {display_name}
                        **{get_translation("symbol")}:** {element['symbol']}  
                        **{get_translation("atomic_number")}:** {element['atomic_number']}  
                        **{get_translation("category")}:** {element['category'].capitalize()}  
                        """)
                        
                        if st.button(get_translation("view_details"), key=f"pt_view_{element['atomic_number']}"):
                            st.session_state.current_element_description = element
                            st.session_state.show_element_description = True
                            st.rerun()
                    
                    with col2:
                        # Get appropriate description based on language
                        description = element['korean_description'] if st.session_state.language == "Korean" and 'korean_description' in element and element['korean_description'] else element['description']
                        
                        discovered_by = element['discovered_by'] if element['discovered_by'] else get_translation("unknown")
                        discovery_year = element['discovery_year'] if element['discovery_year'] else get_translation("ancient")
                        
                        st.markdown(f"""
                        **{get_translation("atomic_weight")}:** {element['atomic_weight']} u  
                        **{get_translation("electron_configuration")}:** {element['electron_configuration']}  
                        **{get_translation("discovered_by")}:** {discovered_by}  
                        **{get_translation("discovery_year")}:** {discovery_year}
                        
                        {description[:200]}...
                        """)
        else:
            st.error(get_translation("no_results"))
    
    # Navigation buttons
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button(get_translation("back_to_home"), use_container_width=True):
            st.session_state.page = "home"
            st.rerun()
    
    with col2:
        if st.button(get_translation("take_a_quiz"), use_container_width=True):
            st.session_state.page = "quiz"
            st.rerun()
    
    # No duplicate category legend needed - we already have it at the top
