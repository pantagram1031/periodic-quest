"""
Topic Creation module for the Science Learning Platform.
This module provides a unified interface for creating new topics, whether from a preset template or custom.
"""
import streamlit as st
from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.topic_builder import create_topic, update_topic

def render():
    """Render the topic creation page"""
    st.title("Create New Topic")
    
    # Check if user is logged in
    if not is_logged_in():
        st.warning("Please log in to create a topic.")
        if st.button("Go to Login"):
            st.session_state.page = "login"
            st.rerun()
        return
    
    # Get current user
    username = get_current_user()
    
    # Define available presets
    PRESETS = {
        "Custom Topic": {
            "title": "",
            "description": "",
            "icon": "📚",
            "entity_type": "item",
            "aspects": []
        },
        "Chemical Elements": {
            "title": "Chemical Elements",
            "description": "A collection of chemical elements with their properties",
            "icon": "⚗️",
            "entity_type": "element",
            "aspects": [
                {
                    "id": "name",
                    "name": "Name",
                    "type": "text",
                    "description": "Element name",
                    "is_required": True,
                    "is_searchable": True,
                    "is_quiz_field": True
                },
                {
                    "id": "symbol",
                    "name": "Symbol",
                    "type": "text",
                    "description": "Element symbol",
                    "is_required": True,
                    "is_searchable": True,
                    "is_quiz_field": True
                },
                {
                    "id": "atomic_number",
                    "name": "Atomic Number",
                    "type": "number",
                    "description": "Element's atomic number",
                    "is_required": True,
                    "is_searchable": True,
                    "is_quiz_field": True
                }
            ]
        },
        "Particles": {
            "title": "Particles",
            "description": "A collection of particles with their properties",
            "icon": "⚛️",
            "entity_type": "particle",
            "aspects": [
                {
                    "id": "name",
                    "name": "Name",
                    "type": "text",
                    "description": "Particle name",
                    "is_required": True,
                    "is_searchable": True,
                    "is_quiz_field": True
                },
                {
                    "id": "type",
                    "name": "Type",
                    "type": "text",
                    "description": "Particle type (e.g., fermion, boson)",
                    "is_required": True,
                    "is_searchable": True,
                    "is_quiz_field": True
                },
                {
                    "id": "mass",
                    "name": "Mass",
                    "type": "number",
                    "description": "Particle mass",
                    "is_required": True,
                    "is_searchable": True,
                    "is_quiz_field": True
                }
            ]
        }
    }
    
    # Initialize form
    with st.form("topic_creation_form"):
        # Get template data if available
        template = st.session_state.get("topic_template")
        
        # Preset selection
        selected_preset = st.selectbox(
            "Select a Preset",
            options=list(PRESETS.keys()),
            key="topic_preset"
        )
        
        # Initialize topic data
        topic_data = {
            "title": "",
            "description": "",
            "icon": "📚",
            "entity_type": "",
            "aspects": []
        }
        
        # Update with preset data if selected
        if selected_preset != "Custom Topic":
            preset_data = PRESETS[selected_preset]
            topic_data.update(preset_data)
        
        # Update with template data if available
        if template:
            topic_data.update({
                "title": template.get("name", ""),
                "description": template.get("description", ""),
                "entity_type": "element" if template.get("id") == "periodic_table" else
                              "particle" if template.get("id") == "standard_model" else
                              "event" if template.get("id") == "historical_events" else "",
                "aspects": template.get("aspects", [])
            })
        
        # Topic title
        topic_data["title"] = st.text_input(
            "Topic Title",
            value=topic_data["title"],
            help="Enter a descriptive title for your topic"
        )
        
        # Topic description
        topic_data["description"] = st.text_area(
            "Description",
            value=topic_data["description"],
            help="Provide a brief description of your topic"
        )
        
        # Entity type name
        topic_data["entity_type"] = st.text_input(
            "Entity Type Name",
            value=topic_data["entity_type"],
            help="What type of entities will this topic contain? (e.g., elements, particles, events)"
        )
        
        # Icon selection
        topic_data["icon"] = st.selectbox(
            "Icon",
            options=["⚛️", "🔬", "📅", "🌍", "🧪", "🔭", "📚", "🎯"],
            index=["⚛️", "🔬", "📅", "🌍", "🧪", "🔭", "📚", "🎯"].index(topic_data["icon"]),
            help="Select an icon to represent your topic"
        )
        
        # Submit button
        submitted = st.form_submit_button("Create Topic")
        
        if submitted:
            if not topic_data["title"] or not topic_data["description"] or not topic_data["entity_type"]:
                st.error("Please fill in all required fields.")
            else:
                try:
                    # Create the topic
                    topic_id = create_topic(
                        title=topic_data["title"],
                        description=topic_data["description"],
                        entity_type=topic_data["entity_type"],
                        creator=username
                    )
                    
                    # Update the topic with aspects
                    if topic_data["aspects"]:
                        update_topic(
                            topic_id=topic_id,
                            aspects=topic_data["aspects"]
                        )
                    
                    # Store the created topic ID and topic data
                    st.session_state.created_topic_id = topic_id
                    st.session_state.topic_id = topic_id
                    st.session_state.topic_data = topic_data
                    
                    # Clear template data
                    if "topic_template" in st.session_state:
                        del st.session_state.topic_template
                    
                    # Clear custom topics from session state to force refresh
                    if "custom_topics" in st.session_state:
                        del st.session_state.custom_topics
                    
                    # Navigate to topic builder
                    st.session_state.page = "topic_builder"
                    st.rerun()
                    
                except Exception as e:
                    st.error(f"Error creating topic: {str(e)}")
    
    # Add a back button
    st.divider()
    if st.button("Back to Template Selection", use_container_width=True):
        st.session_state.page = "preset_template_selector"
        st.rerun() 