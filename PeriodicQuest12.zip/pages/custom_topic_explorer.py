"""
Custom Topic Explorer module for the Science Learning Platform.
This module provides a standardized view for exploring custom topics,
with a navigation structure similar to the Chemical Elements and Standard Model explorers.
"""
import streamlit as st
import os
import json
from datetime import datetime
from typing import Dict, List, Any, Optional

from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.topic_builder import (
    get_all_topics, get_user_topics, load_topic, CUSTOM_TOPICS_DIR
)

def render():
    """Render the Custom Topic Explorer page"""
    
    # Get all topics
    all_topics = get_all_topics()
    
    if not all_topics:
        st.info("No topics available. Create a topic to get started.")
        if st.button("Create New Topic"):
            st.session_state.page = "topic_builder"
            st.rerun()
        return
    
    # Create a formatted list of topics with icons
    topic_options = [f"{topic.get('icon', '📚')} {topic['title']}" for topic in all_topics]
    
    # Topic selector
    selected_topic_display = st.selectbox(
        "Select Topic",
        options=topic_options,
        index=0,
        key="topic_explorer_selector"
    )
    
    # Extract the actual topic name from the display text (remove icon)
    selected_topic = selected_topic_display.split(' ', 1)[1]
    
    # Find the selected topic data
    selected_topic_data = next((topic for topic in all_topics if topic['title'] == selected_topic), None)
    
    if selected_topic_data:
        # Display the topic title with icon
        st.title(f"{selected_topic_data.get('icon', '📚')} {selected_topic_data.get('title', 'Untitled Topic')}")
        
        # Display the topic description
        st.markdown(selected_topic_data.get('description', 'No description available'))
        
        # Display metadata in a clean format
        st.divider()
        st.subheader("Topic Details")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown(f"**Entity Type:** {selected_topic_data.get('entity_type', 'Not specified')}")
            st.markdown(f"**Created by:** {selected_topic_data.get('creator', 'Unknown')}")
            st.markdown(f"**Created on:** {selected_topic_data.get('created_at', 'Unknown')}")
            
        with col2:
            st.markdown(f"**Total Entities:** {len(selected_topic_data.get('entities', []))}")
            st.markdown(f"**Total Aspects:** {len(selected_topic_data.get('aspects', []))}")
            st.markdown(f"**Topic ID:** {selected_topic_data.get('id', 'Unknown')}")
        
        # Display entities and aspects if available
        if selected_topic_data.get('entities'):
            st.divider()
            st.subheader("Entities")
            for entity in selected_topic_data['entities']:
                with st.expander(f"📌 {entity.get('name', 'Unnamed Entity')}"):
                    st.markdown(f"**Type:** {entity.get('type', 'Not specified')}")
                    st.markdown(f"**Description:** {entity.get('description', 'No description available')}")
                    if entity.get('properties'):
                        st.markdown("**Properties:**")
                        for prop_name, prop_value in entity['properties'].items():
                            st.markdown(f"- {prop_name}: {prop_value}")
        
        if selected_topic_data.get('aspects'):
            st.divider()
            st.subheader("Aspects")
            for aspect in selected_topic_data['aspects']:
                with st.expander(f"🔍 {aspect.get('name', 'Unnamed Aspect')}"):
                    st.markdown(f"**Type:** {aspect.get('type', 'Not specified')}")
                    st.markdown(f"**Description:** {aspect.get('description', 'No description available')}")
                    if aspect.get('properties'):
                        st.markdown("**Properties:**")
                        for prop_name, prop_value in aspect['properties'].items():
                            st.markdown(f"- {prop_name}: {prop_value}")
        
        st.divider()
        
        # Navigation buttons
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("Take Quiz", use_container_width=True):
                st.session_state.page = "quiz"
                st.session_state.selected_topic_id = selected_topic_data.get('id')
                st.rerun()
        
        with col2:
            if st.button("View Quiz History", use_container_width=True):
                st.session_state.page = "quiz_history"
                st.session_state.selected_topic_id = selected_topic_data.get('id')
                st.rerun()
        
        with col3:
            if st.button("Create New Topic", use_container_width=True):
                st.session_state.page = "topic_builder"
                st.rerun() 