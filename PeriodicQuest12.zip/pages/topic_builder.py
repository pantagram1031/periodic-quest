"""
Topic Builder module for the Science Learning Platform.
This module provides a grid-based interface for creating and editing custom topics.
"""
import streamlit as st
import json
import os
import uuid
import pandas as pd
from datetime import datetime
from typing import Dict, List, Any, Optional

from utils.translations import get_translation
from utils.user_auth import is_logged_in, get_current_user
from utils.topic_builder import (
    create_topic, update_topic, load_topic, delete_topic,
    get_user_topics, get_all_topics, CUSTOM_TOPICS_DIR
)

def render():
    """Render the topic builder page"""
    st.title("Topic Builder")
    
    # Check if user is logged in
    if not is_logged_in():
        st.warning("Please log in to use the Topic Builder")
        return
    
    # Initialize session state if needed
    if "topic_data" not in st.session_state:
        st.session_state.topic_data = {
            "title": "",
            "description": "",
            "icon": "📚",
            "entity_type": "",
            "aspects": []
        }
    
    # Load topic if we have a selected topic ID
    if "selected_topic_id" in st.session_state:
        topic = load_topic(st.session_state.selected_topic_id)
        if topic:
            st.session_state.topic_id = st.session_state.selected_topic_id
            st.session_state.topic_data = {
                "title": topic.get("title", ""),
                "description": topic.get("description", ""),
                "icon": topic.get("icon", "📚"),
                "entity_type": topic.get("entity_type", ""),
                "aspects": topic.get("aspects", []),
                "entities": topic.get("entities", [])
            }
            # Clear the selected topic ID to prevent reloading
            del st.session_state.selected_topic_id
    
    # Create tabs for different sections
    tab1, tab2 = st.tabs(["Topic Description", "Entity & Quiz Editor"])
    
    with tab1:
        render_topic_description()
    
    with tab2:
        if "topic_id" in st.session_state:
            topic = load_topic(st.session_state.topic_id)
            if topic:
                render_entity_editor(topic)
            else:
                st.warning("Topic not found. Please save the topic description first.")
        else:
            st.warning("Please save the topic description first to edit entities and quizzes.")

def render_topic_description():
    """Render the topic description section"""
    st.subheader("Topic Description")
    
    # Get topic data from session state
    topic_data = st.session_state.topic_data
    
    # Topic title and description
    topic_data["title"] = st.text_input(
        "Topic Title",
        value=topic_data.get("title", ""),
        key="topic_title"
    )
    
    topic_data["description"] = st.text_area(
        "Topic Description",
        value=topic_data.get("description", ""),
        key="topic_description"
    )
    
    # Entity type name
    topic_data["entity_type"] = st.text_input(
        "Entity Type Name",
        value=topic_data.get("entity_type", ""),
        help="What type of entities will this topic contain? (e.g., elements, particles, events)"
    )
    
    # Icon selection
    topic_data["icon"] = st.selectbox(
        "Icon",
        options=["⚛️", "🔬", "📅", "🌍", "🧪", "🔭", "📚", "🎯"],
        index=["⚛️", "🔬", "📅", "🌍", "🧪", "🔭", "📚", "🎯"].index(topic_data.get("icon", "📚")),
        help="Select an icon to represent your topic"
    )
    
    # Save button
    if st.button("Save Topic Description", use_container_width=True):
        if topic_data["title"] and topic_data["description"] and topic_data["entity_type"]:
            try:
                # Create or update the topic
                if "topic_id" in st.session_state:
                    update_topic(
                        topic_id=st.session_state.topic_id,
                        title=topic_data["title"],
                        description=topic_data["description"],
                        entity_type=topic_data["entity_type"],
                        icon=topic_data["icon"],
                        aspects=topic_data.get("aspects", [])
                    )
                    st.success("Topic updated successfully!")
                else:
                    # Create new topic
                    topic_id = create_topic(
                        title=topic_data["title"],
                        description=topic_data["description"],
                        entity_type=topic_data["entity_type"],
                        creator=get_current_user()
                    )
                    
                    # Update with additional data
                    if topic_data.get("aspects"):
                        update_topic(
                            topic_id=topic_id,
                            aspects=topic_data["aspects"]
                        )
                    
                    st.session_state.topic_id = topic_id
                    st.success("Topic created successfully!")
                
                # Update session state
                st.session_state.topic_data = topic_data
                
            except Exception as e:
                st.error(f"Error saving topic: {str(e)}")
        else:
            st.error("Please fill in all required fields.")

def render_entity_editor(topic):
    """Render the entity editor section with grid-based approach"""
    st.subheader("Entity & Aspect Editor")
    
    # Create tabs for different sections
    aspect_tab, entity_tab, quiz_tab = st.tabs(["Aspects", "Entities", "Quiz Settings"])
    
    with aspect_tab:
        render_aspects_editor(topic)
    
    with entity_tab:
        render_entities_editor(topic)
    
    with quiz_tab:
        render_quiz_settings(topic)

def render_aspects_editor(topic):
    """Render the aspects editor section"""
    st.markdown("### Manage Aspects")
    
    # Add new aspect
    with st.expander("Add New Aspect", expanded=False):
        new_aspect = {
            "id": st.text_input("Aspect ID", key="new_aspect_id"),
            "name": st.text_input("Aspect Name", key="new_aspect_name"),
            "type": st.selectbox("Aspect Type", ["text", "number", "boolean"], key="new_aspect_type"),
            "description": st.text_area("Aspect Description", key="new_aspect_desc"),
            "is_required": st.checkbox("Required", key="new_aspect_required"),
            "is_searchable": st.checkbox("Searchable", key="new_aspect_searchable"),
            "is_quiz_field": st.checkbox("Use in Quiz", key="new_aspect_quiz")
        }
        
        if st.button("Add Aspect", key="add_aspect_btn"):
            if new_aspect["id"] and new_aspect["name"]:
                aspects = topic.get("aspects", [])
                # Ensure the aspect has all required fields
                aspect_data = {
                    "id": new_aspect["id"],
                    "name": new_aspect["name"],
                    "type": new_aspect["type"],
                    "description": new_aspect["description"],
                    "is_required": new_aspect["is_required"],
                    "is_searchable": new_aspect["is_searchable"],
                    "is_quiz_field": new_aspect["is_quiz_field"]
                }
                aspects.append(aspect_data)
                update_topic(topic_id=topic["id"], aspects=aspects)
                st.success("Aspect added successfully!")
                st.rerun()
            else:
                st.error("Please fill in all required fields.")
    
    # Display existing aspects
    aspects = topic.get("aspects", [])
    if aspects:
        st.markdown("#### Existing Aspects")
        for i, aspect in enumerate(aspects):
            # Ensure aspect has all required fields
            aspect_id = aspect.get("id", f"aspect_{i}")  # Use index as fallback
            aspect_name = aspect.get("name", "Unnamed Aspect")
            aspect_type = aspect.get("type", "text")
            
            with st.expander(f"{aspect_name} ({aspect_type})", expanded=False):
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write(f"**ID:** `{aspect_id}`")
                    st.write(f"**Description:** {aspect.get('description', '')}")
                    st.write(f"**Required:** {'Yes' if aspect.get('is_required', False) else 'No'}")
                    st.write(f"**Searchable:** {'Yes' if aspect.get('is_searchable', False) else 'No'}")
                    st.write(f"**Used in Quiz:** {'Yes' if aspect.get('is_quiz_field', False) else 'No'}")
                with col2:
                    # Use both index and ID to ensure unique keys
                    if st.button("Remove", key=f"remove_aspect_{i}_{aspect_id}", use_container_width=True):
                        aspects.remove(aspect)
                        update_topic(topic_id=topic["id"], aspects=aspects)
                        st.success("Aspect removed successfully!")
                        st.rerun()
    else:
        st.info("No aspects defined yet. Add aspects to start building your topic.")

def render_entities_editor(topic):
    """Render the entities editor section"""
    st.markdown("### Manage Entities")
    
    # Add new entity
    with st.expander("Add New Entity", expanded=False):
        new_entity = {
            "id": str(uuid.uuid4()),
            "name": st.text_input("Entity Name", key="new_entity_name")
        }
        
        # Add fields for each aspect
        aspects = topic.get("aspects", [])
        for i, aspect in enumerate(aspects):
            if aspect["type"] == "text":
                new_entity[aspect["id"]] = st.text_input(
                    aspect["name"],
                    key=f"new_entity_{aspect['id']}_{i}_{uuid.uuid4().hex[:8]}"
                )
            elif aspect["type"] == "number":
                new_entity[aspect["id"]] = st.number_input(
                    aspect["name"],
                    key=f"new_entity_{aspect['id']}_{i}_{uuid.uuid4().hex[:8]}"
                )
            elif aspect["type"] == "boolean":
                new_entity[aspect["id"]] = st.checkbox(
                    aspect["name"],
                    key=f"new_entity_{aspect['id']}_{i}_{uuid.uuid4().hex[:8]}"
                )
        
        if st.button("Add Entity", key="add_entity_btn"):
            if new_entity["name"]:
                entities = topic.get("entities", [])
                entities.append(new_entity)
                update_topic(topic_id=topic["id"], entities=entities)
                st.success("Entity added successfully!")
                st.rerun()
            else:
                st.error("Please fill in all required fields.")
    
    # Display entity grid
    entities = topic.get("entities", [])
    aspects = topic.get("aspects", [])
    
    if entities and aspects:
        st.markdown("#### Entity Grid")
        
        # Create tabs for value and bait editing
        value_tab, bait_tab = st.tabs(["Values", "Bait Options"])
        
        with value_tab:
            # Create a DataFrame for the grid
            grid_data = {}
            for entity in entities:
                grid_data[entity["name"]] = {}
                for aspect in aspects:
                    grid_data[entity["name"]][aspect["name"]] = entity.get(aspect["id"], "")
            
            df = pd.DataFrame(grid_data).T
            
            # Display the grid
            edited_df = st.data_editor(
                df,
                use_container_width=True,
                key="entity_grid"
            )
            
            # Save changes
            if st.button("Save Values", use_container_width=True):
                for entity_name, row in edited_df.iterrows():
                    entity = next((e for e in entities if e["name"] == entity_name), None)
                    if entity:
                        for aspect in aspects:
                            entity[aspect["id"]] = row[aspect["name"]]
                update_topic(topic_id=topic["id"], entities=entities)
                st.success("Values saved successfully!")
        
        with bait_tab:
            st.markdown("#### Bait Options Grid")
            st.info("Add bait options for each cell. Multiple baits can be added by separating them with commas.")
            
            # Create a DataFrame for bait options
            bait_data = {}
            for entity in entities:
                bait_data[entity["name"]] = {}
                for aspect in aspects:
                    # Get existing bait options for this entity-aspect combination
                    bait_key = f"{entity['id']}_{aspect['id']}"
                    current_baits = topic.get("bait_options", {}).get(bait_key, [])
                    bait_data[entity["name"]][aspect["name"]] = ", ".join(current_baits)
            
            bait_df = pd.DataFrame(bait_data).T
            
            # Display the bait grid
            edited_bait_df = st.data_editor(
                bait_df,
                use_container_width=True,
                key="bait_grid"
            )
            
            # Save bait changes
            if st.button("Save Bait Options", use_container_width=True):
                bait_options = {}
                for entity_name, row in edited_bait_df.iterrows():
                    entity = next((e for e in entities if e["name"] == entity_name), None)
                    if entity:
                        for aspect in aspects:
                            bait_key = f"{entity['id']}_{aspect['id']}"
                            # Split by comma and clean up each bait
                            baits = [bait.strip() for bait in row[aspect["name"]].split(",") if bait.strip()]
                            if baits:  # Only add if there are baits
                                bait_options[bait_key] = baits
                
                # Update topic with new bait options
                topic_data = topic.copy()
                topic_data["bait_options"] = bait_options
                update_topic(topic_id=topic["id"], topic_data=topic_data)
                st.success("Bait options saved successfully!")

def render_quiz_settings(topic):
    """Render the quiz settings section"""
    st.markdown("### Quiz Settings")
    
    # Get aspects for selection
    aspects = topic.get("aspects", [])
    quiz_aspects = [aspect for aspect in aspects if aspect.get("is_quiz_field", False)]
    
    if not quiz_aspects:
        st.warning("No aspects are marked for quiz use. Please mark some aspects in the Aspects tab.")
        return
    
    # Input aspects selection
    st.markdown("#### Input Aspects")
    input_aspects = st.multiselect(
        "Select aspects to use as quiz inputs",
        options=[aspect["name"] for aspect in quiz_aspects],
        default=[aspect["name"] for aspect in quiz_aspects]
    )
    
    # Output aspects selection
    st.markdown("#### Output Aspects")
    output_aspects = st.multiselect(
        "Select aspects to use as quiz outputs",
        options=[aspect["name"] for aspect in quiz_aspects],
        default=[aspect["name"] for aspect in quiz_aspects]
    )
    
    # Quiz type selection
    quiz_type = st.selectbox(
        "Quiz Type",
        options=["Multiple Choice", "Text Input", "Mixed"],
        index=2,
        help="Select the type of questions for this quiz"
    )
    
    # Bait options for each aspect
    st.markdown("#### Bait Options")
    for aspect in quiz_aspects:
        with st.expander(f"Bait Options for {aspect['name']}", expanded=False):
            current_bait = topic.get("bait_options", {}).get(aspect["id"], [])
            bait_text = "\n".join(current_bait)
            new_bait = st.text_area(
                "Enter bait options (one per line)",
                value=bait_text,
                key=f"bait_{aspect['id']}"
            )
            if new_bait:
                bait_options = [line.strip() for line in new_bait.split("\n") if line.strip()]
                if "bait_options" not in topic:
                    topic["bait_options"] = {}
                topic["bait_options"][aspect["id"]] = bait_options
    
    # Save quiz settings
    if st.button("Save Quiz Settings", use_container_width=True):
        quiz_settings = {
            "input_aspects": [aspect["id"] for aspect in quiz_aspects if aspect["name"] in input_aspects],
            "output_aspects": [aspect["id"] for aspect in quiz_aspects if aspect["name"] in output_aspects],
            "quiz_type": quiz_type.lower().replace(" ", "_"),
            "is_custom_topic": True
        }
        update_topic(topic_id=topic["id"], quiz_settings=quiz_settings, bait_options=topic.get("bait_options", {}))
        st.success("Quiz settings saved successfully!")
        
        # Add buttons to take or manage the quiz
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Take Quiz", use_container_width=True):
                st.session_state.page = "quiz"
                st.session_state.quiz_topic_id = topic["id"]
                st.session_state.quiz_type = "custom_topic"
                st.rerun()
        
        with col2:
            if st.button("Manage Quiz", use_container_width=True):
                st.session_state.page = "custom_content"
                st.session_state.content_tab = "quizzes"
                st.session_state.editing_quiz_id = topic["id"]
                st.rerun()