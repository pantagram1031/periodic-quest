"""
Element details page module for the Chemical Elements Explorer.
"""

import streamlit as st
import plotly.graph_objects as go
from data.elements import get_element_color
from utils.translations import get_translation, get_display_name

def render():
    """Render the element details page"""
    if not st.session_state.selected_element:
        st.error(get_translation("no_element_selected"))
        
        if st.button(get_translation("back_to_home")):
            st.session_state.page = "home"
            st.rerun()
        return
    
    element = st.session_state.selected_element
    
    # Element header with colored background
    category_color = get_element_color(element['category'])
    
    # Use display_name for proper formatting with Korean/English
    display_name = get_display_name(element)
    
    # Get translated labels
    atomic_number_label = get_translation("atomic_number")
    category_label = get_translation("category")
    
    st.markdown(
        f"""
        <div style="background-color: {category_color}; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
            <h1 style="color: #000000;">{display_name} ({element['symbol']})</h1>
            <h3 style="color: #000000;">{atomic_number_label}: {element['atomic_number']} | {category_label}: {element['category'].capitalize()}</h3>
        </div>
        """, 
        unsafe_allow_html=True
    )
    
    # Layout with tabs for different information categories
    tab1, tab2, tab3 = st.tabs([
        get_translation("basic_properties"), 
        get_translation("physical_properties_tab"), 
        get_translation("discovery_uses")
    ])
    
    with tab1:
        # Check if mobile mode is enabled
        mobile_mode = st.session_state.mobile_mode if "mobile_mode" in st.session_state else False
        
        # Use full width in mobile mode, otherwise split into columns
        if mobile_mode:
            # Single column layout for mobile
            col_main = st.container()
            with col_main:
                st.subheader(get_translation("element_identity"))
                
                # Get appropriate translations and values
                group_text = element['group'] if element['group'] is not None else get_translation("not_applicable")
                
                st.markdown(f"""
                **{get_translation("name")}:** {element['name']}  
                **{get_translation("symbol")}:** {element['symbol']}  
                **{get_translation("atomic_number")}:** {element['atomic_number']}  
                **{get_translation("atomic_weight")}:** {element['atomic_weight']} u  
                **{get_translation("category")}:** {element['category'].capitalize()}  
                **{get_translation("group")}:** {group_text}  
                **{get_translation("period")}:** {element['period']}  
                """)
                
                # Electronic structure section
                st.subheader(get_translation("electronic_structure"))
                
                # Get translation for N/A
                na_text = get_translation("not_applicable")
                electronegativity_text = element['electronegativity'] if element['electronegativity'] is not None else na_text
                
                st.markdown(f"""
                **{get_translation("electron_configuration")}:** {element['electron_configuration']}  
                **{get_translation("electronegativity")}:** {electronegativity_text}  
                """)
                
                # Create a simple visualization of the element's position in the periodic table
                fig = go.Figure()
                
                # Add a rectangle for the element
                fig.add_shape(
                    type='rect',
                    x0=0,
                    y0=0,
                    x1=1,
                    y1=1,
                    fillcolor=category_color,
                    opacity=0.8,
                    line=dict(
                        color='black',
                        width=2
                    )
                )
                
                # Add the element symbol and atomic number
                fig.add_trace(go.Scatter(
                    x=[0.5],
                    y=[0.6],
                    mode='text',
                    text=[element['symbol']],
                    textfont=dict(
                        family='Arial',
                        size=40,
                        color='black'
                    ),
                    hoverinfo='none'
                ))
                
                fig.add_trace(go.Scatter(
                    x=[0.5],
                    y=[0.3],
                    mode='text',
                    text=[element['atomic_number']],
                    textfont=dict(
                        family='Arial',
                        size=20,
                        color='black'
                    ),
                    hoverinfo='none'
                ))
                
                # Update layout
                fig.update_layout(
                    height=200,  # Slightly smaller for mobile
                    width=200,
                    showlegend=False,
                    margin=dict(l=0, r=0, t=0, b=0),
                    xaxis=dict(
                        showgrid=False,
                        zeroline=False,
                        showticklabels=False,
                        range=[0, 1]
                    ),
                    yaxis=dict(
                        showgrid=False,
                        zeroline=False,
                        showticklabels=False,
                        range=[0, 1]
                    )
                )
                
                st.plotly_chart(fig, use_container_width=False)
        else:
            # Desktop layout with columns
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader(get_translation("element_identity"))
                
                # Get appropriate translations and values
                group_text = element['group'] if element['group'] is not None else get_translation("not_applicable")
                
                st.markdown(f"""
                **{get_translation("name")}:** {element['name']}  
                **{get_translation("symbol")}:** {element['symbol']}  
                **{get_translation("atomic_number")}:** {element['atomic_number']}  
                **{get_translation("atomic_weight")}:** {element['atomic_weight']} u  
                **{get_translation("category")}:** {element['category'].capitalize()}  
                **{get_translation("group")}:** {group_text}  
                **{get_translation("period")}:** {element['period']}  
                """)
            
            with col2:
                st.subheader(get_translation("electronic_structure"))
                
                # Get translation for N/A
                na_text = get_translation("not_applicable")
                electronegativity_text = element['electronegativity'] if element['electronegativity'] is not None else na_text
                
                st.markdown(f"""
                **{get_translation("electron_configuration")}:** {element['electron_configuration']}  
                **{get_translation("electronegativity")}:** {electronegativity_text}  
                """)
                
                # Create a simple visualization of the element's position in the periodic table
                fig = go.Figure()
                
                # Add a rectangle for the element
                fig.add_shape(
                    type='rect',
                    x0=0,
                    y0=0,
                    x1=1,
                    y1=1,
                    fillcolor=category_color,
                    opacity=0.8,
                    line=dict(
                        color='black',
                        width=2
                    )
                )
                
                # Add the element symbol and atomic number
                fig.add_trace(go.Scatter(
                    x=[0.5],
                    y=[0.6],
                    mode='text',
                    text=[element['symbol']],
                    textfont=dict(
                        family='Arial',
                        size=40,
                        color='black'
                    ),
                    hoverinfo='none'
                ))
                
                fig.add_trace(go.Scatter(
                    x=[0.5],
                    y=[0.3],
                    mode='text',
                    text=[element['atomic_number']],
                    textfont=dict(
                        family='Arial',
                        size=20,
                        color='black'
                    ),
                    hoverinfo='none'
                ))
                
                # Update layout
                fig.update_layout(
                    height=250,
                    width=250,
                    showlegend=False,
                    margin=dict(l=0, r=0, t=0, b=0),
                    xaxis=dict(
                        showgrid=False,
                        zeroline=False,
                        showticklabels=False,
                        range=[0, 1]
                    ),
                    yaxis=dict(
                        showgrid=False,
                        zeroline=False,
                        showticklabels=False,
                        range=[0, 1]
                    )
                )
                
                st.plotly_chart(fig)
    
    with tab2:
        # Check if mobile mode is enabled
        mobile_mode = st.session_state.mobile_mode if "mobile_mode" in st.session_state else False
        
        if mobile_mode:
            # Single column layout for mobile
            col_main = st.container()
            with col_main:
                st.subheader(get_translation("physical_properties"))
                
                st.markdown(f"""
                **{get_translation("density")}:** {element['density']} g/cm³  
                **{get_translation("melting_point")}:** {element['melting_point']} K  
                **{get_translation("boiling_point")}:** {element['boiling_point']} K  
                """)
                
                # Add phase at room temperature if known
                room_temp = 298.15  # K
                if element['melting_point'] and element['boiling_point']:
                    if room_temp < element['melting_point']:
                        phase = get_translation("solid")
                    elif room_temp < element['boiling_point']:
                        phase = get_translation("liquid")
                    else:
                        phase = get_translation("gas")
                    phase_text = get_translation("phase_at_room_temp")
                    st.markdown(f"**{phase_text}:** {phase}")
                
                # Create a simple bar chart for comparing melting and boiling points
                if element['melting_point'] and element['boiling_point']:
                    fig = go.Figure()
                    
                    # Get translated labels for the chart
                    mp_label = get_translation("melting_point")
                    bp_label = get_translation("boiling_point")
                    
                    fig.add_trace(go.Bar(
                        x=[mp_label, bp_label],
                        y=[element['melting_point'], element['boiling_point']],
                        marker_color=[category_color, '#1E88E5'],
                        text=[f"{element['melting_point']} K", f"{element['boiling_point']} K"],
                        textposition='auto'
                    ))
                    
                    # Title and labels in the appropriate language
                    chart_title = get_translation("mp_bp_chart_title")
                    y_axis_title = get_translation("temperature_k")
                    
                    fig.update_layout(
                        title=chart_title,
                        yaxis=dict(title=y_axis_title),
                        height=300
                    )
                    
                    st.plotly_chart(fig)
        else:
            # Desktop layout with columns
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader(get_translation("physical_properties"))
                st.markdown(f"""
                **{get_translation("density")}:** {element['density']} g/cm³  
                **{get_translation("melting_point")}:** {element['melting_point']} K  
                **{get_translation("boiling_point")}:** {element['boiling_point']} K  
                """)
                
                # Add phase at room temperature if known
                room_temp = 298.15  # K
                if element['melting_point'] and element['boiling_point']:
                    if room_temp < element['melting_point']:
                        phase = get_translation("solid")
                    elif room_temp < element['boiling_point']:
                        phase = get_translation("liquid")
                    else:
                        phase = get_translation("gas")
                    phase_text = get_translation("phase_at_room_temp")
                    st.markdown(f"**{phase_text}:** {phase}")
            
            with col2:
                # Create a simple bar chart for comparing melting and boiling points
                if element['melting_point'] and element['boiling_point']:
                    fig = go.Figure()
                    
                    # Get translated labels for the chart
                    mp_label = get_translation("melting_point")
                    bp_label = get_translation("boiling_point")
                    
                    fig.add_trace(go.Bar(
                        x=[mp_label, bp_label],
                        y=[element['melting_point'], element['boiling_point']],
                        marker_color=[category_color, '#1E88E5'],
                        text=[f"{element['melting_point']} K", f"{element['boiling_point']} K"],
                        textposition='auto'
                    ))
                    
                    # Title and labels in the appropriate language
                    chart_title = get_translation("mp_bp_chart_title")
                    y_axis_title = get_translation("temperature_k")
                    
                    fig.update_layout(
                        title=chart_title,
                        yaxis=dict(title=y_axis_title),
                        height=300
                    )
                    
                    st.plotly_chart(fig)
    
    with tab3:
        # Check if mobile mode is enabled
        mobile_mode = st.session_state.mobile_mode if "mobile_mode" in st.session_state else False
        
        # Get current language
        current_lang = st.session_state.language if "language" in st.session_state else "English"
        
        # Get translations for unknown and ancient
        unknown_text = get_translation("unknown")
        ancient_text = get_translation("ancient")
        
        # Use the translation for discovered_by and discovery_year
        discovered_by = element['discovered_by'] if element['discovered_by'] else unknown_text
        discovery_year = element['discovery_year'] if element['discovery_year'] else ancient_text
        
        # Function to show descriptions based on language
        def show_basic_description():
            # For Korean language
            if current_lang == "Korean":
                # Show Korean beginner description if available
                if 'korean_beginner_description' in element and element['korean_beginner_description']:
                    st.markdown(element['korean_beginner_description'])
                # Fall back to regular Korean description
                elif 'korean_description' in element and element['korean_description']:
                    st.markdown(element['korean_description'])
                # Ultimate fallback to English description
                else:
                    if 'beginner_description' in element and element['beginner_description']:
                        st.markdown(element['beginner_description'])
                    else:
                        st.markdown(element['description'])
            # For English language
            else:
                # Show beginner/basic description if available, otherwise fall back to regular description
                if 'beginner_description' in element and element['beginner_description']:
                    st.markdown(element['beginner_description'])
                else:
                    st.markdown(element['description'])
        
        def show_advanced_description():
            # For Korean language
            if current_lang == "Korean":
                # Show Korean advanced description if available
                if 'korean_advanced_description' in element and element['korean_advanced_description']:
                    st.markdown(element['korean_advanced_description'])
                # Fall back to regular Korean description
                elif 'korean_description' in element and element['korean_description']:
                    st.markdown(element['korean_description'])
                # Ultimate fallback to English description
                else:
                    if 'advanced_description' in element and element['advanced_description']:
                        st.markdown(element['advanced_description'])
                    else:
                        st.markdown(element['description'])
            # For English language
            else:
                # Show advanced description if available, otherwise fall back to regular description
                if 'advanced_description' in element and element['advanced_description']:
                    st.markdown(element['advanced_description'])
                else:
                    st.markdown(element['description'])
                    
        if mobile_mode:
            # Single column layout for mobile
            st.subheader(get_translation("discovery"))
            st.markdown(f"""
            **{get_translation("discovered_by")}:** {discovered_by}  
            **{get_translation("discovery_year")}:** {discovery_year}  
            """)
            
            st.subheader(get_translation("description"))
            
            # Create tabs for different description levels with translated labels
            description_tabs = st.tabs([get_translation("basic"), get_translation("advanced")])
            
            with description_tabs[0]:
                show_basic_description()
                    
            with description_tabs[1]:
                show_advanced_description()
        else:
            # Desktop layout with columns
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader(get_translation("discovery"))
                st.markdown(f"""
                **{get_translation("discovered_by")}:** {discovered_by}  
                **{get_translation("discovery_year")}:** {discovery_year}  
                """)
            
            with col2:
                st.subheader(get_translation("description"))
                
                # Create tabs for different description levels with translated labels
                description_tabs = st.tabs([get_translation("basic"), get_translation("advanced")])
                
                with description_tabs[0]:
                    show_basic_description()
                        
                with description_tabs[1]:
                    show_advanced_description()
    
    # Navigation buttons
    st.markdown("---")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button(get_translation("back_to_home"), use_container_width=True):
            st.session_state.page = "home"
            st.rerun()
    
    with col2:
        if st.button(get_translation("view_periodic_table"), use_container_width=True):
            st.session_state.page = "periodic_table"
            st.rerun()
    
    with col3:
        if st.button(get_translation("take_a_quiz"), use_container_width=True):
            st.session_state.page = "quiz"
            st.rerun()
