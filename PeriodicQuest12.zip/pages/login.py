"""
Login module for the Science Learning Platform.
This module handles user login and registration.
"""
import streamlit as st
from utils.translations import get_translation
from utils.user_auth import (
    authenticate_user, register_user, is_logged_in, 
    get_current_user, get_current_user_display_name,
    get_user_data, logout, request_password_reset,
    reset_password
)

def render():
    """Render the login page"""
    st.title(get_translation("account_management", "Account Management"))
    
    # If already logged in, show a logout button
    if is_logged_in():
        username = get_current_user()
        display_name = get_current_user_display_name()
        
        st.success(f"{get_translation('welcome')}, {display_name}!")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Button to go to full account page
            if st.button(get_translation("account_info", "Account Info"), use_container_width=True):
                st.session_state.page = "account"
                st.rerun()
                
        with col2:
            # Logout button
            if st.button(get_translation("logout", "Logout"), use_container_width=True):
                logout()
                st.success(get_translation("logged_out", "You have been logged out."))
                st.rerun()
        
        return
    
    # Login and Registration tabs
    tab1, tab2, tab3 = st.tabs([
        get_translation("login", "Login"), 
        get_translation("register", "Register"),
        get_translation("reset_password", "Reset Password")
    ])
    
    with tab1:
        _render_login_tab()
    
    with tab2:
        _render_register_tab()
        
    with tab3:
        _render_reset_password_tab()
    
def _render_login_tab():
    """Render the login tab"""
    with st.form("login_form"):
        st.subheader(get_translation("login_to_your_account", "Login to Your Account"))
        
        username = st.text_input(get_translation("username", "Username"))
        password = st.text_input(get_translation("password", "Password"), type="password")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            submit_button = st.form_submit_button(get_translation("login", "Login"), use_container_width=True)
        with col2:
            forgot_password = st.form_submit_button("Forgot Password?", use_container_width=True)
        
        if submit_button:
            if not username or not password:
                st.error(get_translation("please_fill_all_fields", "Please fill in all fields."))
            else:
                success, message = authenticate_user(username, password)
                if success:
                    st.session_state.username = username
                    user_data = get_user_data(username)
                    st.session_state.user_id = user_data.get("user_id")
                    
                    # Set language preference if available
                    if "settings" in user_data and "language" in user_data["settings"]:
                        st.session_state.language = user_data["settings"]["language"]
                    
                    st.success(message)
                    # Rerun to refresh page and show account info
                    st.rerun()
                else:
                    st.error(message)
        
        if forgot_password:
            st.session_state.show_reset_password = True
            st.rerun()

def _render_register_tab():
    """Render the registration tab"""
    with st.form("register_form"):
        st.subheader(get_translation("create_account", "Create New Account"))
        
        new_username = st.text_input(get_translation("username", "Username"))
        display_name = st.text_input(
            get_translation("display_name", "Display Name"),
            help=get_translation("display_name_help", "Your preferred name to display in the app (optional)")
        )
        email = st.text_input(
            "Email",
            help="Your email address for password recovery (optional)"
        )
        new_password = st.text_input(get_translation("password", "Password"), type="password")
        confirm_password = st.text_input(get_translation("confirm_password", "Confirm Password"), type="password")
        
        # Password strength indicator
        if new_password:
            strength = 0
            if len(new_password) >= 8:
                strength += 1
            if any(c.isupper() for c in new_password):
                strength += 1
            if any(c.islower() for c in new_password):
                strength += 1
            if any(c.isdigit() for c in new_password):
                strength += 1
            if any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in new_password):
                strength += 1
                
            strength_colors = ["red", "orange", "yellow", "lightgreen", "green"]
            st.markdown(f"Password strength: {'🔴' * strength}{'⚪' * (5-strength)}")
        
        language_options = ["English", "한국어"]  # Add more languages as needed
        selected_language = st.selectbox(
            get_translation("language_setting", "Language"),
            options=language_options,
            index=0  # Default to English
        )
        
        submit_button = st.form_submit_button(get_translation("register", "Register"), use_container_width=True)
        
        if submit_button:
            if not new_username or not new_password or not confirm_password:
                st.error(get_translation("please_fill_required_fields", "Please fill in all required fields."))
            elif new_password != confirm_password:
                st.error(get_translation("passwords_dont_match", "Passwords don't match."))
            elif len(new_password) < 8:
                st.error("Password must be at least 8 characters long.")
            else:
                success, message = register_user(new_username, new_password, display_name, email)
                if success:
                    st.success(message)
                    st.info(get_translation("please_login", "Please login with your new account."))
                else:
                    st.error(message)

def _render_reset_password_tab():
    """Render the password reset tab"""
    st.subheader("Reset Your Password")
    
    # Step 1: Request reset
    if "reset_step" not in st.session_state:
        st.session_state.reset_step = 1
    
    if st.session_state.reset_step == 1:
        with st.form("request_reset_form"):
            username = st.text_input("Username")
            submit = st.form_submit_button("Request Reset Link")
            
            if submit:
                if not username:
                    st.error("Please enter your username.")
                else:
                    success, message = request_password_reset(username)
                    if success:
                        st.success("A reset token has been generated. Please check your email.")
                        st.session_state.reset_username = username
                        st.session_state.reset_step = 2
                        st.rerun()
                    else:
                        st.error(message)
    
    # Step 2: Enter new password
    elif st.session_state.reset_step == 2:
        with st.form("reset_password_form"):
            st.info("Please enter the reset token you received and your new password.")
            reset_token = st.text_input("Reset Token")
            new_password = st.text_input("New Password", type="password")
            confirm_password = st.text_input("Confirm New Password", type="password")
            
            submit = st.form_submit_button("Reset Password")
            
            if submit:
                if not reset_token or not new_password or not confirm_password:
                    st.error("Please fill in all fields.")
                elif new_password != confirm_password:
                    st.error("Passwords don't match.")
                elif len(new_password) < 8:
                    st.error("Password must be at least 8 characters long.")
                else:
                    success, message = reset_password(
                        st.session_state.reset_username,
                        reset_token,
                        new_password
                    )
                    if success:
                        st.success("Password has been reset successfully. Please login with your new password.")
                        del st.session_state.reset_step
                        del st.session_state.reset_username
                        st.rerun()
                    else:
                        st.error(message)